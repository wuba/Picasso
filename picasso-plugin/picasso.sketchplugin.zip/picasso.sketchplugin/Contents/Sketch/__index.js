var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

module.exports = _iterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray;

/***/ }),

/***/ "./node_modules/@skpm/fs/index.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// TODO: async. Should probably be done with NSFileHandle and some notifications
// TODO: file descriptor. Needs to be done with NSFileHandle
var Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
var utils = __webpack_require__(/*! ./utils */ "./node_modules/@skpm/fs/utils.js");
var parseStat = utils.parseStat;
var fsError = utils.fsError;
var fsErrorForPath = utils.fsErrorForPath;
var encodingFromOptions = utils.encodingFromOptions;
var NOT_IMPLEMENTED = utils.NOT_IMPLEMENTED;

module.exports.constants = {
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1,
};

module.exports.access = NOT_IMPLEMENTED("access");

module.exports.accessSync = function (path, mode) {
  mode = mode | 0;
  var fileManager = NSFileManager.defaultManager();

  switch (mode) {
    case 0:
      canAccess = module.exports.existsSync(path);
      break;
    case 1:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 2:
      canAccess = Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 3:
      canAccess =
        Boolean(Number(fileManager.isExecutableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 4:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path)));
      break;
    case 5:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 6:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 7:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
  }

  if (!canAccess) {
    throw new Error("Can't access " + String(path));
  }
};

module.exports.appendFile = NOT_IMPLEMENTED("appendFile");

module.exports.appendFileSync = function (file, data, options) {
  if (!module.exports.existsSync(file)) {
    return module.exports.writeFileSync(file, data, options);
  }

  var handle = NSFileHandle.fileHandleForWritingAtPath(file);
  handle.seekToEndOfFile();

  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  handle.writeData(nsdata);
};

module.exports.chmod = NOT_IMPLEMENTED("chmod");

module.exports.chmodSync = function (path, mode) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFilePosixPermissions: mode,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.chown = NOT_IMPLEMENTED("chown");
module.exports.chownSync = NOT_IMPLEMENTED("chownSync");

module.exports.close = NOT_IMPLEMENTED("close");
module.exports.closeSync = NOT_IMPLEMENTED("closeSync");

module.exports.copyFile = NOT_IMPLEMENTED("copyFile");

module.exports.copyFileSync = function (path, dest, flags) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.copyItemAtPath_toPath_error(path, dest, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.createReadStream = NOT_IMPLEMENTED("createReadStream");
module.exports.createWriteStream = NOT_IMPLEMENTED("createWriteStream");

module.exports.exists = NOT_IMPLEMENTED("exists");

module.exports.existsSync = function (path) {
  var fileManager = NSFileManager.defaultManager();
  return Boolean(Number(fileManager.fileExistsAtPath(path)));
};

module.exports.fchmod = NOT_IMPLEMENTED("fchmod");
module.exports.fchmodSync = NOT_IMPLEMENTED("fchmodSync");
module.exports.fchown = NOT_IMPLEMENTED("fchown");
module.exports.fchownSync = NOT_IMPLEMENTED("fchownSync");
module.exports.fdatasync = NOT_IMPLEMENTED("fdatasync");
module.exports.fdatasyncSync = NOT_IMPLEMENTED("fdatasyncSync");
module.exports.fstat = NOT_IMPLEMENTED("fstat");
module.exports.fstatSync = NOT_IMPLEMENTED("fstatSync");
module.exports.fsync = NOT_IMPLEMENTED("fsync");
module.exports.fsyncSync = NOT_IMPLEMENTED("fsyncSync");
module.exports.ftruncate = NOT_IMPLEMENTED("ftruncate");
module.exports.ftruncateSync = NOT_IMPLEMENTED("ftruncateSync");
module.exports.futimes = NOT_IMPLEMENTED("futimes");
module.exports.futimesSync = NOT_IMPLEMENTED("futimesSync");

module.exports.lchmod = NOT_IMPLEMENTED("lchmod");
module.exports.lchmodSync = NOT_IMPLEMENTED("lchmodSync");
module.exports.lchown = NOT_IMPLEMENTED("lchown");
module.exports.lchownSync = NOT_IMPLEMENTED("lchownSync");

module.exports.link = NOT_IMPLEMENTED("link");

module.exports.linkSync = function (existingPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.linkItemAtPath_toPath_error(existingPath, newPath, err);

  if (err.value() !== null) {
    throw fsErrorForPath(existingPath, undefined, err.value());
  }
};

module.exports.lstat = NOT_IMPLEMENTED("lstat");

module.exports.lstatSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.attributesOfItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return parseStat(result);
};

module.exports.mkdir = NOT_IMPLEMENTED("mkdir");

module.exports.mkdirSync = function (path, options) {
  var mode = 0o777;
  var recursive = false;
  if (options && options.mode) {
    mode = options.mode;
  }
  if (options && options.recursive) {
    recursive = options.recursive;
  }
  if (typeof options === "number") {
    mode = options;
  }
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(
    path,
    recursive,
    {
      NSFilePosixPermissions: mode,
    },
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.mkdtemp = NOT_IMPLEMENTED("mkdtemp");

module.exports.mkdtempSync = function (path) {
  function makeid() {
    var text = "";
    var possible =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 6; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  var tempPath = path + makeid();
  module.exports.mkdirSync(tempPath);
  return tempPath;
};

module.exports.open = NOT_IMPLEMENTED("open");
module.exports.openSync = NOT_IMPLEMENTED("openSync");

module.exports.read = NOT_IMPLEMENTED("read");

module.exports.readdir = NOT_IMPLEMENTED("readdir");

module.exports.readdirSync = function (path, options) {
  var encoding = encodingFromOptions(options, "utf8");
  var fileManager = NSFileManager.defaultManager();
  var paths = fileManager.subpathsAtPath(path);
  var arr = [];
  for (var i = 0; i < paths.length; i++) {
    var pathName = paths[i];
    arr.push(encoding === "buffer" ? Buffer.from(pathName) : String(pathName));
  }
  return arr;
};

module.exports.readFile = NOT_IMPLEMENTED("readFile");

module.exports.readFileSync = function (path, options) {
  var encoding = encodingFromOptions(options, "buffer");
  var fileManager = NSFileManager.defaultManager();
  var data = fileManager.contentsAtPath(path);
  if (!data) {
    throw fsErrorForPath(path, false);
  }

  var buffer = Buffer.from(data);

  if (encoding === "buffer") {
    return buffer;
  } else if (encoding === "NSData") {
    return buffer.toNSData();
  } else {
    return buffer.toString(encoding);
  }
};

module.exports.readlink = NOT_IMPLEMENTED("readlink");

module.exports.readlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.destinationOfSymbolicLinkAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return String(result);
};

module.exports.readSync = NOT_IMPLEMENTED("readSync");

module.exports.realpath = NOT_IMPLEMENTED("realpath");
module.exports.realpath.native = NOT_IMPLEMENTED("realpath.native");

module.exports.realpathSync = function (path) {
  return String(
    NSString.stringWithString(path).stringByResolvingSymlinksInPath()
  );
};

module.exports.realpathSync.native = NOT_IMPLEMENTED("realpathSync.native");

module.exports.rename = NOT_IMPLEMENTED("rename");

module.exports.renameSync = function (oldPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.moveItemAtPath_toPath_error(oldPath, newPath, err);

  var error = err.value();

  if (error !== null) {
    // if there is already a file, we need to overwrite it
    if (
      String(error.domain()) === "NSCocoaErrorDomain" &&
      Number(error.code()) === 516
    ) {
      var err2 = MOPointer.alloc().init();
      fileManager.replaceItemAtURL_withItemAtURL_backupItemName_options_resultingItemURL_error(
        NSURL.fileURLWithPath(newPath),
        NSURL.fileURLWithPath(oldPath),
        null,
        NSFileManagerItemReplacementUsingNewMetadataOnly,
        null,
        err2
      );
      if (err2.value() !== null) {
        throw fsErrorForPath(oldPath, undefined, err2.value());
      }
    } else {
      throw fsErrorForPath(oldPath, undefined, error);
    }
  }
};

module.exports.rmdir = NOT_IMPLEMENTED("rmdir");

module.exports.rmdirSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (!isDirectory) {
    throw fsError("ENOTDIR", {
      path: path,
      syscall: "rmdir",
    });
  }
  fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, true, err.value(), "rmdir");
  }
};

module.exports.stat = NOT_IMPLEMENTED("stat");

// the only difference with lstat is that we resolve symlinks
//
// > lstat() is identical to stat(), except that if pathname is a symbolic
// > link, then it returns information about the link itself, not the file
// > that it refers to.
// http://man7.org/linux/man-pages/man2/lstat.2.html
module.exports.statSync = function (path) {
  return module.exports.lstatSync(module.exports.realpathSync(path));
};

module.exports.symlink = NOT_IMPLEMENTED("symlink");

module.exports.symlinkSync = function (target, path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.createSymbolicLinkAtPath_withDestinationPath_error(
    path,
    target,
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.truncate = NOT_IMPLEMENTED("truncate");

module.exports.truncateSync = function (path, len) {
  var hFile = NSFileHandle.fileHandleForUpdatingAtPath(sFilePath);
  hFile.truncateFileAtOffset(len || 0);
  hFile.closeFile();
};

module.exports.unlink = NOT_IMPLEMENTED("unlink");

module.exports.unlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (isDirectory) {
    throw fsError("EPERM", {
      path: path,
      syscall: "unlink",
    });
  }
  var result = fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.unwatchFile = NOT_IMPLEMENTED("unwatchFile");

module.exports.utimes = NOT_IMPLEMENTED("utimes");

module.exports.utimesSync = function (path, aTime, mTime) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFileModificationDate: aTime,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.watch = NOT_IMPLEMENTED("watch");
module.exports.watchFile = NOT_IMPLEMENTED("watchFile");

module.exports.write = NOT_IMPLEMENTED("write");

module.exports.writeFile = NOT_IMPLEMENTED("writeFile");

module.exports.writeFileSync = function (path, data, options) {
  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  nsdata.writeToFile_atomically(path, true);
};

module.exports.writeSync = NOT_IMPLEMENTED("writeSync");


/***/ }),

/***/ "./node_modules/@skpm/fs/utils.js":
/*!****************************************!*\
  !*** ./node_modules/@skpm/fs/utils.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports.parseStat = function parseStat(result) {
  return {
    dev: String(result.NSFileDeviceIdentifier),
    // ino: 48064969, The file system specific "Inode" number for the file.
    mode: result.NSFileType | result.NSFilePosixPermissions,
    nlink: Number(result.NSFileReferenceCount),
    uid: String(result.NSFileOwnerAccountID),
    gid: String(result.NSFileGroupOwnerAccountID),
    // rdev: 0, A numeric device identifier if the file is considered "special".
    size: Number(result.NSFileSize),
    // blksize: 4096, The file system block size for i/o operations.
    // blocks: 8, The number of blocks allocated for this file.
    atimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    mtimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    ctimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    birthtimeMs:
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000,
    atime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ), // the 0.5 comes from the node source. Not sure why it's added but in doubt...
    mtime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    ctime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    birthtime: new Date(
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    isBlockDevice: function () {
      return result.NSFileType === NSFileTypeBlockSpecial;
    },
    isCharacterDevice: function () {
      return result.NSFileType === NSFileTypeCharacterSpecial;
    },
    isDirectory: function () {
      return result.NSFileType === NSFileTypeDirectory;
    },
    isFIFO: function () {
      return false;
    },
    isFile: function () {
      return result.NSFileType === NSFileTypeRegular;
    },
    isSocket: function () {
      return result.NSFileType === NSFileTypeSocket;
    },
    isSymbolicLink: function () {
      return result.NSFileType === NSFileTypeSymbolicLink;
    },
  };
};

var ERRORS = {
  EPERM: {
    message: "operation not permitted",
    errno: -1,
  },
  ENOENT: {
    message: "no such file or directory",
    errno: -2,
  },
  EACCES: {
    message: "permission denied",
    errno: -13,
  },
  ENOTDIR: {
    message: "not a directory",
    errno: -20,
  },
  EISDIR: {
    message: "illegal operation on a directory",
    errno: -21,
  },
};

function fsError(code, options) {
  var error = new Error(
    code +
      ": " +
      ERRORS[code].message +
      ", " +
      (options.syscall || "") +
      (options.path ? " '" + options.path + "'" : "")
  );

  Object.keys(options).forEach(function (k) {
    error[k] = options[k];
  });

  error.code = code;
  error.errno = ERRORS[code].errno;

  return error;
}

module.exports.fsError = fsError;

module.exports.fsErrorForPath = function fsErrorForPath(
  path,
  shouldBeDir,
  err,
  syscall
) {
  var fileManager = NSFileManager.defaultManager();
  var doesExist = fileManager.fileExistsAtPath(path);
  if (!doesExist) {
    return fsError("ENOENT", {
      path: path,
      syscall: syscall || "open",
    });
  }
  var isReadable = fileManager.isReadableFileAtPath(path);
  if (!isReadable) {
    return fsError("EACCES", {
      path: path,
      syscall: syscall || "open",
    });
  }
  if (typeof shouldBeDir !== "undefined") {
    var isDirectory = __webpack_require__(/*! ./index */ "./node_modules/@skpm/fs/index.js").lstatSync(path).isDirectory();
    if (isDirectory && !shouldBeDir) {
      return fsError("EISDIR", {
        path: path,
        syscall: syscall || "read",
      });
    } else if (!isDirectory && shouldBeDir) {
      return fsError("ENOTDIR", {
        path: path,
        syscall: syscall || "read",
      });
    }
  }
  return new Error(err || "Unknown error while manipulating " + path);
};

module.exports.encodingFromOptions = function encodingFromOptions(
  options,
  defaultValue
) {
  return options && options.encoding
    ? String(options.encoding)
    : options
    ? String(options)
    : defaultValue;
};

module.exports.NOT_IMPLEMENTED = function NOT_IMPLEMENTED(name) {
  return function () {
    throw new Error(
      "fs." +
        name +
        " is not implemented yet. If you feel like implementing it, any contribution will be gladly accepted on https://github.com/skpm/fs"
    );
  };
};


/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/classNameList.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/classNameList.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList = [
    'rat',
    'valley',
    'pence',
    'unconditional',
    'feather',
    'zoo',
    'build',
    'field',
    'nationality',
    'salad',
    'ferry',
    'building',
    'limit',
    'stewardess',
    'water',
    'manage',
    'path',
    'example',
    'purple',
    'valid',
    'hurry',
    'argue',
    'accommodation',
    'mixture',
    'time',
    'picnic',
    'consensus',
    'smoke',
    'protection',
    'conscience',
    'sense',
    'owe',
    'chant',
    'term',
    'urban',
    'considerate',
    'afraid',
    'bandage',
    'table',
    'tennis',
    'candidate',
    'combine',
    'hurricane',
    'independent',
    'cancer',
    'choose',
    'town',
    'desire',
    'visual',
    'life',
    'submit',
    'physics',
    'meaning',
    'country',
    'half',
    'joy',
    'adult',
    'servant',
    'care',
    'search',
    'same',
    'furniture',
    'agree',
    'heart',
    'unemployment',
    'nearly',
    'bond',
    'master',
    'rise',
    'punish',
    'monument',
    'stick',
    'tax',
    'personnel',
    'fact',
    'therefore',
    'ox',
    'ocean',
    'eagle',
    'cloud',
    'fibre',
    'fiber',
    'bingo',
    'fortunate',
    'mommy',
    'wage',
    'along',
    'surplus',
    'add',
    'outdoors',
    'paper',
    'fetch',
    'church',
    'edition',
    'weather',
    'opera',
    'dot',
    'service',
    'disease',
    'symphony',
    'survival',
    'thus',
    'satisfy',
    'arise',
    'sorry',
    'dinosaur',
    'properly',
    'story',
    'appetite',
    'pronounce',
    'socialist',
    'certain',
    'pea',
    'bacterium',
    'contrary',
    'roof',
    'carve',
    'essay',
    'reward',
    'convenience',
    'export',
    'fit',
    'racial',
    'herself',
    'bid',
    'novelist',
    'safety',
    'off',
    'east',
    'misunderstand',
    'razor',
    'waiting',
    'room',
    'short',
    'surprise',
    'pleasure',
    'tidy',
    'garage',
    'analyse',
    'Am',
    'analyze',
    'notice',
    'violinist',
    'ice',
    'deliberately',
    'alike',
    'perfect',
    'broom',
    'welfare',
    'keyboard',
    'dad',
    'daddy',
    'approximately',
    'hopeful',
    'habit',
    'confidential',
    'complex',
    'recreation',
    'data',
    'kindergarten',
    'sniff',
    'we',
    'studio',
    'overlook',
    'barbershop',
    'minority',
    'escape',
    'jeans',
    'videophone',
    'adapt',
    'report',
    'recorder',
    'betray',
    'vast',
    'arrow',
    'usual',
    'eat',
    'spread',
    'agent',
    'spare',
    'conclusion',
    'rock',
    'hometown',
    'bakery',
    'conclude',
    'worry',
    'operate',
    'floor',
    'area',
    'noise',
    'chairwoman',
    'classroom',
    'communicate',
    'attack',
    'event',
    'dream',
    'criminal',
    'authentic',
    'scarf',
    'senior',
    'OK',
    'okay',
    'description',
    'representative',
    'carriage',
    'sacred',
    'run',
    'software',
    'diet',
    'copy',
    'eastern',
    'carbon',
    'sow',
    'universe',
    'folk',
    'tendency',
    'camp',
    'likely',
    'alive',
    'harvest',
    'devote',
    'marathon',
    'Christian',
    'government',
    'Franc',
    'seminar',
    'departure',
    'forward',
    'person',
    'violence',
    'basketball',
    'gas',
    'fox',
    'advance',
    'majority',
    'credit',
    'relief',
    'prefer',
    'qualification',
    'sand',
    'lift',
    'attain',
    'fantasy',
    'trap',
    'interesting',
    'nothing',
    'civilian',
    'besides',
    'homework',
    'container',
    'fireworks',
    'toy',
    'focus',
    'decide',
    'frighten',
    'cleaner',
    'autumn',
    'beneath',
    'hostess',
    'climb',
    'expert',
    'super',
    'significance',
    'hair',
    'phrase',
    'authority',
    'agricultural',
    'explore',
    'framework',
    'caf',
    'consequence',
    'geography',
    'your',
    'match',
    'hall',
    'ship',
    'suppose',
    'signature',
    'borrow',
    'create',
    'companion',
    'direction',
    'except',
    'big',
    'nutrition',
    'anecdote',
    'string',
    'breast',
    'flashlight',
    'unconscious',
    'champion',
    'funeral',
    'since',
    'how',
    'jacket',
    'robot',
    'like',
    'pleasant',
    'airport',
    'compensate',
    'more',
    'sandwich',
    'boring',
    'seldom',
    'jazz',
    'mile',
    'apologize',
    'shout',
    'commit',
    'can',
    'institution',
    'upstairs',
    'abortion',
    'storage',
    'bravery',
    'envelope',
    'amazing',
    'disappoint',
    'advantage',
    'lab',
    'laboratory',
    'foreign',
    'conduct',
    'prison',
    'agreement',
    'botany',
    'famous',
    'mix',
    'level',
    'go',
    'urgent',
    'scholar',
    'jet',
    'cottage',
    'sigh',
    'maid',
    'pop',
    'popular',
    'advertisement',
    'western',
    'course',
    'wound',
    'together',
    'reservation',
    'because',
    'realise',
    'grateful',
    'huge',
    'turn',
    'knowledge',
    'arrive',
    'seaside',
    'assessment',
    'kilometre',
    'plug',
    'impress',
    'else',
    'fail',
    'discuss',
    'temporary',
    'volcano',
    'call',
    'asleep',
    'amateur',
    'material',
    'fragrant',
    'slave',
    'itself',
    'stupid',
    'central',
    'evening',
    'collision',
    'highway',
    'staff',
    'Asia',
    'medicine',
    'shop',
    'pump',
    'discourage',
    'political',
    'continent',
    'bless',
    'jeep',
    'account',
    'zoom',
    'content',
    'trousers',
    'tonight',
    'spend',
    'astronaut',
    'belt',
    'yet',
    'result',
    'gravity',
    'worth',
    'prize',
    'up',
    'quarrel',
    'born',
    'ring',
    'guard',
    'driver',
    'otherwise',
    'repair',
    'back',
    'reasonable',
    'could',
    'disappear',
    'shy',
    'questionnaire',
    'cheers',
    'interview',
    'kindness',
    'gold',
    'gradual',
    'quit',
    'medical',
    'waste',
    'airmail',
    'expensive',
    'wisdom',
    'favourite',
    'attitude',
    'touch',
    'soil',
    'especially',
    'who',
    'suck',
    'breath',
    'rice',
    'stout',
    'version',
    'oxygen',
    'grey',
    'humorous',
    'burn',
    'regard',
    'seaweed',
    'tremble',
    'pillow',
    'garlic',
    'straw',
    'pineapple',
    'hot',
    'tradition',
    'rescue',
    'again',
    'violent',
    'as',
    'terror',
    'fortune',
    'until',
    'pride',
    'foster',
    'home',
    'peace',
    'shorts',
    'vertical',
    'jam',
    'hatch',
    'atmosphere',
    'stadium',
    'main',
    'people',
    'light',
    'injure',
    'witness',
    'component',
    'weekly',
    'right',
    'dialogue',
    'audience',
    'acquire',
    'store',
    'decline',
    'very',
    'user',
    'spit',
    'undertake',
    'terrible',
    'vacation',
    'much',
    'handbag',
    'saucer',
    'officer',
    'whisper',
    'pleased',
    'greedy',
    'horse',
    'little',
    'cloudy',
    'mainland',
    'fee',
    'taste',
    'alternative',
    'opening',
    'toothache',
    'universal',
    'cow',
    'wheel',
    'pipe',
    'profession',
    'dig',
    'conversation',
    'gain',
    'subjective',
    'thunder',
    'clay',
    'hill',
    'give',
    'budget',
    'against',
    'cage',
    'on',
    'unfit',
    'scene',
    'pint',
    'freezing',
    'oilfield',
    'onion',
    'seed',
    'outstanding',
    'wool',
    'crazy',
    'sew',
    'shelf',
    'freeze',
    'speed',
    'behaviour',
    'behavior',
    'TV',
    'television',
    'chest',
    'knock',
    'something',
    'directory',
    'platform',
    'sightseeing',
    'bay',
    'foreigner',
    'another',
    'oh',
    'zero',
    'boy',
    'handsome',
    'rest',
    'study',
    'front',
    'rely',
    'aside',
    'appeal',
    'competence',
    'fresh',
    'question',
    'south',
    'annoy',
    'pretty',
    'conference',
    'communist',
    'sunlight',
    'cure',
    'slide',
    'glance',
    'paint',
    'wine',
    'dive',
    'admire',
    'existence',
    'bureaucratic',
    'price',
    'skill',
    'nor',
    'enthusiastic',
    'volleyball',
    'dam',
    'delicate',
    'someone',
    'post',
    'father',
    'disgusting',
    'radioactive',
    'offense',
    'passer',
    'by',
    'what',
    'human',
    'guarantee',
    'husband',
    'island',
    'painting',
    'nowadays',
    'hardship',
    'counter',
    'collar',
    'appropriate',
    'thriller',
    'repeat',
    'perform',
    'unbelievable',
    'dozen',
    'Easter',
    'noisy',
    'see',
    'idea',
    'uncomfortable',
    'load',
    'reception',
    'look',
    'value',
    'chess',
    'thunderstorm',
    'convenient',
    'kilo',
    'cassette',
    'toward',
    's',
    'wood',
    'theft',
    'chef',
    'businessman',
    'silly',
    'tomato',
    'brunch',
    'laugh',
    'suitcase',
    'coin',
    'spade',
    'mental',
    'comfort',
    'receiver',
    'Africa',
    'percentage',
    'wrong',
    'correspond',
    'reflect',
    'spy',
    'somebody',
    'religious',
    'last',
    'shade',
    'perfume',
    'pity',
    'trouble',
    'necklace',
    'pancake',
    'interest',
    'hen',
    'dynasty',
    'single',
    'puzzle',
    'head',
    'mean',
    'break',
    'among',
    'certificate',
    'crowd',
    'wander',
    'box',
    'fix',
    'clinic',
    'grammar',
    'ball',
    'translate',
    'delete',
    'cheat',
    'adjust',
    'ill',
    'swing',
    'privilege',
    'quarter',
    'brain',
    'orbit',
    'attach',
    'blind',
    'wild',
    'plastic',
    'adaption',
    'lively',
    'reply',
    'yours',
    'assume',
    'saying',
    'composition',
    'sunshine',
    'union',
    'angle',
    'legal',
    'death',
    'observe',
    'splendid',
    'scar',
    'buy',
    'kill',
    'rent',
    'distinguish',
    'lead',
    'vest',
    'effect',
    'mud',
    'refer',
    'globe',
    'zip',
    'power',
    'marriage',
    'brilliant',
    'pick',
    'speech',
    'ancient',
    'director',
    'replace',
    'pig',
    'autonomous',
    'red',
    'output',
    'die',
    'gifted',
    'station',
    'apple',
    'teamwork',
    'revision',
    'revolution',
    'surgeon',
    'link',
    'average',
    'section',
    'fluency',
    'underground',
    'number',
    'amusement',
    'develop',
    'sword',
    'star',
    'greengrocer',
    'lucky',
    'eraser',
    'rainbow',
    'anxious',
    'beyond',
    'news',
    'waitress',
    'reference',
    'switch',
    'caption',
    'rough',
    'rail',
    'photo',
    'photograph',
    'parrot',
    'must',
    'instant',
    'centre',
    'determine',
    'street',
    'voyage',
    'Ms',
    'patient',
    'wake',
    'worker',
    'Internet',
    'coast',
    'benefit',
    'with',
    'already',
    'face',
    'none',
    'broad',
    'feed',
    'shoot',
    'across',
    'male',
    'Antarctic',
    'zone',
    'continue',
    'blackboard',
    'join',
    'defend',
    'tentative',
    'channel',
    'technical',
    'snow',
    'difficult',
    'bird',
    'widespread',
    'war',
    'pear',
    'lot',
    'excuse',
    'actress',
    'tablet',
    'score',
    'pronunciation',
    'such',
    'accent',
    'chat',
    'deer',
    'memorial',
    'within',
    'tent',
    'microwave',
    'success',
    'luggage',
    'ending',
    'noodle',
    'vain',
    'dentist',
    'district',
    'control',
    'bill',
    'professor',
    'indicate',
    'gentle',
    'helicopter',
    'airplane',
    'please',
    'allowance',
    'forehead',
    'stable',
    'fast',
    'lake',
    'quilt',
    'agenda',
    'command',
    'photographer',
    'monitor',
    'gift',
    'middle',
    'means',
    'glare',
    'breakfast',
    'mad',
    'currency',
    'detective',
    'VCD',
    'visual',
    'compact',
    'disk',
    'prisoner',
    'dinner',
    'helmet',
    'handwriting',
    'thankful',
    'enough',
    'psychology',
    'skin',
    'amuse',
    'cut',
    'poisonous',
    'hearing',
    'praise',
    'flight',
    'ash',
    'crime',
    'troublesome',
    'coke',
    'circulate',
    'address',
    'numb',
    'drunk',
    'resign',
    'menu',
    'congratulate',
    'gay',
    'plain',
    'affair',
    'chicken',
    'deed',
    'pure',
    'cover',
    'error',
    'relationship',
    'snowy',
    'ticket',
    'subject',
    'throughout',
    'applicant',
    'ceiling',
    'manner',
    'type',
    'remark',
    'mop',
    'smog',
    'lid',
    'topic',
    'literature',
    'garment',
    'squirrel',
    'aloud',
    'next',
    'barrier',
    'sharp',
    'declare',
    'headline',
    'appreciation',
    'vivid',
    'well',
    'a',
    'm',
    'am',
    'A',
    'M',
    'AM',
    'thief',
    'skirt',
    'wildlife',
    'cater',
    'tissue',
    'leader',
    'hide',
    'bit',
    'pioneer',
    'nation',
    'disagree',
    'relevant',
    'drawer',
    'dip',
    'treatment',
    'regular',
    'duty',
    'metre',
    'download',
    'canal',
    'vague',
    'foot',
    'letter',
    'sadness',
    'skate',
    'motherland',
    'dress',
    'some',
    'major',
    'lie',
    'tractor',
    'plus',
    'honour',
    'bow',
    'public',
    'reform',
    'fill',
    'mathematics',
    'math',
    'maths',
    'admission',
    'throat',
    'civil',
    'goat',
    'watch',
    'environment',
    'taxpayer',
    'whether',
    'anxiety',
    'carrier',
    'captain',
    'apology',
    'broadcast',
    'compete',
    'matter',
    'decision',
    'unwilling',
    'Europe',
    'coincidence',
    'circle',
    'oppose',
    'forty',
    'arrest',
    'shore',
    'unit',
    'origin',
    'use',
    'inn',
    'electronic',
    'volunteer',
    'team',
    'burst',
    'thread',
    'innocent',
    'skyscraper',
    'hero',
    'twin',
    'tiny',
    'expense',
    'surface',
    'swift',
    'thermos',
    'tutor',
    'dimension',
    'god',
    'behave',
    'jog',
    'wax',
    'bad',
    'outside',
    'vital',
    'leaf',
    'Asian',
    'pet',
    'each',
    'no',
    'theater',
    'think',
    'storm',
    'neighbourhood',
    'clock',
    'dare',
    'explode',
    'peaceful',
    'pale',
    'assumption',
    'typewriter',
    'concentrate',
    'several',
    'bell',
    'bitter',
    'reason',
    'dance',
    'pest',
    'shame',
    'bored',
    'point',
    'analysis',
    'bus',
    'identification',
    'need',
    'spoon',
    'nephew',
    'physician',
    'judgment',
    'gallon',
    'meeting',
    'tobacco',
    'wash',
    'relation',
    'breathe',
    'clean',
    'chart',
    'faith',
    'hook',
    'percent',
    'instruction',
    'daughter',
    'intention',
    'yourself',
    'booth',
    'secure',
    'semicircle',
    'voice',
    'food',
    'strait',
    'addicted',
    'cartoon',
    'prepare',
    'shave',
    'fight',
    'apparent',
    'metal',
    'pink',
    'passive',
    'lovely',
    'transparent',
    'click',
    'outward',
    's',
    'adolescent',
    'than',
    'fire',
    'sick',
    'grasp',
    'ashamed',
    'black',
    'interpreter',
    'weed',
    'from',
    'beauty',
    'schoolboy',
    'towel',
    'beg',
    'biochemistry',
    'into',
    'symptom',
    'subscribe',
    'shrink',
    'allow',
    'accountant',
    'disturb',
    'avenue',
    'meet',
    'message',
    'bread',
    'sheet',
    'secret',
    'whenever',
    'pardon',
    'physical',
    'athlete',
    'requirement',
    'glory',
    'surround',
    'violin',
    'aluminium',
    'birthplace',
    'nuclear',
    'equal',
    'most',
    'often',
    'soup',
    'rigid',
    'adjustment',
    'blue',
    'abstract',
    'steady',
    'rope',
    'sink',
    'goose',
    'place',
    'truck',
    'job',
    'wide',
    'compromise',
    'arrival',
    'rooster',
    'tick',
    'intelligence',
    'theme',
    'wait',
    'postpone',
    'hole',
    'deserve',
    'institute',
    'surrounding',
    'twice',
    'coal',
    'draw',
    'yard',
    'destroy',
    'rag',
    'correction',
    'ownership',
    'predict',
    'agency',
    'I',
    'automatic',
    'guess',
    'lunch',
    'rugby',
    'burden',
    'enter',
    'discussion',
    'struggle',
    'editor',
    'reduce',
    'prohibit',
    'persuade',
    'day',
    'sharpener',
    'research',
    'greet',
    'educator',
    'penny',
    'get',
    'cheap',
    'lose',
    'customs',
    'salty',
    'height',
    'find',
    'above',
    'aid',
    'Arctic',
    'fuel',
    'socialism',
    'bend',
    'terminal',
    'compulsory',
    'winner',
    'grass',
    'sweet',
    'stream',
    'irrigation',
    'busy',
    'low',
    'swap',
    'musician',
    'cuisine',
    'sacrifice',
    'recommend',
    'soldier',
    'ruin',
    'possible',
    'anyway',
    'judge',
    'triangle',
    'mother',
    'attraction',
    'pool',
    'birthday',
    'brown',
    'howl',
    'personally',
    'offshore',
    'application',
    'dioxide',
    'suite',
    'obvious',
    'wife',
    'ham',
    'speaker',
    'mistake',
    'least',
    'game',
    'sympathy',
    'league',
    'clumsy',
    'millionaire',
    'tournament',
    'nod',
    'socket',
    'willing',
    'blame',
    'status',
    'sincerely',
    'emergency',
    'nature',
    'seal',
    'pollute',
    'sometimes',
    'contribute',
    'poster',
    'postage',
    'routine',
    'kettle',
    'piece',
    'listen',
    'lesson',
    'painter',
    'neither',
    'postcode',
    'electric',
    'competition',
    'leather',
    'seem',
    'sausage',
    'format',
    'bamboo',
    'expose',
    'protect',
    'accident',
    'cubic',
    'yoghurt',
    'dictation',
    'plate',
    'inspire',
    'grandson',
    'stop',
    'anyhow',
    'merciful',
    'bathroom',
    'journey',
    'patience',
    'cinema',
    'chair',
    'survive',
    'change',
    'litre',
    'onto',
    'dirty',
    'mineral',
    'gather',
    'milk',
    'grill',
    'wall',
    'object',
    'spot',
    'ready',
    'patent',
    'land',
    'policewoman',
    'media',
    'tale',
    'guest',
    'positive',
    'precise',
    'march',
    'speed',
    'o',
    'clock',
    'donate',
    'want',
    'polite',
    'troop',
    'hotel',
    'classify',
    'fingernail',
    'facial',
    'classmate',
    'graduation',
    'pattern',
    'card',
    'powerful',
    'brewery',
    'homeland',
    'distant',
    'trust',
    'stage',
    'is',
    'sell',
    'import',
    'convince',
    'suffering',
    'pork',
    'grocer',
    'satellite',
    'statistics',
    'himself',
    'defence',
    'rate',
    'tense',
    'army',
    'factory',
    'necessary',
    'agriculture',
    'impression',
    'accustomed',
    'few',
    'flow',
    'hold',
    'moustache',
    'corrupt',
    'tasty',
    'swear',
    'condition',
    'steep',
    'courage',
    'marry',
    'extreme',
    'those',
    'that',
    'tourism',
    'ground',
    'glove',
    'contain',
    'chain',
    'midnight',
    'obtain',
    'will',
    'acid',
    'stair',
    'update',
    'pay',
    'evidence',
    'carpet',
    'advocate',
    'cheer',
    'blow',
    'reject',
    'comprehension',
    'bathe',
    'dumpling',
    'high',
    'my',
    'airspace',
    'promise',
    'athletic',
    'headmistress',
    'slim',
    'after',
    'afterward',
    's',
    'refuse',
    'organ',
    'cautious',
    'advise',
    'fountain',
    'wet',
    'PE',
    'physical',
    'education',
    'remind',
    'whole',
    'down',
    'weekend',
    'punctuation',
    'shopping',
    'flag',
    'violate',
    'premier',
    'slice',
    'hunt',
    'healthy',
    'respond',
    'approve',
    'peach',
    'avoid',
    'sort',
    'daily',
    'trick',
    'bean',
    'curd',
    'many',
    'approach',
    'enquiry',
    'rude',
    'slow',
    'cab',
    'band',
    'transform',
    'paragraph',
    'freeway',
    'production',
    'international',
    'invent',
    'security',
    'rectangle',
    'his',
    'treasure',
    'govern',
    'discount',
    'fantastic',
    'sight',
    'delay',
    'restaurant',
    'independence',
    'spoken',
    'might',
    'which',
    'accept',
    'read',
    'every',
    'scientist',
    'so',
    'fever',
    'acre',
    'argument',
    'holy',
    'crew',
    'door',
    'today',
    'meal',
    'walk',
    'scenery',
    'found',
    'gesture',
    'come',
    'ample',
    'due',
    'tree',
    'meanwhile',
    'try',
    'construction',
    'intend',
    'nervous',
    'here',
    'divide',
    'page',
    'movement',
    'decrease',
    'raise',
    'bench',
    'fence',
    'manager',
    'interval',
    'bowl',
    'heel',
    'disability',
    'case',
    'sweat',
    'link',
    'exist',
    'mourn',
    'performance',
    'glad',
    'ancestor',
    'gun',
    'recognise',
    'different',
    'toast',
    'civilization',
    'language',
    'flee',
    'zebra',
    'select',
    'never',
    'broken',
    'mutton',
    'video',
    'twist',
    'shadow',
    'stocking',
    'algebra',
    'help',
    'cookie',
    'elegant',
    'endless',
    'centigrade',
    'glue',
    'concern',
    'basic',
    'wallet',
    'wave',
    'dish',
    'spelling',
    'know',
    'goods',
    'practise',
    'clothes',
    'scientific',
    'instead',
    'teenager',
    'welcome',
    'careless',
    'weigh',
    'parking',
    'human',
    'being',
    'used',
    'north',
    'chopsticks',
    'principle',
    'loud',
    'African',
    'size',
    'strike',
    'biology',
    'absence',
    'deaf',
    'rare',
    'unrest',
    'saleswoman',
    'royal',
    'below',
    'movie',
    'bowling',
    'resist',
    'kingdom',
    'powder',
    'condemn',
    'capsule',
    'let',
    'practical',
    'paddle',
    'temperature',
    'apart',
    'butterfly',
    'stand',
    'concert',
    'maximum',
    'simplify',
    'sleep',
    'spring',
    'tooth',
    'exercise',
    'reach',
    'overhead',
    'heaven',
    'dignity',
    'believe',
    'commitment',
    'parent',
    'tired',
    'tennis',
    'flesh',
    'ping',
    'pong',
    'circuit',
    'decoration',
    'review',
    'courtyard',
    'potato',
    'various',
    'destination',
    'appoint',
    'affection',
    'severe',
    'bush',
    'conductor',
    'sceptical',
    'mask',
    'why',
    'poor',
    'great',
    'solid',
    'permanent',
    'nest',
    'dust',
    'assess',
    'impossible',
    'would',
    'fat',
    'rapid',
    'northeast',
    'oral',
    'typical',
    'harmful',
    'darkness',
    'defeat',
    'spokeswoman',
    'beneficial',
    'wherever',
    'skip',
    'but',
    'Olympic',
    'confuse',
    'preference',
    'artificial',
    'expression',
    'drink',
    'check',
    'ban',
    'interrupt',
    'divorce',
    'variety',
    'altogether',
    'anniversary',
    'herb',
    'jump',
    'foolish',
    'quick',
    'he',
    'deposit',
    'at',
    'train',
    'shabby',
    'ripen',
    'worldwide',
    'computer',
    'sob',
    'kick',
    'thirst',
    'partly',
    'upset',
    'chalk',
    'diagram',
    'appear',
    'lamp',
    'if',
    'lorry',
    'congratulation',
    'forgetful',
    'castle',
    'skatebroad',
    'toothpaste',
    'ordinary',
    'piano',
    'collection',
    'emperor',
    'remove',
    'unlike',
    'encouragement',
    'bungalow',
    'lazy',
    'measure',
    'perhaps',
    'native',
    'ought',
    'wag',
    'become',
    'astronomer',
    'contemporary',
    'villager',
    'rewind',
    'when',
    'receive',
    'other',
    'salary',
    'potential',
    'compass',
    'animal',
    'ear',
    'pension',
    'annual',
    'salesman',
    'month',
    'behind',
    'drug',
    'creature',
    'hire',
    'respect',
    'granddaughter',
    'partner',
    'jaw',
    'mind',
    'total',
    'alarm',
    'aggressive',
    'mobile',
    'attention',
    'require',
    'air',
    'basement',
    'belong',
    'equipment',
    'recite',
    'standard',
    'straight',
    'chief',
    'decade',
    'shot',
    'earthquake',
    'scare',
    'PC',
    'personal',
    'computer',
    'access',
    'inform',
    'rain',
    'envy',
    'feeling',
    'keep',
    'flour',
    'yell',
    'rid',
    'badminton',
    'newspaper',
    'aim',
    'disadvantage',
    'admirable',
    'stress',
    'unable',
    'occupy',
    'laughter',
    'referee',
    'part',
    'introduce',
    'time',
    'pulse',
    'information',
    'soon',
    'theoretical',
    'junior',
    'journalist',
    'chemist',
    'pace',
    'frequent',
    'explicit',
    'bounce',
    'cat',
    'happen',
    'chemistry',
    'sharpen',
    'safe',
    'form',
    'steal',
    'toilet',
    'clothing',
    'prescription',
    'spell',
    'advice',
    'belief',
    'differ',
    'graduate',
    'seek',
    'spirit',
    'nail',
    'female',
    'development',
    'bottle',
    'blank',
    'round',
    'host',
    'cattle',
    'barber',
    'basis',
    'bite',
    'phone',
    'telephone',
    'parallel',
    'friend',
    'gym',
    'gymnasium',
    'equip',
    'way',
    'occupation',
    'appearance',
    'health',
    'bomb',
    'tour',
    'print',
    'addition',
    'apartment',
    'shut',
    'supper',
    'play',
    'guilty',
    'beast',
    'diary',
    'local',
    'dog',
    'progress',
    'boxing',
    'line',
    'diverse',
    'breakthrough',
    'dictionary',
    'supermarket',
    'shower',
    'wise',
    'controversial',
    'background',
    'spiritual',
    'handle',
    'bridge',
    'succeed',
    'calculate',
    'private',
    'reality',
    'accuracy',
    'smart',
    'sad',
    'butter',
    'contradictory',
    'passenger',
    'contribution',
    'beautiful',
    'sideway',
    'brand',
    'maybe',
    'easy',
    'close',
    'bunch',
    'actual',
    'statesman',
    'province',
    'fierce',
    'Mrs',
    'net',
    'age',
    'owner',
    'silver',
    'per',
    'deep',
    'summary',
    'flash',
    'citizen',
    'Christmas',
    'opposite',
    'blanket',
    'pregnant',
    'one',
    'anchor',
    'root',
    'wear',
    'participate',
    'firm',
    'neck',
    'request',
    'refrigerator',
    'pile',
    'changeable',
    'brave',
    'technology',
    'magazine',
    'the',
    'sparrow',
    'cook',
    'evaluate',
    'traditional',
    'man',
    'profit',
    'random',
    'bean',
    'botanical',
    'natural',
    'night',
    'double',
    'shortly',
    'lounge',
    'teapot',
    'scholarship',
    'tease',
    'warehouse',
    'quiet',
    'bag',
    'side',
    'uniform',
    'pray',
    'just',
    'pupil',
    'whale',
    'helpful',
    'tall',
    'hers',
    'outcome',
    'eager',
    'title',
    'northern',
    'bother',
    'silence',
    'sensitive',
    'scissors',
    'oneself',
    'sail',
    'arrange',
    'postcard',
    'ray',
    'clear',
    'kilogram',
    'typhoon',
    'dismiss',
    'law',
    'disappointed',
    'failure',
    'contradict',
    'primitive',
    'artist',
    'boss',
    'Catholic',
    'chemical',
    'aunt',
    'science',
    'operator',
    'outer',
    'dangerous',
    'birth',
    'arm',
    'improve',
    'separate',
    'expand',
    'America',
    'rubber',
    'police',
    'wire',
    'hurt',
    'virus',
    'textbook',
    'away',
    'winter',
    'carry',
    'acknowledge',
    'block',
    'cycle',
    'fisherman',
    'housework',
    'freedom',
    'discrimination',
    'normal',
    'official',
    'reserve',
    'refresh',
    'accurate',
    'finance',
    'cross',
    'everybody',
    'enjoyable',
    'visit',
    'modem',
    'word',
    'raincoat',
    'nationwide',
    'learn',
    'injury',
    'brother',
    'garbage',
    'tomb',
    'unfair',
    'insect',
    'her',
    'jar',
    'vegetable',
    'she',
    'silent',
    'pack',
    'clap',
    'pain',
    'able',
    'remote',
    'heat',
    'dormitory',
    'worthy',
    'choke',
    'send',
    'both',
    'industry',
    'fall',
    'fragile',
    'maple',
    'bank',
    'suspension',
    'minus',
    'mouse',
    'seize',
    'fax',
    'sing',
    'smell',
    'foggy',
    'occur',
    'pie',
    'cushion',
    'absurd',
    'examine',
    'thin',
    'yellow',
    'salt',
    'sea',
    'free',
    'cream',
    'hungry',
    'elect',
    'policeman',
    'confident',
    'drive',
    'room',
    'nobody',
    'board',
    'cash',
    'important',
    'blouse',
    'name',
    'acquisition',
    'write',
    'article',
    'sheep',
    'marble',
    'self',
    'lung',
    'incident',
    'juice',
    'vinegar',
    'overcoat',
    'tea',
    'simple',
    'snake',
    'concrete',
    'wealth',
    'hand',
    'encourage',
    'swell',
    'good',
    'record',
    'pair',
    'package',
    'entry',
    'extraordinary',
    'harmony',
    'ton',
    'him',
    'quite',
    'attract',
    'publish',
    'uncertain',
    'invitation',
    'whose',
    'enjoy',
    'conservative',
    'stare',
    'spray',
    'money',
    'garden',
    'either',
    'map',
    'e',
    'mail',
    'email',
    'theory',
    'noble',
    'nowhere',
    'produce',
    'sunburnt',
    'shape',
    'too',
    'receipt',
    'me',
    'ski',
    'son',
    'fur',
    'date',
    'optimistic',
    'toothbrush',
    'cap',
    'vote',
    'mirror',
    'shoe',
    'butcher',
    'specialist',
    'cake',
    'bachelor',
    'fruit',
    'tongue',
    'pyramid',
    'kite',
    'carpenter',
    'supreme',
    'cousin',
    'special',
    'somehow',
    'honest',
    'generation',
    'figure',
    'capital',
    'friendship',
    'pencil',
    'lantern',
    'social',
    'lame',
    'drop',
    'finger',
    'allocate',
    'boat',
    'farmer',
    'turning',
    'brochure',
    'possess',
    'pull',
    'magic',
    'save',
    'goal',
    'schoolmate',
    'period',
    'smooth',
    'wealthy',
    'merely',
    'serious',
    'dawn',
    'cup',
    'consume',
    'pond',
    'kind',
    'cough',
    'somewhere',
    'mine',
    'soccer',
    'politician',
    'anywhere',
    'second',
    'alphabet',
    'ripe',
    'hopeless',
    'performer',
    'steam',
    'digital',
    'biography',
    'abundant',
    'canteen',
    'introduction',
    'past',
    'mature',
    'quiz',
    'planet',
    'ourselves',
    'start',
    'seashell',
    'insurance',
    'adventure',
    'enemy',
    'appendix',
    'cancel',
    'unite',
    'damage',
    'rob',
    'method',
    'immediately',
    'fun',
    'brief',
    'electricity',
    'football',
    'exit',
    'morning',
    'liberty',
    'swim',
    'assistant',
    'moral',
    'book',
    'umbrella',
    'operation',
    'however',
    'hunger',
    'order',
    'consult',
    'unusual',
    'preserve',
    'headache',
    'teach',
    'palace',
    'desperate',
    'accessible',
    'lay',
    'am',
    'cause',
    'lemon',
    'motto',
    'stainless',
    'slip',
    'mosquito',
    'small',
    'understand',
    'talent',
    'activity',
    'astonish',
    'regardless',
    'training',
    'season',
    'although',
    'fiction',
    'take',
    'key',
    'bonus',
    'hard',
    'republic',
    'railway',
    'early',
    'final',
    'sit',
    'adequate',
    'accelerate',
    'education',
    'voluntary',
    'desert',
    'pollution',
    'pianist',
    'via',
    'settlement',
    'receptionist',
    'alongside',
    'out',
    'arithmetic',
    'foresee',
    'dilemma',
    'madam',
    'madame',
    'purse',
    'exhibition',
    'popular',
    'year',
    'dynamic',
    'CD',
    'compact',
    'disk',
    'awkward',
    'cabbage',
    'conservation',
    'by',
    'leak',
    'note',
    'strange',
    'inspect',
    'tube',
    'symbol',
    'sleepy',
    'acquaintance',
    'slight',
    'scan',
    'national',
    'shopkeeper',
    'sky',
    'behalf',
    'engine',
    'recover',
    'yes',
    'fine',
    'teacher',
    'accomplish',
    'explain',
    'tram',
    'company',
    'transport',
    'fellow',
    'attend',
    'colour',
    'bury',
    'purchase',
    'quake',
    'act',
    'follow',
    'grocery',
    'crash',
    'plane',
    'systematic',
    'network',
    'fundamental',
    'trade',
    'superior',
    'hotdog',
    'dial',
    'complete',
    'cheerful',
    'frontier',
    'battle',
    'pause',
    'warmth',
    'ruler',
    'mild',
    'explanation',
    'drawback',
    'proud',
    'cigarette',
    'strong',
    'tune',
    'offer',
    'long',
    'thought',
    'absorb',
    'mend',
    'invention',
    'victim',
    'responsibility',
    'minister',
    'tell',
    'sun',
    'rot',
    'beside',
    'approval',
    'radium',
    'pressure',
    'sorrow',
    'consider',
    'diamond',
    'drag',
    'apply',
    'useless',
    'register',
    'depth',
    'difference',
    'X',
    'ray',
    'X',
    'lack',
    'sentence',
    'tend',
    'announce',
    'division',
    'initial',
    'income',
    'all',
    'fist',
    'abolish',
    'them',
    'they',
    'grandma',
    'grandmother',
    'stand',
    'bicycle',
    'fear',
    'engineer',
    'arbitrary',
    'spoonful',
    'hang',
    'tape',
    'particular',
    'assistance',
    'mail',
    'hi',
    'settle',
    'forecast',
    'comment',
    'lady',
    'nursery',
    'radiation',
    'passport',
    'prove',
    'road',
    'house',
    'while',
    'row',
    'precious',
    'arch',
    'mass',
    'grape',
    'poison',
    'statement',
    'mouth',
    'merchant',
    'European',
    'roundabout',
    'wish',
    'enlarge',
    'AIDS',
    'abuse',
    'narrow',
    'grandparents',
    'action',
    'quality',
    'beach',
    'acute',
    'yesterday',
    'general',
    'far',
    'celebration',
    'react',
    'elder',
    'doctor',
    'stone',
    'loss',
    'playground',
    'cheque',
    'sneeze',
    'distinction',
    'gymnastics',
    'concept',
    'excellent',
    'common',
    'commercial',
    'demand',
    'presentation',
    'choir',
    'white',
    'stateswoman',
    'southern',
    'crossroads',
    'kitchen',
    'hobby',
    'preview',
    'win',
    'west',
    'hour',
    'haircut',
    'relay',
    'humour',
    'text',
    'possibility',
    'literary',
    'effort',
    'sir',
    'shark',
    'T',
    'shirt',
    'T',
    'art',
    'grow',
    'forever',
    'banana',
    'opinion',
    'awake',
    'invite',
    'administration',
    'slavery',
    'bishop',
    'diploma',
    'attractive',
    'between',
    'watermelon',
    'deadline',
    'car',
    'elephant',
    'minimum',
    'hammer',
    'baby',
    'exchange',
    'kangaroo',
    'crossing',
    'do',
    'work',
    'ambition',
    'base',
    'loaf',
    'president',
    'businesswoman',
    'merry',
    'minibus',
    'insure',
    'drum',
    'dark',
    'mistaken',
    'Moslem',
    'Muslim',
    'weak',
    'hunter',
    'rainy',
    'degree',
    'club',
    'scold',
    'session',
    'whom',
    'tomorrow',
    'cooker',
    'process',
    'library',
    'beat',
    'neighbour',
    'truth',
    'recent',
    'author',
    'dollar',
    'abandon',
    'beard',
    'silk',
    'BC',
    'tight',
    'bat',
    'victory',
    'honey',
    'substitute',
    'themselves',
    'zipper',
    'licence',
    'chapter',
    'unique',
    'hardly',
    'nut',
    'lawyer',
    'aware',
    'being',
    'alcoholic',
    'vehicle',
    'campaign',
    'upper',
    'lamb',
    'track',
    'branch',
    'large',
    'optional',
    'bacon',
    'whichever',
    'fasten',
    'convey',
    'problem',
    'pilot',
    'sickness',
    'hardworking',
    'atom',
    'eggplant',
    'lip',
    'rubbish',
    'hope',
    'embassy',
    'tin',
    'cost',
    'pin',
    'favour',
    'walnut',
    'entire',
    'mom',
    'mum',
    'share',
    'experiment',
    'leave',
    'sugar',
    'bent',
    'serve',
    'permit',
    'missile',
    'pill',
    'earth',
    'upward',
    's',
    'golf',
    'sculpture',
    'fortnight',
    'lend',
    'fish',
    'near',
    'sound',
    'feel',
    'successful',
    'dry',
    'return',
    'only',
    'waist',
    'trial',
    'ride',
    'put',
    'thorough',
    'and',
    'green',
    'sideroad',
    'rebuild',
    'around',
    'bathtub',
    'conventional',
    'discovery',
    'communication',
    'illegal',
    'now',
    'wrist',
    'museum',
    'guidance',
    'rainfall',
    'awful',
    'cosy',
    'tolerate',
    'rank',
    'throw',
    'category',
    'illness',
    'everywhere',
    'retell',
    'member',
    'petrol',
    'bedroom',
    'ceremony',
    'balance',
    'mustard',
    'polish',
    'constant',
    'uncle',
    'tiresome',
    'tailor',
    'disturbing',
    'moment',
    'statue',
    'moon',
    'system',
    'bargain',
    'energetic',
    'alcohol',
    'expectation',
    'instrument',
    'reliable',
    'equality',
    'greeting',
    'generous',
    'shuttle',
    'or',
    'handkerchief',
    'to',
    'fog',
    'everyone',
    'enterprise',
    'trunk',
    'soft',
    'comb',
    'useful',
    'bride',
    'oil',
    'sudden',
    'before',
    'sponsor',
    'always',
    'candy',
    'pavement',
    'hit',
    'biscuit',
    'table',
    'of',
    'modern',
    'kiss',
    'instruct',
    'without',
    'weight',
    'starvation',
    'city',
    'you',
    'consistent',
    'orange',
    'scream',
    'Oceania',
    'shelter',
    'characteristic',
    'evident',
    'inside',
    'trend',
    'appreciate',
    'fan',
    'attempt',
    'ankle',
    'spaceship',
    'indeed',
    'carrot',
    'abrupt',
    'curriculum',
    'depend',
    'plan',
    'market',
    'eventually',
    'schedule',
    'cool',
    'yummy',
    'strength',
    'fluent',
    'pedestrian',
    'claw',
    'suit',
    'party',
    'set',
    'task',
    'seat',
    'school',
    'applaud',
    'world',
    'furnished',
    'anger',
    'seagull',
    'department',
    'bring',
    'cheese',
    'press',
    'sweep',
    'panic',
    'pub',
    'suspect',
    'prevent',
    'challenging',
    'live',
    'bar',
    'pan',
    'corner',
    'temple',
    'pass',
    'real',
    'frost',
    'trip',
    'character',
    'tyre',
    'race',
    'through',
    'aspect',
    'novel',
    'permission',
    'wonder',
    'false',
    'our',
    'energy',
    'microscope',
    'grandchild',
    'exam',
    'examination',
    'climate',
    'suggestion',
    'consultant',
    'college',
    'Pacific',
    'shirt',
    'phenomenon',
    'cotton',
    'organization',
    'vase',
    'bleed',
    'cruel',
    'smoker',
    'terrify',
    'consist',
    'latter',
    'advertise',
    'harbour',
    'mark',
    'proper',
    'empty',
    'curtain',
    'style',
    'restriction',
    'upon',
    'camera',
    'loose',
    'university',
    'boot',
    'melon',
    'sour',
    'border',
    'coat',
    'hear',
    'consideration',
    'open',
    'anyone',
    'rocket',
    'ours',
    'notebook',
    'ambassadress',
    'skillful',
    'sale',
    'beer',
    'criterion',
    'translation',
    'weep',
    'tiger',
    'woollen',
    'have',
    'hesitate',
    'weakness',
    'balcony',
    'armchair',
    'extension',
    'southwest',
    'function',
    'reading',
    'business',
    'ugly',
    'connect',
    'cigar',
    'aboard',
    'grandpa',
    'grandfather',
    'justice',
    'debt',
    'begin',
    'raw',
    'countryside',
    'fry',
    'wipe',
    'smile',
    'fool',
    'everyday',
    'boom',
    'shaver',
    'erupt',
    'brush',
    'frog',
    'this',
    'court',
    'evolution',
    'insist',
    'grand',
    'week',
    'admit',
    'split',
    'forbid',
    'disaster',
    'society',
    'awesome',
    'embarrass',
    'provide',
    'vice',
    'muddy',
    'couple',
    'ant',
    'relax',
    'pocket',
    'cheek',
    'selfish',
    'forget',
    'balloon',
    'memory',
    'p',
    'm',
    'pm',
    'P',
    'M',
    'PM',
    'dead',
    'chocolate',
    'superb',
    'bee',
    'ad',
    'advertisement',
    'truly',
    'valuable',
    'draft',
    'scratch',
    'procedure',
    'be',
    'should',
    'soap',
    'alley',
    'religion',
    'primary',
    'No',
    'number',
    'punishment',
    'granny',
    'mat',
    'waiter',
    'include',
    'oval',
    'finish',
    'flexible',
    'dustbin',
    'any',
    'top',
    'stay',
    'souvenir',
    'left',
    'bone',
    'ability',
    'stomach',
    'basket',
    'available',
    'regret',
    'ever',
    'anything',
    'ago',
    'previous',
    'window',
    'thrill',
    'federal',
    'bottom',
    'physicist',
    'accompany',
    'increase',
    'murder',
    'accumulate',
    'for',
    'excite',
    'bath',
    'traffic',
    'classic',
    'festival',
    'rather',
    'drill',
    'allergic',
    'insert',
    'fare',
    'spear',
    'theirs',
    'conflict',
    'lecture',
    'even',
    'chaos',
    'youth',
    'fault',
    'desk',
    'list',
    'porridge',
    'tasteless',
    'backward',
    's',
    'suggest',
    'influence',
    'disagreement',
    'virtue',
    'personal',
    'guide',
    'damp',
    'future',
    'cent',
    'fold',
    'over',
    'golden',
    'translator',
    'queen',
    'queue',
    'librarian',
    'communism',
    'signal',
    'outgoing',
    'burglar',
    'deal',
    'motor',
    'growth',
    'state',
    'glass',
    'presence',
    'database',
    'office',
    'family',
    'motorcycle',
    'ridiculous',
    'duck',
    'overcome',
    'cafeteria',
    'motivation',
    'culture',
    'poet',
    'preparation',
    'centimetre',
    'gate',
    'tortoise',
    'hospital',
    'they',
    'architect',
    'heavy',
    'chance',
    'messy',
    'solar',
    'multiply',
    'plant',
    'film',
    'guitar',
    'then',
    'sister',
    'count',
    'experience',
    'once',
    'poem',
    'choice',
    'quantity',
    'immigration',
    'inch',
    'also',
    'similar',
    'outline',
    'ministry',
    'remain',
    'grain',
    'baggage',
    'clerk',
    'withdraw',
    'idiom',
    'architecture',
    'alone',
    'ward',
    'flame',
    'thinking',
    'pot',
    'mailbox',
    'academic',
    'bed',
    'hat',
    'caution',
    'pepper',
    'afford',
    'bound',
    'jewellery',
    'dash',
    'lightning',
    'stranger',
    'port',
    'nose',
    'customer',
    'practice',
    'turkey',
    'meat',
    'tail',
    'situation',
    'position',
    'construct',
    'push',
    'secretary',
    'stain',
    'tension',
    'schoolgirl',
    'risk',
    'late',
    'stamp',
    'absent',
    'challenge',
    'shine',
    'cell',
    'grade',
    'full',
    'collect',
    'minute',
    'catalogue',
    'clarify',
    'fade',
    'sunny',
    'worn',
    'roast',
    'picture',
    'horrible',
    'population',
    'nice',
    'AD',
    'colleague',
    'speak',
    'love',
    'child',
    'achieve',
    'discover',
    'spin',
    'adolescence',
    'nurse',
    'active',
    'panda',
    'adore',
    'forgive',
    'tire',
    'cold',
    'earn',
    'travel',
    'distribute',
    'jungle',
    'dull',
    'clever',
    'dislike',
    'pole',
    'radio',
    'former',
    'careful',
    'employ',
    'whistle',
    'separation',
    'happiness',
    'prayer',
    'underwear',
    'pine',
    'downstairs',
    'dizzy',
    'space',
    'cocoa',
    'abnormal',
    'young',
    'passage',
    'sideways',
    'cube',
    'extra',
    'tool',
    'show',
    'plot',
    'express',
    'southeast',
    'girl',
    'cave',
    'ache',
    'monkey',
    'target',
    'Mr',
    'ambulance',
    'unless',
    'noon',
    'range',
    'shake',
    'vocabulary',
    'miss',
    'dessert',
    'painful',
    'connection',
    'true',
    'casual',
    'strengthen',
    'circumstance',
    'knee',
    'tank',
    'handful',
    'gram',
    'during',
    'correct',
    'importance',
    'wheat',
    'ahead',
    'joke',
    'coffee',
    'shock',
    'punctual',
    'leg',
    'ink',
    'brake',
    'its',
    'anybody',
    'washroom',
    'sex',
    'holiday',
    'downtown',
    'mountainous',
    'organise',
    'strawberry',
    'starve',
    'expect',
    'worthwhile',
    'candle',
    'obey',
    'geometry',
    'doubt',
    'DVD',
    'digital',
    'video',
    'disk',
    'ballet',
    'web',
    'housewife',
    'role',
    'roll',
    'wrinkle',
    'tap',
    'make',
    'eye',
    'traveller',
    'neat',
    'where',
    'almost',
    'ask',
    'laundry',
    'move',
    'labour',
    'a',
    'feast',
    'swallow',
    'pen',
    'award',
    'handy',
    'reporter',
    'relate',
    'stubborn',
    'identify',
    'entrance',
    'forest',
    'that',
    'ice',
    'cream',
    'remember',
    'lemonade',
    'dusty',
    'delight',
    'westward',
    's',
    'litter',
    'imagine',
    'support',
    'machine',
    'charge',
    'fancy',
    'end',
    'disabled',
    'associate',
    'entertainment',
    'fond',
    'porter',
    'hate',
    'appointment',
    'woman',
    'class',
    'album',
    'delighted',
    'fork',
    'promote',
    'doll',
    'cry',
    'bright',
    'deliver',
    'catastrophe',
    'comfortable',
    'portable',
    'not',
    'retire',
    'visitor',
    'ecology',
    'own',
    'recipe',
    'history',
    'luck',
    'visa',
    'unfortunate',
    'achievement',
    'rabbit',
    'programme',
    'sofa',
    'battery',
    'postman',
    'electrical',
    'talk',
    'mercy',
    'iron',
    'present',
    'baseball',
    'strict',
    'bare',
    'airline',
    'comedy',
    'century',
    'dear',
    'apron',
    'flat',
    'assist',
    'sport',
    'politics',
    'fly',
    'actor',
    'farm',
    'song',
    'outing',
    'belly',
    'typist',
    'policy',
    'float',
    'buffet',
    'settler',
    'headmaster',
    'happy',
    'catch',
    'medium',
    'steward',
    'riddle',
    'bear',
    'nearby',
    'mess',
    'paperwork',
    'flu',
    'supply',
    'model',
    'mist',
    'Dr',
    'doctor',
    'popcorn',
    'corn',
    'old',
    'chew',
    'exact',
    'aircraft',
    'view',
    'bike',
    'bicycle',
    'hydrogen',
    'astronomy',
    'cupboard',
    'rule',
    'flower',
    'project',
    'test',
    'represent',
    'shallow',
    'weekday',
    'document',
    'thank',
    'purpose',
    'step',
    'bark',
    'overweight',
    'tower',
    'direct',
    'liquid',
    'worm',
    'hello',
    'hamburger',
    'chorus',
    'stove',
    'reputation',
    'sweater',
    'affect',
    'windy',
    'may',
    'niece',
    'regulation',
    'soul',
    'eyesight',
    'brick',
    'till',
    'harm',
    'ambassador',
    'sailor',
    'egg',
    'wind',
    'tourist',
    'mountain',
    'gallery',
    'clone',
    'mushroom',
    'northwest',
    'needle',
    'tie',
    'trolleybus',
    'committee',
    'in',
    'lap',
    'everything',
    'warm',
    'cyclist',
    'widow',
    'shall',
    'yawn',
    'afternoon',
    'Buddhism',
    'timetable',
    'chairman',
    'are',
    'funny',
    'decorate',
    'edge',
    'file',
    'boycott',
    'underline',
    'technique',
    'childhood',
    'blood',
    'pound',
    'crop',
    'celebrate',
    'absolute',
    'describe',
    'sock',
    'breathless',
    'liberation',
    'knife',
    'rose',
    'custom',
    'resemble',
    'bye',
    'graph',
    'worried',
    'salute',
    'amount',
    'ignore',
    'whoever',
    'barbecue',
    'delicious',
    'summer',
    'rich',
    'telescope',
    'abroad',
    'beef',
    'accuse',
    'sleeve',
    'mm',
    'millimetre',
    'body',
    'navy',
    'basin',
    'say',
    'dusk',
    'these',
    'this',
    'student',
    'steel',
    'friendly',
    'music',
    'altitude',
    'sure',
    'wrestle',
    'it',
    'treat',
    'wonderful',
    'probably',
    'button',
    'force',
    'ambiguous',
    'bridegroom',
    'really',
    'gentleman',
    'giraffe',
    'possession',
    'boil',
    'telephone',
    'recycle',
    'cloth',
    'shoulder',
    'park',
    'confirm',
    'compare',
    'answer',
    'mankind',
    'wolf',
    'danger',
    'hug',
    'camel',
    'shortcoming',
    'river',
    'about',
    'tear',
    'antique',
    'thing',
    'unbearable',
    'sneaker',
    'circus',
    'familiar',
    'still',
    'pretend',
    'beddings',
    'whatever',
    'amaze',
    'vacant',
    'suffer',
    'Atlantic',
    'flood',
    'devotion',
    'wedding',
    'rush',
    'difficulty',
    'friction',
    'king',
    'schoolbag',
    'urge',
    'screen',
    'cast',
    'steak',
    'parcel',
    'square',
    'warn',
    'lock',
    'under',
    'debate',
    'tough',
    'design',
    'corporation',
    'negotiate',
    'new',
    'tip',
    'modest',
    'association',
    'adopt',
    'constitution',
    'curious',
    'medal',
    'taxi',
    'arrangement',
    'packet',
    'pour',
    'group',
    'crayon',
    'musical',
    'angry',
    'boundary',
    'spokesman',
    'lonely',
    'though',
    'academy',
    'their',
    'outspoken',
    'length',
    'thick',
    'wing',
    'myself',
    'digest',
    'plenty',
    'fair',
    'squeeze',
    'product',
    'mention',
    'coach',
    'suitable',
    'kid',
    'lion',
    'straight',
    'forward',
    'there',
    'educate',
    'disk',
    'disc',
    'calm',
    'fridge',
    'refrigerator',
    'distance',
    'relative',
    'satisfaction',
    'village',
    'television',
];
exports.default = classNameList;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/index.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/index.js ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList_1 = __webpack_require__(/*! ./classNameList */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/classNameList.js");
const handleClassName = (data, numObj = { num: 0 }) => {
    for (let i = 0; i < data.length; i++) {
        const layer = data[i];
        const currIndex = numObj.num % classNameList_1.default.length; //英文单词下标
        const numIndex = Math.floor(numObj.num / classNameList_1.default.length) + 1; //数字后缀
        layer.className = numIndex > 1 ? classNameList_1.default[currIndex] + numIndex : classNameList_1.default[currIndex];
        numObj.num++;
        if (Array.isArray(layer.children)) {
            layer.children = handleClassName(layer.children, numObj);
        }
    }
    return data;
};
exports.default = handleClassName;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/index.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/index.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoCode = void 0;
const web_1 = __webpack_require__(/*! ./web */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/index.js");
const weapp_1 = __webpack_require__(/*! ./weapp */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/index.js");
const reactnative_1 = __webpack_require__(/*! ./reactnative */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/index.js");
const src_1 = __webpack_require__(/*! ../../sketch-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js");
exports.picassoCode = (data, size, // 画板宽度 370px、750px 按照移动端处理
platform = src_1.CodeType.WebPx) => {
    switch (platform) {
        case src_1.CodeType.WebPx:
            return web_1.picassoWebCode(data, size);
        case src_1.CodeType.Weapp:
            return weapp_1.picassoWeappCode(data, size);
        case src_1.CodeType.ReactNative:
            return reactnative_1.picassoRNCode(data);
        default:
            break;
    }
};
__exportStar(__webpack_require__(/*! ./web */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/index.js"), exports);
__exportStar(__webpack_require__(/*! ./weapp */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/index.js"), exports);
__exportStar(__webpack_require__(/*! ./reactnative */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/index.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/generateJSX.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/generateJSX.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: iChengbo
 * @Date: 2020-09-02 11:41:52
 * @LastEditors: iChengbo
 * @LastEditTime: 2020-09-08 19:03:13
 * @FilePath: /picasso-core/packages/picasso-code/src/reactnative/generateJSX.ts
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRNJSX = void 0;
const RN = {
    Container: 'View',
    Image: 'ImageBackground',
    Text: 'Text',
    Link: 'Text',
};
/**
 *
 *
 * @param {Array} data layoutDSL
 * @returns React代码
 */
function _generateRNJSX(data) {
    let html = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        if (record.type == 'Image' && ((record.children && record.children.length == 0) || !record.children)) {
            const source = /^http/.test(record.value) ? `{uri: "${record.value}"}` : `require('./images/${record.value}')`;
            html.push(`<Image style=${record.addClassName
                ? `{StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])}`
                : `{styles.${record.className}}`} source={${source}} resizeMode={"stretch"} />`);
        }
        else {
            let tag = RN[record.type];
            if (record.type == 'Image') {
                // console.log("图片样式：", record.style)
                // 背景图片
                if (!!record.style.backgroundImage) {
                    const bgSource = /^http/.test(record.style.backgroundImage) ? `{uri: "${record.style.backgroundImage}"}` : `require('./images/${record.style.backgroundImage}')`;
                    html.push(`<${tag} style={${record.addClassName ?
                        `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])`
                        : `styles.${record.className}`}}
                            source={${bgSource}}
                        >`);
                }
                else if (!!record.style.linearGradient) {
                    // 渐变的处理
                    tag = 'LinearGradient';
                    const { gAngle, gList } = record.style.linearGradient;
                    const _gList = gList.map(item => {
                        // return generateColor(item.color);
                    });
                    const { width, height } = record.style.backgroundSize;
                    html.push(`<LinearGradient useAngle={true} angle={${+gAngle}} colors={${JSON.stringify(_gList)}} style={{width: scaleSize(${width / 2}), height: scaleSize(${height / 2})}}>`);
                }
                else {
                    tag = 'View';
                    html.push('<View>');
                }
            }
            else if (record.type == 'Text') {
                // 文本特殊处理：包一层View设置高度，并将文本垂直居中
                // 方案一：会导致一些其他的问题
                // tag = 'View';
                // html.push(`<${tag} style={{ height: styles.${record.className}.height, flexDirection: 'row', alignItems: 'center'  }}>`)
                // // html.push(`<${tag} style={${record.addClassName ?
                // //     `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}, { flexDirection: 'row', alignItems: 'center' }])`
                // //     : `[styles.${record.className}, { flexDirection: 'row', alignItems: 'center' }]`}}>`);
                // html.push(`<Text style={${record.addClassName ?
                //     `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}, { height: undefined, lineHeight: undefined }])`
                //     : `[styles.${record.className}, { height: undefined, lineHeight: undefined }]`}}>`
                // );
                // html.push(record.value.replace(/\n/g, `{"\\n"}`) || '');
                // html.push('</Text>');
                // 方案二：将高度及行高均置为 undefined，但会影响上下间距布局
                html.push(`<${tag} style={${record.addClassName ?
                    `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])`
                    : `[styles.${record.className}, { height: undefined, lineHeight: undefined }]`}}>`);
            }
            else {
                html.push(`<${tag} style={${record.addClassName ?
                    `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])`
                    : `styles.${record.className}`}}>`);
            }
            if (record.children && record.type != 'Text') {
                // 递归 子 children
                html.push(exports.generateRNJSX(record.children));
            }
            // else if (record.children && record.type == 'Text' && !record.isMerged) {
            //     // TODO：此处是干啥的
            //     html.push(record.value || '');
            //     html.push(generateRNJSX(record.children));
            // } 
            else {
                if (record.type == 'Text') {
                    html.push(record.value.replace(/\n/g, `{"\\n"}`) || '');
                }
            }
            html.push(`</${tag}>`);
        }
    }
    return html.join('\n');
}
exports.generateRNJSX = (data) => {
    let JSXCode = _generateRNJSX(data);
    return JSXCode;
    // return beautifyHtml(JSXCode, { indent_size: 2 })
};
// export const generateRNJSX = (data: any) => {
//     // let JSXCode = _generateRNJSX(data)
//     // return beautifyHtml(JSXCode, { indent_size: 2 })
//     let html = [];
//     for (let i = 0; i < data.length; i++) {
//         let record = data[i];
//         let tag = 'View';
//         if (record.type == 'Image') {
//         } else if (record.type == 'Text') {
//         } else {
//             html.push(`<${tag}>`)
//         }
//         if (Array.isArray(record.children)) {
//             html.push(generateRNJSX(record.children));
//         }
//         if (['View', 'Text',].includes(record.type)) {
//             html.push(`</${tag}>`);
//         }
//         // switch (record.type) {
//         //     case 'Image':
//         //         break;
//         //     case 'Text':
//         //         break;
//         //     default:
//         //         const tag = 'View';
//         //         html.push(`<${tag}> </${tag}>`);
//         //         if (Array.isArray(record.children)) {
//         //             html.push(generateRNJSX(record.children));
//         //         }
//         //         break;
//         // }
//     }
//     return html.join('\n');
// }


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/generateStyle.js":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/generateStyle.js ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRNStyle = void 0;
/*
 * @Author: iChengbo
 * @Date: 2020-09-02 11:44:55
 * @LastEditors: iChengbo
 * @LastEditTime: 2020-09-08 17:13:39
 * @FilePath: /picasso-core/packages/picasso-code/src/reactnative/generateStyle.ts
 */
let styles = {};
exports.generateRNStyle = (data) => {
    if (Array.isArray(data)) {
        data.forEach(item => {
            // 删除特殊处理的属性
            delete item.style.backgroundImage;
            delete item.style.linearGradient;
            delete item.style.backgroundSize;
            styles[item.className] = item.style;
            if (Array.isArray(item.children)) {
                exports.generateRNStyle(item.children);
            }
        });
    }
    let result = JSON.stringify(styles, null, 2).replace(/"width": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"width": scaleSize(${$1})`;
    });
    result = result.replace(/"height": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"height": scaleSize(${$1})`;
    });
    result = result.replace(/"lineHeight": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"lineHeight": scaleSize(${$1})`;
    });
    result = result.replace(/"marginLeft": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"marginLeft": scaleSize(${$1})`;
    });
    result = result.replace(/"marginTop": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"marginTop": scaleSize(${$1})`;
    });
    return result;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/index.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/index.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoRNCode = void 0;
const handleClassName_1 = __webpack_require__(/*! ../handleClassName */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/index.js");
const src_1 = __webpack_require__(/*! ../../../picasso-trans/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/index.js");
const src_2 = __webpack_require__(/*! ../../../sketch-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js");
const generateJSX_1 = __webpack_require__(/*! ./generateJSX */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/generateJSX.js");
const generateStyle_1 = __webpack_require__(/*! ./generateStyle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/reactnative/generateStyle.js");
/**
 * @description Picasso生成代码
 * @param { Layer[] } data
 * @param { number } size 画板宽度
 */
exports.picassoRNCode = (data) => {
    // class 名称处理
    data = handleClassName_1.default(data);
    // 4. 样式处理
    data = src_1.picassoTrans(data, {
        scale: src_2.WebScale.Points,
        unit: src_2.Unit.ReactNative,
        colorFormat: src_2.ColorFormat.RGBA,
        codeType: src_2.CodeType.ReactNative
    });
    // console.log("哈哈哈哈哈\n",  JSON.stringify(data, null, 2))
    // 生成组件
    const jsxCode = generateJSX_1.generateRNJSX(data);
    // console.log("生成的组件：", jsxCode)
    // 生成样式
    const styleCode = generateStyle_1.generateRNStyle(data);
    return {
        jsx: `import React, { Component } from 'react';
        import {
            Image,
            View,
            Text,
            ImageBackground,
            ScrollView,
            Dimensions,
            StyleSheet,
            SafeAreaView,
            Platform,
            StatusBar,
        } from 'react-native';
        ${/LinearGradient/.test(jsxCode) ? "import LinearGradient from 'react-native-linear-gradient';" : ""}
        
        const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
        
        const scaleSize = (size) => size * (SCREEN_WIDTH / 375);
        
        const isIphoneX = () => {
            return Platform.OS === 'ios' &&
                !Platform.isPad &&
                !Platform.isTVOS &&
                (SCREEN_HEIGHT === 812 || SCREEN_WIDTH === 812 || SCREEN_WIDTH === 896 || SCREEN_HEIGHT === 896);
        }
            
        const STATUSBAR_HEIGHT = Platform.select({
            ios: isIphoneX() ? 44 : 20,
            android: StatusBar.currentHeight,
        })
        
        export default class PicasoPage extends Component {
            constructor(props) {
                super(props);
            }
        
            componentDidMount() {}
        
            componentWillUnmount() {}
        
            render() {
                return (
                    <ScrollView style={{ flex: 1, width: SCREEN_WIDTH, height: SCREEN_HEIGHT }}>
                        ${jsxCode}
                    </ScrollView>
                )
            }
        }
        
        const styles = StyleSheet.create(${styleCode})
        `
    };
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/generateWXML.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/generateWXML.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const generateWXML = (data) => {
    let wxml = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        if (record.type === 'Image') {
            wxml.push(`<image class="${record.className}" src="./images/${record.value}"/>`);
        }
        else {
            if (record.type === 'Text') {
                wxml.push(`<view class="${record.className}">`);
                record.value = record.value.replace(/\n/g, '\\n') || '';
                wxml.push(record.value || '');
            }
            else {
                wxml.push(`<view class="${record.className}" >`);
            }
            if (Array.isArray(record.children)) {
                wxml.push(generateWXML(record.children));
            }
            if (record.type === 'Text') {
                wxml.push(`</view>`);
            }
            else {
                wxml.push(`</view>`);
            }
        }
    }
    return wxml.join('\n');
};
exports.default = generateWXML;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/generateWXSS.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/generateWXSS.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 *  px转换为rpx
 *
 */
const pxtorpx = (value, size) => {
    const scale = 750 / size;
    if (/px/.test(value)) {
        value = value.replace(/((\.|\d|\e|\-)+)px/g, ($1, $2) => {
            return `${Math.round($1.split('px')[0] * 10 * scale) / 10}rpx`;
        });
    }
    return value;
};
const generateWeappStyle = (data, size) => {
    let style = [];
    if (data.style && Object.keys(data.style).length) {
        for (var key in data.style) {
            if (data.style.hasOwnProperty(key) &&
                data.style[key] != undefined) {
                let currValue = data.style[key];
                currValue = pxtorpx(currValue, size);
                style.push(`${key}: ${currValue};`);
            }
        }
    }
    return style.join('\n');
};
const generateWXSS = (data, size, parentNodeName = '') => {
    let wxss = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        let nodeName = parentNodeName
            ? parentNodeName + ' .' + record.className
            : '.' + record.className;
        wxss.push(nodeName + '{');
        wxss.push(generateWeappStyle(record, size));
        wxss.push('}');
        if (record.children) {
            wxss.push(generateWXSS(record.children, size, nodeName));
        }
    }
    return wxss.join('\n');
};
exports.default = generateWXSS;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/index.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/index.js ***!
  \*****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoWeappCode = void 0;
const handleClassName_1 = __webpack_require__(/*! ../handleClassName */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/handleClassName/index.js");
const src_1 = __webpack_require__(/*! ../../../picasso-trans/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/index.js");
const src_2 = __webpack_require__(/*! ../../../sketch-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js");
const generateWXML_1 = __webpack_require__(/*! ./generateWXML */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/generateWXML.js");
const generateWXSS_1 = __webpack_require__(/*! ./generateWXSS */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/weapp/generateWXSS.js");
/**
 * @description Picasso生成小程序代码
 * @param {Layer[]} data
 * @param { number } size 画板宽度
 */
exports.picassoWeappCode = (data, size) => {
    // class名称处理
    data = handleClassName_1.default(data);
    // 样式处理
    data = src_1.picassoTrans(data, {
        scale: src_2.WebScale.Points,
        unit: src_2.Unit.Weapp,
        colorFormat: src_2.ColorFormat.RGBA,
        codeType: src_2.CodeType.Weapp
    });
    //生成wxml模板
    const wxml = generateWXML_1.default(data);
    //生成wxss代码
    const wxss = generateWXSS_1.default(data, size);
    return {
        wxml,
        wxss
    };
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/cssOrder.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/cssOrder.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * css顺序数组
 */
const cssList = [
    'position',
    'top',
    'right',
    'bottom',
    'left',
    'z-index',
    'display',
    'float',
    'width',
    'height',
    'max-width',
    'max-height',
    'min-width',
    'min-height',
    'padding',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
    'margin',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'margin-collapse',
    'margin-top-collapse',
    'margin-right-collapse',
    'margin-bottom-collapse',
    'margin-left-collapse',
    'overflow',
    'overflow-x',
    'overflow-y',
    'clip',
    'clear',
    'font',
    'font-family',
    'font-size',
    'font-smoothing',
    'osx-font-smoothing',
    'font-style',
    'font-weight',
    'hyphens',
    'src',
    'line-height',
    'letter-spacing',
    'word-spacing',
    'color',
    'text-align',
    'text-decoration',
    'text-indent',
    'text-overflow',
    'text-rendering',
    'text-size-adjust',
    'text-shadow',
    'text-transform',
    'word-break',
    'word-wrap',
    'white-space',
    'vertical-align',
    'list-style',
    'list-style-type',
    'list-style-position',
    'list-style-image',
    'pointer-events',
    'cursor',
    'background',
    'background-attachment',
    'background-color',
    'background-image',
    'background-position',
    'background-repeat',
    'background-size',
    'border',
    'border-collapse',
    'border-top',
    'border-right',
    'border-bottom',
    'border-left',
    'border-color',
    'border-image',
    'border-top-color',
    'border-right-color',
    'border-bottom-color',
    'border-left-color',
    'border-spacing',
    'border-style',
    'border-top-style',
    'border-right-style',
    'border-bottom-style',
    'border-left-style',
    'border-width',
    'border-top-width',
    'border-right-width',
    'border-bottom-width',
    'border-left-width',
    'border-radius',
    'border-top-right-radius',
    'border-bottom-right-radius',
    'border-bottom-left-radius',
    'border-top-left-radius',
    'border-radius-topright',
    'border-radius-bottomright',
    'border-radius-bottomleft',
    'border-radius-topleft',
    'content',
    'quotes',
    'outline',
    'outline-offset',
    'opacity',
    'filter',
    'visibility',
    'size',
    'zoom',
    'transform',
    'box-align',
    'box-flex',
    'box-orient',
    'box-pack',
    'box-shadow',
    'box-sizing',
    'table-layout',
    'animation',
    'animation-delay',
    'animation-duration',
    'animation-iteration-count',
    'animation-name',
    'animation-play-state',
    'animation-timing-function',
    'animation-fill-mode',
    'transition',
    'transition-delay',
    'transition-duration',
    'transition-property',
    'transition-timing-function',
    'background-clip',
    'backface-visibility',
    'resize',
    'appearance',
    'user-select',
    'interpolation-mode',
    'direction',
    'marks',
    'page',
    'set-link-source',
    'unicode-bidi',
    'speak'
];
/**
 * css 排序方法
 */
exports.default = (item) => {
    let itemIndex = cssList.length;
    if (cssList.indexOf(item) > -1) {
        itemIndex = cssList.indexOf(item);
    }
    return itemIndex;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateBody.js":
/*!**********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateBody.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const generateBody = (data, tab = '') => {
    var _a, _b;
    let html = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        if (record.type === 'Image' && !(((_a = record.children) === null || _a === void 0 ? void 0 : _a.length) > 0)) {
            html.push(`${tab}<img class="${record.className}" src="${record.value.indexOf('http') === 0 ? record.value : `../images/${record.value}`}"/>`);
        }
        else if (record.type === 'Text' && ((_b = record.children) === null || _b === void 0 ? void 0 : _b.length) > 0) {
            const tag = 'div';
            html.push(`${tab}<${tag} class="${record.className}">`);
            record.children.forEach((layer) => {
                html.push(`${tab}    <span class="${record.className}">`);
                html.push(`${tab}        ${layer.value || ''}`);
                html.push(`${tab}    </span>`);
            });
            html.push(`${tab}</${tag}>`);
        }
        else {
            // to be done
            const tag = 'div';
            html.push(`${tab}<${tag} class="${record.className}">`);
            if (record.type === 'Text') {
                record.value = record.value.replace(/ /ig, '&nbsp;');
                html.push(`${tab}    ${record.value || ''}`);
            }
            if (Array.isArray(record.children)) {
                html.push(generateBody(record.children, tab + '    '));
            }
            html.push(`${tab}</${tag}>`);
        }
    }
    return html.join('\n');
};
exports.default = generateBody;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateCSS.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateCSS.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleCssOrder_1 = __webpack_require__(/*! ./handleCssOrder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/handleCssOrder.js");
/**
 * scss中 px转换为rem方法
 * @param {String} value css值
 * @param {String} platform 平台
 */
const addpxtorem = (value) => {
    if (/px/.test(value)) {
        value = value.replace(/((\.|\d|\e|\-)+)px/g, ($1) => {
            return `pxtorem(${Math.round($1.split('px')[0] * 10) / 10}px)`;
        });
    }
    return value;
};
const pxtorem = (currValue, platform, size) => {
    const draftSize = size / 7.5;
    if (/px/.test(currValue)) {
        currValue = currValue.replace(/((\.|\d|\e|\-)+)px/g, ($1) => {
            return +platform === 2
                ? `${Math.round(($1.split("px")[0] / draftSize) * 1000) / 1000}rem`
                : `${Math.round($1.split("px")[0] * 10) / 10}px`;
        });
    }
    return currValue;
};
// scss字符串
let scssStr = '';
const transformScssFormat = (data, size, platform) => {
    for (var i = 0; i < data.length; i++) {
        scssStr += `.${data[i].className} {\n`;
        let orderStyle = handleCssOrder_1.default(data[i].style);
        let styleKeyList = Object.keys(orderStyle);
        for (let j = 0; j < styleKeyList.length; j++) {
            const key = styleKeyList[j];
            let value = orderStyle[key];
            //修复undefindpx的bug
            value = pxtorem(value, platform, size);
            if (!/undefind/.test(value)) {
                scssStr += `    ${key}: ${value};\n`;
            }
        }
        scssStr += `\}\n`;
        if (data[i].children) {
            transformScssFormat(data[i].children, size, platform);
        }
    }
    return scssStr;
};
const generaterScss = (data, size, platform) => {
    // 清空存储
    scssStr = '';
    return transformScssFormat(data, size, platform);
};
exports.default = generaterScss;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateScss.js":
/*!**********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateScss.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleCssOrder_1 = __webpack_require__(/*! ./handleCssOrder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/handleCssOrder.js");
/**
 * scss中 px转换为rem方法
 * @param {String} value css值
 * @param {String} platform 平台
 */
const addpxtorem = (value) => {
    if (/px/.test(value)) {
        value = value.replace(/((\.|\d|\e|\-)+)px/g, ($1) => {
            return `pxtorem(${Math.round($1.split('px')[0] * 10) / 10}px)`;
        });
    }
    return value;
};
// scss字符串
let scssStr = '';
const transformScssFormat = (data, layerNumber = 1) => {
    let styleTab = '';
    let classTab = '';
    let count = 0;
    while (count < layerNumber) {
        styleTab += '    ';
        if (count < layerNumber - 1) {
            classTab += '    ';
        }
        count++;
    }
    for (var i = 0; i < data.length; i++) {
        scssStr += layerNumber == 1 ? `.${data[i].className} {\n${styleTab}` : `${classTab}.${data[i].className} {\n${styleTab}`;
        let orderStyle = handleCssOrder_1.default(data[i].style);
        let styleKeyList = Object.keys(orderStyle);
        for (let j = 0; j < styleKeyList.length; j++) {
            const key = styleKeyList[j];
            let value = orderStyle[key];
            //修复undefindpx的bug
            value = addpxtorem(value);
            if (!/undefind/.test(value)) {
                if (j != styleKeyList.length - 1) {
                    scssStr += `${key}: ${value};\n${styleTab}`;
                }
                else {
                    scssStr += `${key}: ${value};\n`;
                }
            }
        }
        if (data[i].children) {
            transformScssFormat(data[i].children, layerNumber + 1);
        }
        scssStr += layerNumber == 1 ? `\}\n` : `${classTab}\}\n`;
    }
    return scssStr;
};
const generaterScss = (data, size) => {
    const draftSize = size / 7.5;
    // scss 基础变量
    let scss = `@function pxtorem($px){
    @return $px/${draftSize}px * 1rem;
}
`;
    // 重新清零，防止不同画板的scss累加
    scssStr = '';
    scss += transformScssFormat(data);
    return scss;
};
exports.default = generaterScss;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/handleCssOrder.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/handleCssOrder.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const cssOrder_1 = __webpack_require__(/*! ./cssOrder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/cssOrder.js");
/**
 * margin合并
 * @param {Object} styleOrderObj 样式
 */
const mergeMargin = (styleOrderObj) => {
    let marginTop = 0, marginRight = 0, marginBottom = 0, marginLeft = 0;
    let num = 0;
    if (styleOrderObj['margin-top']) {
        num++;
        marginTop = styleOrderObj['margin-top'];
    }
    if (styleOrderObj['margin-right']) {
        num++;
        marginRight = styleOrderObj['margin-right'];
    }
    if (styleOrderObj['margin-bottom']) {
        num++;
        marginBottom = styleOrderObj['margin-bottom'];
    }
    if (styleOrderObj['margin-left']) {
        num++;
        marginLeft = styleOrderObj['margin-left'];
    }
    if (num >= 2) {
        if (marginBottom == marginLeft && marginLeft == marginRight && marginRight == marginTop) {
            styleOrderObj['margin'] = `${marginTop}`;
        }
        else if (marginBottom == marginTop && marginLeft == marginRight) {
            styleOrderObj['margin'] = `${marginTop} ${marginRight}`;
        }
        else if (marginLeft == marginRight) {
            styleOrderObj['margin'] = `${marginTop} ${marginRight} ${marginBottom}`;
        }
        else {
            styleOrderObj['margin'] = `${marginTop} ${marginRight} ${marginBottom} ${marginLeft}`;
        }
        delete styleOrderObj['margin-top'];
        delete styleOrderObj['margin-right'];
        delete styleOrderObj['margin-bottom'];
        delete styleOrderObj['margin-left'];
    }
    if (styleOrderObj['margin-right'] == 'auto') {
        delete styleOrderObj['margin-right'];
    }
    if (styleOrderObj['margin-left'] == 'auto') {
        delete styleOrderObj['margin-left'];
    }
    return styleOrderObj;
};
/**
 * css 格式化
 */
exports.default = (styleObj) => {
    if (styleObj instanceof Object && Object.keys(styleObj).length > 0) {
        let styleKeysList = Object.keys(styleObj);
        let styleOrderObj = {};
        for (let i = 0; i < styleKeysList.length; i++) {
            if ((styleObj[styleKeysList[i]] / 1 != 0) || styleKeysList[i] === 'left' || styleKeysList[i] === 'top') {
                if (!((styleKeysList[i] == 'width' && styleObj[styleKeysList[i]] == 'auto') ||
                    (styleKeysList[i] == 'font-weight' && styleObj[styleKeysList[i]] == 400) ||
                    (styleKeysList[i] == 'flex-direction' && styleObj[styleKeysList[i]] == 'row') ||
                    (styleKeysList[i] == 'text-align' && styleObj[styleKeysList[i]] == 'left'))) {
                    if (!isNaN(styleObj[styleKeysList[i]] / 1) && 'font-weight' != styleKeysList[i] && 'flex' != styleKeysList[i]) {
                        styleOrderObj[styleKeysList[i]] = styleObj[styleKeysList[i]] + 'px';
                    }
                    else {
                        styleOrderObj[styleKeysList[i]] = styleObj[styleKeysList[i]];
                    }
                }
            }
        }
        // 合并margin
        styleOrderObj = mergeMargin(styleOrderObj);
        // 生成的样式排序
        let styleKeysList2 = Object.keys(styleOrderObj);
        styleKeysList2.sort((a, b) => {
            return cssOrder_1.default(a) - cssOrder_1.default(b);
        });
        let styleOrderObj2 = {};
        for (let i = 0; i < styleKeysList2.length; i++) {
            styleOrderObj2[styleKeysList2[i]] = styleOrderObj[styleKeysList2[i]];
        }
        return styleOrderObj2;
    }
    else {
        return {};
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/index.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/index.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoWebCode = void 0;
const generateScss_1 = __webpack_require__(/*! ./generateScss */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateScss.js");
const generateCSS_1 = __webpack_require__(/*! ./generateCSS */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateCSS.js");
const generateBody_1 = __webpack_require__(/*! ./generateBody */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/web/generateBody.js");
const src_1 = __webpack_require__(/*! ../../../picasso-trans/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/index.js");
const src_2 = __webpack_require__(/*! ../../../sketch-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js");
/**
 * 生成局部代码
 * @description Picasso生成代码
 * @param {Layer[]} data
 * @param {string} outputPath 生成代码存放路径
 */
exports.picassoWebCode = (data, size) => {
    try {
        const platform = [375, 750].includes(Math.round(size)) ? 2 : 1;
        // 4. 样式处理
        data = src_1.picassoTrans(data, {
            scale: src_2.WebScale.Points,
            unit: src_2.Unit.WebPx,
            colorFormat: src_2.ColorFormat.RGBA,
            codeType: src_2.CodeType.WebPx,
        });
        // 生成 body
        const body = generateBody_1.default(data, '');
        let scss = '';
        // 生成scss
        scss += generateScss_1.default(data, size);
        // 生成css
        const css = generateCSS_1.default(data, size, platform);
        return {
            scss,
            css,
            html: body,
            vueHtml: body,
            reactHtml: body.replace(/class=/ig, 'className='),
        };
    }
    catch (error) {
        console.log(error);
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/BaseComponent.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/BaseComponent.js ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Container.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Container.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Image.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Image.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Link.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Link.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/List.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/List.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Text.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Text.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/index.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/index.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./BaseComponent */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/BaseComponent.js"), exports);
__exportStar(__webpack_require__(/*! ./Container */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Container.js"), exports);
__exportStar(__webpack_require__(/*! ./Link */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Link.js"), exports);
__exportStar(__webpack_require__(/*! ./Text */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Text.js"), exports);
__exportStar(__webpack_require__(/*! ./Image */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/Image.js"), exports);
__exportStar(__webpack_require__(/*! ./List */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/List.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Border.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Border.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 边框类型
 */
var borderStyleType;
(function (borderStyleType) {
    borderStyleType["Dotted"] = "dotted";
    borderStyleType["Solid"] = "solid";
    borderStyleType["Double"] = "double";
    borderStyleType["Dashed"] = "dashed";
})(borderStyleType || (borderStyleType = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Margin.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Margin.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Padding.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Padding.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/index.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/index.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./Border */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Border.js"), exports);
__exportStar(__webpack_require__(/*! ./Margin */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Margin.js"), exports);
__exportStar(__webpack_require__(/*! ./Padding */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/Padding.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/Background.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/Background.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.BackgroundRepeat = void 0;
/**
 *
 */
var BackgroundRepeat;
(function (BackgroundRepeat) {
    BackgroundRepeat[BackgroundRepeat["repeat"] = 0] = "repeat";
    BackgroundRepeat[BackgroundRepeat["repeat-x"] = 1] = "repeat-x";
    BackgroundRepeat[BackgroundRepeat["no-repeat"] = 2] = "no-repeat";
    BackgroundRepeat[BackgroundRepeat["repeat-y"] = 3] = "repeat-y";
})(BackgroundRepeat = exports.BackgroundRepeat || (exports.BackgroundRepeat = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/BorderRadius.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/BorderRadius.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/BoxShadow.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/BoxShadow.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/TextShadow.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/TextShadow.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/TextStyle.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/TextStyle.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/Transform.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/Transform.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/index.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/index.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./TextStyle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/TextStyle.js"), exports);
__exportStar(__webpack_require__(/*! ./Background */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/Background.js"), exports);
__exportStar(__webpack_require__(/*! ./BoxShadow */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/BoxShadow.js"), exports);
__exportStar(__webpack_require__(/*! ./TextShadow */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/TextShadow.js"), exports);
__exportStar(__webpack_require__(/*! ./Transform */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/Transform.js"), exports);
__exportStar(__webpack_require__(/*! ./BorderRadius */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/BorderRadius.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/common/index.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/common/index.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/index.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/index.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./Component */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Component/index.js"), exports);
__exportStar(__webpack_require__(/*! ./Structure */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Structure/index.js"), exports);
__exportStar(__webpack_require__(/*! ./Style */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/Style/index.js"), exports);
__exportStar(__webpack_require__(/*! ./common */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/common/index.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleLabelList.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleLabelList.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleLabelList = void 0;
const utils = __webpack_require__(/*! ./utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/utils.js");
const markLabelList = (data, parent) => {
    // 标记lableList 的情况  距离左边的距离相等 只有一行的情况下
    try {
        for (let item of data) {
            if (utils.isEqualHeight(data) &&
                utils.isSameSpacing(data) &&
                (utils.hasBorder(data) || utils.hasBackground(data)) &&
                utils.hasTextType(data)) {
                parent.isLabelList = true;
            }
            if (item.children && !item.isLabelList) {
                markLabelList(item.children, item);
            }
        }
        return data;
    }
    catch (error) {
        console.log(error);
    }
};
const mergeLabelList = (data) => {
    // 标记 isLabelList=true 合并的相邻行
    try {
        for (let i = 0; i < data.length; i++) {
            let prev = data[i];
            let next = i + 1 <= data.length ? data[i + 1] : null;
            if (next && prev.isLabelList && next.isLabelList) {
                // children 合并
                prev.children = [...prev.children, ...next.children];
                prev.marginBottom = next.structure.y - prev.structure.y - prev.structure.height;
                prev.marginRight = prev.children[1].structure.x - prev.children[0].structure.x - prev.children[0].structure.width;
                prev.structure.height = next.structure.y - prev.structure.y + next.structure.height;
                data.splice(i + 1, 1); // 删除合并完之后的 next
                i--;
            }
            if (prev.children) {
                mergeLabelList(prev.children);
            }
        }
        return data;
    }
    catch (error) {
        console.log(error);
    }
};
exports.handleLabelList = data => {
    data = markLabelList(data);
    data = mergeLabelList(data);
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleMergeItem.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleMergeItem.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleMergeItem = void 0;
const utils_1 = __webpack_require__(/*! ../utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/utils.js");
const isEqualList = (data) => {
    let widthInit = data[0].structure.height;
    for (let i = 1; i < data.length; i++) {
        const item = data[i];
        if (Math.abs(item.structure.height - widthInit) >= 2) {
            return false;
        }
    }
    return true;
};
//所有元素在同一条线上
const isLine = (data) => {
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        for (let j = i; j < data.length; j++) {
            const itemJ = data[j];
            if (itemJ.structure.y >= item.structure.y + item.structure.height || item.structure.y >= itemJ.structure.y + itemJ.structure.height) {
                return false;
            }
        }
    }
    return true;
};
exports.handleMergeItem = (data, parent) => {
    if (!data) {
        return data;
    }
    /**
     * 1.父元素宽度接近画板
     * 2.子元素呈现出明显的聚合
     *
     * 左聚合：当中心在左边时且全部元素在左边
     * 右聚合：当中心在右边时且全部元素在右边
     */
    if (isLine(data) && parent && parent.structure.height > 0.7 * 750 && data.length > 2 && !isEqualList(data) && data[0].name != 'ItemList') {
        let flagL = true;
        let flagR = true;
        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            if (item.structure.x + item.structure.height / 2 < parent.structure.x + parent.structure.height / 2) {
                if (item.structure.x + item.structure.height > parent.structure.x + parent.structure.height * 0.5) {
                    flagL = false;
                }
            }
            if (item.structure.x + item.structure.height / 2 >= parent.structure.x + parent.structure.height / 2) {
                if (item.structure.x < parent.structure.x + parent.structure.height * 0.5) {
                    flagR = false;
                }
            }
        }
        if (flagL) {
            let spanArr = [];
            let otherArr = [];
            for (let i = 0; i < data.length; i++) {
                const item = data[i];
                if (item.structure.x + item.structure.height / 2 < parent.structure.x + parent.structure.height / 2) {
                    spanArr.push(item);
                }
                else {
                    otherArr.push(item);
                }
            }
            if (spanArr.length > 1) {
                let spanMinX = spanArr[0].structure.x, spanMinY = spanArr[0].structure.y, spanMaxX = spanArr[0].structure.x + spanArr[0].structure.height, spanMaxY = spanArr[0].structure.y + spanArr[0].structure.height;
                for (let i = 0; i < spanArr.length; i++) {
                    const item = spanArr[i];
                    if (item.structure.x < spanMinX) {
                        spanMinX = item.structure.x;
                    }
                    if (item.structure.y < spanMinY) {
                        spanMinY = item.structure.y;
                    }
                    if (item.structure.x + item.structure.height > spanMaxX) {
                        spanMaxX = item.structure.x + item.structure.height;
                    }
                    if (item.structure.y + item.structure.height > spanMaxY) {
                        spanMaxY = item.structure.y + item.structure.height;
                    }
                }
                data = [{
                        id: utils_1.uniqueId(),
                        class: 'Span',
                        type: 'Container',
                        name: 'Span3',
                        structure: {
                            zIndex: parent.structure.zIndex,
                            x: spanMinX,
                            y: spanMinY,
                            width: spanMaxX - spanMinX,
                            height: spanMaxY - spanMinY,
                        },
                        children: spanArr,
                        style: {}
                    }, ...otherArr];
            }
        }
        if (flagR) {
            let spanArr = [];
            let otherArr = [];
            for (let i = 0; i < data.length; i++) {
                const item = data[i];
                if (item.structure.x + item.structure.height / 2 >= parent.structure.x + parent.structure.height / 2) {
                    spanArr.push(item);
                }
                else {
                    otherArr.push(item);
                }
            }
            if (spanArr.length > 1) {
                let spanMinX = spanArr[0].structure.x, spanMinY = spanArr[0].structure.y, spanMaxX = spanArr[0].structure.x + spanArr[0].structure.height, spanMaxY = spanArr[0].structure.y + spanArr[0].structure.height;
                for (let i = 0; i < spanArr.length; i++) {
                    const item = spanArr[i];
                    if (item.structure.x < spanMinX) {
                        spanMinX = item.structure.x;
                    }
                    if (item.structure.y < spanMinY) {
                        spanMinY = item.structure.y;
                    }
                    if (item.structure.x + item.structure.height > spanMaxX) {
                        spanMaxX = item.structure.x + item.structure.height;
                    }
                    if (item.structure.y + item.structure.height > spanMaxY) {
                        spanMaxY = item.structure.y + item.structure.height;
                    }
                }
                data = [...otherArr, {
                        id: utils_1.uniqueId(),
                        class: 'Row',
                        type: 'Container',
                        name: 'Row',
                        structure: {
                            zIndex: parent.structure.zIndex,
                            x: spanMinX,
                            y: spanMinY,
                            width: spanMaxX - spanMinX,
                            height: spanMaxY - spanMinY,
                        },
                        children: spanArr,
                        style: {}
                    }];
            }
        }
    }
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        if (Array.isArray(item.children)) {
            item.children = exports.handleMergeItem(item.children, item);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleSpanGroup.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleSpanGroup.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleSpanGroup = void 0;
const utils_1 = __webpack_require__(/*! ../utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/utils.js");
//判断是否为列关系
function isSpan(item, beforeItem) {
    if (Array.isArray(item.children) &&
        Array.isArray(beforeItem.children) &&
        item.children.length == beforeItem.children.length &&
        item.children.length >= 2) {
        let centreFlag = true;
        let itemClass = item.children[0].type != 'Text' ? 'notext' : 'text';
        let beforeItemClass = beforeItem.children[0].type != 'Text' ? 'notext' : 'text';
        if (itemClass == beforeItemClass) {
            centreFlag = false;
        }
        for (let i = 0; i < item.children.length; i++) {
            const currItem = item.children[i];
            const currBeforeItem = beforeItem.children[i];
            let currClass = currItem.type != 'Text' ? 'notext' : 'text';
            if (currClass != itemClass) {
                centreFlag = false;
            }
            let beforeClass = currBeforeItem.type != 'Text' ? 'notext' : 'text';
            if (beforeClass != beforeItemClass) {
                centreFlag = false;
            }
            if (Math.abs(currItem.structure.x +
                currItem.structure.width / 2 -
                currBeforeItem.structure.x -
                currBeforeItem.structure.width / 2) > 2) {
                centreFlag = false;
            }
        }
        return centreFlag;
    }
    else {
        return false;
    }
}
// 判断是否为文本列关系
function isTextSpan(item, beforeItem) {
    if (Array.isArray(item.children) &&
        Array.isArray(beforeItem.children) &&
        item.children.length == beforeItem.children.length &&
        item.children.length >= 2) {
        let centreFlag = true;
        if (item.children[0].type !== 'Text' || beforeItem.children[0].type !== 'Text') {
            return false;
        }
        if (!item.children[0].style.textStyle.fontSize || !item.children[0].style.textStyle.fontWeight) {
            return false;
        }
        if (!beforeItem.children[0].style.textStyle.fontSize || !beforeItem.children[0].style.textStyle.fontWeight) {
            return false;
        }
        const getClass = (layer) => {
            var _a, _b, _c, _d;
            return `${(_b = (_a = layer.style) === null || _a === void 0 ? void 0 : _a.textStyle) === null || _b === void 0 ? void 0 : _b.fontSize}_${(_d = (_c = layer.style) === null || _c === void 0 ? void 0 : _c.textStyle) === null || _d === void 0 ? void 0 : _d.fontWeight}`;
        };
        let itemClass = getClass(item.children[0]);
        let beforeItemClass = getClass(beforeItem.children[0]);
        if (itemClass === beforeItemClass) {
            centreFlag = false;
        }
        for (let i = 0; i < item.children.length; i++) {
            const currItem = item.children[i];
            const currBeforeItem = beforeItem.children[i];
            let currClass = getClass(currItem);
            if (currClass != itemClass) {
                centreFlag = false;
            }
            let beforeClass = getClass(currBeforeItem);
            if (beforeClass != beforeItemClass) {
                centreFlag = false;
            }
            if (Math.abs(//不垂直居中
            currItem.structure.x +
                currItem.structure.width / 2 -
                currBeforeItem.structure.x -
                currBeforeItem.structure.width / 2) > 2
                &&
                    Math.abs(//不左对齐
                    currItem.structure.x - currBeforeItem.structure.x) > 2) {
                centreFlag = false;
            }
        }
        return centreFlag;
    }
    else {
        return false;
    }
}
exports.handleSpanGroup = (data) => {
    if (!data)
        return data;
    if (data.length > 1) {
        let totalArr = [];
        let itemArr = [data[0]];
        for (let i = 1; i < data.length; i++) {
            const item = data[i];
            const beforeItem = data[i - 1];
            if (!(itemArr.length < 2 && (isSpan(item, beforeItem) || isTextSpan(item, beforeItem)))) {
                totalArr.push(itemArr);
                itemArr = [];
            }
            itemArr.push(item);
        }
        totalArr.push(itemArr);
        if (totalArr.length > 1) {
            let dataChildren = [];
            for (let j = 0; j < totalArr.length; j++) {
                const item = totalArr[j];
                if (item.length == 1) {
                    dataChildren.push(item[0]);
                }
                else if (item.length >= 2) {
                    let spanList = {};
                    //计算span的strutrue
                    let currDivX = 0, currDivY = 0, currMaxX = 0, currMaxY = 0;
                    spanList.children = item;
                    for (let j = 0; j < spanList.children.length; j++) {
                        if (j == 0) {
                            currDivX = spanList.children[j].structure.x;
                            currDivY = spanList.children[j].structure.y;
                            currMaxX = spanList.children[j].structure.x + spanList.children[j].structure.width;
                            currMaxY = spanList.children[j].structure.y + spanList.children[j].structure.height;
                        }
                        else {
                            if (currDivX > spanList.children[j].structure.x) {
                                currDivX = spanList.children[j].structure.x;
                            }
                            if (currDivY > spanList.children[j].structure.y) {
                                currDivY = spanList.children[j].structure.y;
                            }
                            if (currMaxX <
                                spanList.children[j].structure.x + spanList.children[j].structure.width) {
                                currMaxX = spanList.children[j].structure.x + spanList.children[j].structure.width;
                            }
                            if (currMaxY <
                                spanList.children[j].structure.y + spanList.children[j].structure.height) {
                                currMaxY = spanList.children[j].structure.y + spanList.children[j].structure.height;
                            }
                        }
                    }
                    let itemList = [];
                    for (let j = 0; j < item[0].children.length; j++) {
                        const oneItem = item[0].children[j];
                        const twoItem = item[1].children[j];
                        let currDivX = Math.min(oneItem.structure.x, twoItem.structure.x), currDivY = Math.min(oneItem.structure.y, twoItem.structure.y), currMaxX = Math.max(oneItem.structure.x + oneItem.structure.width, twoItem.structure.x + twoItem.structure.width), currMaxY = Math.max(oneItem.structure.y + oneItem.structure.height, twoItem.structure.y + twoItem.structure.height);
                        itemList.push({
                            id: utils_1.uniqueId(),
                            name: 'ItemList',
                            class: 'Span',
                            type: 'Container',
                            structure: {
                                x: currDivX,
                                y: currDivY,
                                width: currMaxX - currDivX,
                                height: currMaxY - currDivY,
                            },
                            style: {},
                            children: [oneItem, twoItem]
                        });
                    }
                    dataChildren.push({
                        id: utils_1.uniqueId(),
                        name: 'List',
                        class: 'Span',
                        type: 'Container',
                        structure: {
                            x: currDivX,
                            y: currDivY,
                            width: currMaxX - currDivX,
                            height: currMaxY - currDivY,
                        },
                        style: {},
                        children: itemList
                    });
                }
            }
            data = dataChildren;
        }
        else if (data.length == 2) {
            let itemList = [];
            for (let j = 0; j < data[0].children.length; j++) {
                const oneItem = data[0].children[j];
                const twoItem = data[1].children[j];
                let currDivX = Math.min(oneItem.structure.x, twoItem.structure.x), currDivY = Math.min(oneItem.structure.y, twoItem.structure.y), currMaxX = Math.max(oneItem.structure.x + oneItem.structure.width, twoItem.structure.x + twoItem.structure.width), currMaxY = Math.max(oneItem.structure.y + oneItem.structure.height, twoItem.structure.y + twoItem.structure.height);
                itemList.push({
                    id: utils_1.uniqueId(),
                    name: 'ItemList',
                    class: 'Span',
                    type: 'Container',
                    structure: {
                        x: currDivX,
                        y: currDivY,
                        width: currMaxX - currDivX,
                        height: currMaxY - currDivY,
                    },
                    style: {},
                    children: [oneItem, twoItem]
                });
            }
            data = itemList;
        }
    }
    for (let i = 0; i < data.length; i++) {
        if (Array.isArray(data[i].children)) {
            data[i].children = exports.handleSpanGroup(data[i].children);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/index.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/index.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./handleLabelList */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleLabelList.js"), exports);
__exportStar(__webpack_require__(/*! ./handleSpanGroup */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleSpanGroup.js"), exports);
__exportStar(__webpack_require__(/*! ./handleMergeItem */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/handleMergeItem.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/utils.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/utils.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.hasBackground = exports.hasBorder = exports.isSameSpacing = exports.hasTextType = exports.isEqualHeight = exports.isEqualWidth = void 0;
// 公用方法
exports.isEqualWidth = (data) => {
    if (data.length < 2)
        return false;
    // 判断所有的元素是否等宽
    const setList = new Set();
    for (let item of data) {
        setList.add(item.structure.width);
    }
    return setList.keys.length === 1;
};
exports.isEqualHeight = (data) => {
    if (data.length < 2)
        return false;
    // 判断所有的元素是否等高
    const setList = new Set();
    for (let item of data) {
        setList.add(item.structure.height);
    }
    return setList.keys.length === 1;
};
// 第一层级只包含一个文本节点
exports.hasTextType = (data) => {
    var _a;
    let flag = false;
    for (let item of data) {
        if (item.type === "Container" && ((_a = item.children) === null || _a === void 0 ? void 0 : _a.length)) {
            let textList = [];
            for (let subItem of item.children) {
                if (subItem.type === 'Text') {
                    textList.push(subItem.name);
                }
            }
            flag = textList.length === 1;
            if (!flag) {
                break;
            }
        }
    }
    return flag;
};
// 多行之间判断是否是否相同间距
exports.isSameSpacing = (data) => {
    if (data.length < 2)
        return false;
    let flag = true;
    let space = data[1].structure.x - data[0].structure.x - data[0].structure.width;
    for (let i = 2; i < data.length; i++) {
        if (data[i].structure.y == data[i - 1].structure.y &&
            Math.abs(data[i].structure.x - data[i - 1].structure.x - data[i - 1].structure.width - space) > 2) {
            flag = false;
            break;
        }
    }
    return flag;
};
exports.hasBorder = (data) => {
    for (let item of data) {
        if (!(item.structure.border && item.structure.border.top.width)) {
            return false;
        }
    }
    return true;
};
exports.hasBackground = (data) => {
    var _a, _b;
    for (let item of data) {
        if (!((_b = (_a = item.style) === null || _a === void 0 ? void 0 : _a.background) === null || _b === void 0 ? void 0 : _b.color)) {
            return false;
        }
    }
    return true;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/const.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/const.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CLASS_TYPE = void 0;
exports.CLASS_TYPE = {
    "NORMAL": 1,
    "RELY_ON_PARENT": 2,
    "RELY_ON_CHILD_AND_PARENT": 3,
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/formatData.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/formatData.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const _format = (components, x = 0, y = 0) => {
    for (let item of components) {
        //处理成整数
        item.structure.y = Math.round(item.structure.y - y);
        item.structure.x = Math.round(item.structure.x - x);
        item.structure.width = Math.round(item.structure.width);
        item.structure.height = Math.round(item.structure.height);
        if (item.children && item.children.length) {
            _format(item.children, x, y);
        }
    }
};
exports.default = (dsl) => {
    const rootComponent = dsl[0];
    const x = rootComponent.structure.x;
    const y = rootComponent.structure.y;
    const components = rootComponent.children;
    _format(components, x, y);
    rootComponent.structure.x = 0;
    rootComponent.structure.y = 0;
    return [Object.assign(Object.assign({}, rootComponent), { children: [] }), ...rootComponent.children];
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleCascading.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleCascading.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 判断是否有包含或者重叠
 *
 * @param {*} target
 * @param {*} container
 * @returns
 */
const isContain = (target, container) => {
    if (!target.structure || !container.structure) {
        return false;
    }
    target = target.structure;
    container = container.structure;
    var targetWidth = target.width, targetHeight = target.height, targetLeft = target.x, targetRight = target.x + target.width, targetTop = target.y, targetBottom = target.y + target.height, containerWidth = container.width, containerHeight = container.height, containerLeft = container.x, containerRight = container.x + container.width, containerTop = container.y, containerBottom = container.y + container.height;
    if (targetLeft >= containerLeft &&
        targetTop >= containerTop &&
        targetRight <= containerRight &&
        targetBottom <= containerBottom) {
        return true;
    }
    return false;
};
/**
 * 判断图层是否有半透明背景
 *
 * @param {Object} layer 图层
 * @returns
 */
const isOpacityBackground = (layer) => {
    let isHasBackground = false;
    if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length) {
        layer.style.fills = layer.style.fills.filter((fillItem) => {
            return fillItem.isEnabled;
        });
    }
    if (layer.backgroundColor && layer.hasBackgroundColor) {
        const { alpha } = layer.backgroundColor;
        if (0 < alpha && alpha < 1) {
            isHasBackground = true;
        }
    }
    else if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length &&
        layer.style.fills[layer.style.fills.length - 1].isEnabled) {
        // 处理填充 fills,fills是数组，只支持单个情况,处理成背景色
        const fillStyle = layer.style.fills[layer.style.fills.length - 1];
        let { alpha, red, green, blue } = fillStyle.color;
        // 如果设置了 Opacity 属性，则 fills border 需要乘于这个数值
        if (layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * alpha;
        }
        if (0 < alpha && alpha < 1) {
            isHasBackground = true;
        }
    }
    return isHasBackground;
};
const isNotOpacityBackground = (layer) => {
    let isHasBackground = false;
    if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length) {
        layer.style.fills = layer.style.fills.filter((fillItem) => {
            return fillItem.isEnabled;
        });
    }
    if (layer.backgroundColor && layer.hasBackgroundColor) {
        const { alpha, red, green, blue } = layer.backgroundColor;
        if (alpha == 1) {
            isHasBackground = true;
        }
    }
    else if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length &&
        layer.style.fills[layer.style.fills.length - 1].isEnabled) {
        // 处理填充 fills,fills是数组，只支持单个情况,处理成背景色
        const fillStyle = layer.style.fills[layer.style.fills.length - 1];
        let { alpha, red, green, blue } = fillStyle.color;
        // 如果设置了 Opacity 属性，则 fills border 需要乘于这个数值
        if (layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * alpha;
        }
        if (alpha == 1) {
            isHasBackground = true;
        }
    }
    return isHasBackground;
};
// 判断是否为底栏
const isBottomBar = (layer, artLayer) => {
    if (layer.structure &&
        artLayer.structure &&
        isNotOpacityBackground(layer) &&
        layer.isVisible &&
        layer.structure.x == artLayer.structure.x &&
        layer.structure.width == artLayer.structure.width &&
        layer.structure.y + layer.structure.height ==
            artLayer.structure.y + artLayer.structure.height &&
        layer.structure.height > 40 &&
        layer.structure.height < 140) {
        return true;
    }
    return false;
};
const handleCascading = (data) => {
    let cascadingJson = {};
    //基础层JSON
    let baseJson = JSON.parse(JSON.stringify(data));
    if (data.children.length === 1) {
        let artLayer = data.children[0];
        let vFlag = true;
        let flag = true;
        //依据全屏弹层对json进行分割
        function findFullLayer(data) {
            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
            if (!data.children)
                return data;
            for (let i = 0; i < data.children.length; i++) {
                const layer = data.children[i];
                if (layer.isVisible &&
                    layer.type === 'Container' &&
                    ((_a = layer.structure) === null || _a === void 0 ? void 0 : _a.x) <= ((_b = artLayer.structure) === null || _b === void 0 ? void 0 : _b.x) + 1 &&
                    ((_c = layer.structure) === null || _c === void 0 ? void 0 : _c.y) <= ((_d = artLayer.structure) === null || _d === void 0 ? void 0 : _d.y) + 1 &&
                    ((_e = layer.structure) === null || _e === void 0 ? void 0 : _e.x) + ((_f = layer.structure) === null || _f === void 0 ? void 0 : _f.width) >=
                        ((_g = artLayer.structure) === null || _g === void 0 ? void 0 : _g.width) + ((_h = artLayer.structure) === null || _h === void 0 ? void 0 : _h.x) - 1 &&
                    ((_j = layer.structure) === null || _j === void 0 ? void 0 : _j.y) + ((_k = layer.structure) === null || _k === void 0 ? void 0 : _k.height) >=
                        ((_l = artLayer.structure) === null || _l === void 0 ? void 0 : _l.height) + ((_m = artLayer.structure) === null || _m === void 0 ? void 0 : _m.y) - 1) {
                    if (layer.style.background.color.alpha > 0 && layer.style.background.color.alpha < 1 && flag) {
                        flag = false;
                        vFlag = !vFlag;
                    }
                    layer.structure.x = artLayer.structure.x;
                    layer.structure.y = artLayer.structure.y;
                    layer.structure.width = artLayer.structure.width;
                    layer.structure.height = artLayer.structure.height;
                }
                if (vFlag) {
                    layer.isVisible = false;
                }
                if (Array.isArray(layer.children) && layer.children.length) {
                    findFullLayer(layer);
                }
            }
            return data;
        }
        //属于弹层的JSON
        cascadingJson = findFullLayer(JSON.parse(JSON.stringify(data)));
        vFlag = false;
        flag = true;
        //弹层下面的JSON
        baseJson = findFullLayer(JSON.parse(JSON.stringify(data)));
    }
    return {
        baseJson,
        cascadingJson,
    };
};
exports.default = handleCascading;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleLayer.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleLayer.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 冗余html结构处理
 * 1.Container 子元素无背景，无边框属于无意义元素 -删除子元素处理
 * 2.Container 子元素有背景或者边框，父元素无背景及边框-删除父元素
 * 3.Image 父元素无背景及边框-删除父元素
 * 4.Image 子元素与父元素位置大小完全相同 -删除父元素
 * 5.父元素为artboard的情况下，不删除父元素
 * @param {Array} item
 */
const handleSingleLayer = (item) => {
    var _a, _b;
    if (item.children && item.children.length == 1 && !(item.type == 'Mask' && item.style['border-radius'])) {
        //Container 子元素无背景，无边框属于无意义元素 -删除子元素处理
        if (item.children[0].type == 'Container' || (!item.children[0].type && (item.children[0].sign === '__li' || item.children[0].sign === '__oth'))) {
            if (!item.children[0].textContainer &&
                !item.children[0].structure.border &&
                item.children[0]._class != 'artboard' &&
                !item.children[0].style.transform &&
                !item.children[0].style.background &&
                !item.children[0].isList) {
                if (item.children[0].children) {
                    item.children = JSON.parse(JSON.stringify(item.children[0].children));
                }
                else {
                    item.children = [];
                }
                item = handleSingleLayer(item);
            }
            //Container 子元素有背景或者边框 且父元素不为artboard
            else if (item._class != 'artboard' && !item.style.transform) {
                //父元素无背景及边框-删除父元素
                if (item.type === 'Container' && !item.children[0].structure.border && !item.style.background && !item.style.borderRadius) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                    //子元素有背景色，父子结构大小完全相同-删除父元素
                    /* eslint-disable */
                }
                else if (((_b = (_a = item.children[0].style.background) === null || _a === void 0 ? void 0 : _a.color) === null || _b === void 0 ? void 0 : _b.alpha) === 1 &&
                    !item.style.borderRadius &&
                    item.children[0].structure.height === item.structure.height &&
                    item.children[0].structure.width === item.structure.width &&
                    item.children[0].structure.x === item.structure.x &&
                    item.children[0].structure.y === item.structure.y) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                }
                /* eslint-disable */
            }
        }
        //Image
        else if (item.children[0].type == 'Image' && item._class != 'artboard' && !item.style['transform']) {
            //父元素无背景及边框-删除父元素
            if (item.type == 'Container') {
                if (!item.structure.border && !item.style.background) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                    //子元素与父元素完全相同-删除父元素
                }
                else if (item.children[0].structure.height === item.structure.height &&
                    item.children[0].structure.width === item.structure.width &&
                    item.children[0].structure.x === item.structure.x &&
                    item.children[0].structure.y === item.structure.y &&
                    !item.style.background) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                }
            }
        }
        //Text -暂时不处理
        else if (item.children[0].type === 'Text') {
            //父元素无背景及边框-删除父元素
            // if (item.type==Container) {
            //   if (!item.style['border']&&!item.style['background']) {
            //     item =item.children[0];
            //     item= handleSingleLayer(item);
            //   }
            // }
        }
    }
    return item;
};
const handleLayer = (data) => {
    for (let i = 0; i < data.length; i++) {
        data[i] = handleSingleLayer(data[i]);
        if (Array.isArray(data[i].children)) {
            data[i].children = handleLayer(data[i].children);
        }
    }
    return data;
};
exports.default = handleLayer;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleRow.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleRow.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const const_1 = __webpack_require__(/*! ./const */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/const.js");
const utils_1 = __webpack_require__(/*! ./utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/utils.js");
const handleSpan = (data) => {
    let positionList = [];
    let noPostionList = [];
    data.forEach((item) => {
        if (item.isPosition) {
            positionList.push(item);
        }
        else {
            noPostionList.push(item);
        }
    });
    data = noPostionList;
    //让宽度最大的元素放在最前面
    data = data.sort((a, b) => b.structure.width - a.structure.width);
    //处理进行分列
    //同列的元素外面加一个Span容器
    // 结构调整data
    //children本身全部在一行的不需要加Span容器
    let assignSpanList = [];
    for (let i = 0; i < data.length; i++) {
        let flag = true;
        for (let j = 0; j < assignSpanList.length; j++) {
            //属于哪个容器就放到哪个容器中
            for (let n = 0; n < assignSpanList[j].length; n++) {
                if (flag && ((assignSpanList[j][n].structure.x <= data[i].structure.x && data[i].structure.x < (+assignSpanList[j][n].structure.x + assignSpanList[j][n].structure.width)) ||
                    (+assignSpanList[j][n].structure.x < +data[i].structure.x + data[i].structure.width && +data[i].structure.x + data[i].structure.width <= (+assignSpanList[j][n].structure.x + assignSpanList[j][n].structure.width)))) {
                    assignSpanList[j].push(data[i]);
                    flag = false;
                }
            }
        }
        //都不属于则新建容器，放入其中
        if (flag) {
            assignSpanList.push([data[i]]);
        }
    }
    //children本身全部在一列的不需要加Span容器
    if (data.length == assignSpanList[0].length) {
        assignSpanList = assignSpanList[0].map(item => [item]);
    }
    /**
     * 分列完成后，给属于同一列的加容器
     * 同时给容器赋值x,y,width,height
     * 获取结构调整后的data
     */
    let spanList = [];
    for (let i = 0; i < assignSpanList.length; i++) {
        if (assignSpanList[i].length == 1) {
            spanList.push(assignSpanList[i][0]);
        }
        else {
            let currSpan = [], currDivX = 0, currDivY = 0, currMaxX = 0, currMaxY = 0, zIndex = 0;
            currSpan = assignSpanList[i].sort((a, b) => a.structure.y - b.structure.y);
            // currSpan = assignSpanList[i];
            zIndex = currSpan[0].structure.zIndex;
            for (let j = 0; j < currSpan.length; j++) {
                zIndex = currSpan[j].structure.zIndex > zIndex ? currSpan[j].structure.zIndex : zIndex;
                if (j == 0) {
                    currDivX = currSpan[j].structure.x;
                    currDivY = currSpan[j].structure.y;
                    currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                }
                else {
                    if (currDivX > currSpan[j].structure.x) {
                        currDivX = currSpan[j].structure.x;
                    }
                    if (currDivY > currSpan[j].structure.y) {
                        currDivY = currSpan[j].structure.y;
                    }
                    if (currMaxX < currSpan[j].structure.x + currSpan[j].structure.width) {
                        currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    }
                    if (currMaxY < currSpan[j].structure.y + currSpan[j].structure.height) {
                        currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                    }
                }
            }
            spanList.push({
                id: utils_1.uniqueId(),
                name: 'Span1',
                class: 'Span',
                type: 'Container',
                structure: {
                    zIndex,
                    x: currDivX,
                    y: currDivY,
                    width: currMaxX - currDivX,
                    height: currMaxY - currDivY,
                },
                children: currSpan,
                style: {}
            });
        }
    }
    data = spanList.sort((a, b) => a.structure.x - b.structure.x);
    data = [...data, ...positionList];
    return data;
};
//分行处理
//判断是否为同一行
//同一行给予DIV包裹并且将该行元素作为DIV的子元素
function isSame(data) {
    let flag = true;
    if (Array.isArray(data) && data.length > 2) {
        let firstItemWidth = data[0].structure.width;
        let firstItemHeight = data[0].structure.height;
        data.forEach((item) => {
            if (Math.abs(firstItemWidth - item.structure.width) > 1 || Math.abs(firstItemHeight - item.structure.height) > 1) {
                flag = false;
            }
        });
    }
    return flag;
}
//判断属于左边的图片
const isLeftImg = (layer, parent) => {
    //必须为图片类型
    if (layer.type !== 'Image') {
        return false;
    }
    //距离画板左边的距离<100
    if (layer.structure.x > 100) {
        return false;
    }
    //距离画板左边的距离<100
    if (layer.structure.width < 40) {
        return false;
    }
    //父元素必须存在
    if (!parent) {
        return false;
    }
    //容器的宽度>750*0.7
    if (parent.structure.width < 750 * 0.7) {
        return false;
    }
    for (let i = 1; i < parent.children.length; i++) {
        const item = parent.children[i];
        if (item.structure.x < layer.structure.x + layer.structure.width) {
            return false;
        }
    }
    return true;
};
const isLeftImgRightInfo = (item) => {
    if (Array.isArray(item.children) && item.children.length > 3 && isLeftImg(item.children[0], item)) {
        let itemChildren = [...item.children];
        let firstChildren = itemChildren.shift();
        let currSpan = itemChildren;
        let flag = false;
        for (let j = 0; j < currSpan.length; j++) {
            let item = currSpan[j];
            for (let i = j; i < currSpan.length; i++) {
                const itemI = currSpan[i];
                if (((itemI.structure.x + itemI.structure.width > item.structure.x && item.structure.x >= itemI.structure.x) ||
                    (item.structure.x + item.structure.width > itemI.structure.x && itemI.structure.x >= item.structure.x)) && (item.structure.y + item.structure.height <= itemI.structure.y ||
                    itemI.structure.y + itemI.structure.height <= item.structure.y)) {
                    flag = true;
                }
            }
        }
        if (flag) {
            let currDivX, currDivY, currMaxX, currMaxY;
            let zIndex = currSpan[0].structure.zIndex;
            for (let j = 0; j < currSpan.length; j++) {
                zIndex = currSpan[j].structure.zIndex > zIndex ? currSpan[j].structure.zIndex : zIndex;
                if (j == 0) {
                    currDivX = currSpan[j].structure.x;
                    currDivY = currSpan[j].structure.y;
                    currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                }
                else {
                    if (currDivX > currSpan[j].structure.x) {
                        currDivX = currSpan[j].structure.x;
                    }
                    if (currDivY > currSpan[j].structure.y) {
                        currDivY = currSpan[j].structure.y;
                    }
                    if (currMaxX < currSpan[j].structure.x + currSpan[j].structure.width) {
                        currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    }
                    if (currMaxY < currSpan[j].structure.y + currSpan[j].structure.height) {
                        currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                    }
                }
            }
            item.name = 'LeftImgRightInfo';
            firstChildren.class_name = 'left';
            firstChildren.class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
            item.children = [firstChildren, {
                    id: utils_1.uniqueId(),
                    name: 'Span2',
                    class: 'Span',
                    type: 'Container',
                    structure: {
                        zIndex,
                        x: currDivX,
                        y: currDivY,
                        width: currMaxX - currDivX,
                        height: currMaxY - currDivY,
                    },
                    children: currSpan,
                    style: {},
                    class_name: 'right',
                    class_type: const_1.CLASS_TYPE.RELY_ON_PARENT,
                }];
        }
        else {
            item.children = handleSpan(item.children);
        }
        return item;
    }
    else {
        item.children = handleSpan(item.children);
    }
    return item;
};
//上下合并
const handleMerge = (data) => {
    let leftRItem = {};
    let flag = false;
    for (let i = 0; i < data.length; i++) {
        if (flag) {
            let secondChild = leftRItem.children[1];
            if (data[i].structure.x > secondChild.structure.x - 2) {
                secondChild.children.push(Object.assign({}, data[i]));
                secondChild.structure.height = data[i].structure.y + data[i].structure.height - secondChild.structure.y;
                leftRItem.structure.height = data[i].structure.y + data[i].structure.height - leftRItem.structure.y;
                if (secondChild.structure.width + secondChild.structure.x < data[i].structure.x + data[i].structure.width) {
                    secondChild.structure.width = data[i].structure.x + data[i].structure.width - secondChild.structure.x;
                }
                leftRItem.structure.width = secondChild.structure.width + secondChild.structure.x - leftRItem.structure.x;
                data[i].delete = true;
            }
            else {
                flag = false;
            }
        }
        if (data[i].name == 'LeftImgRightInfo') {
            flag = true;
            leftRItem = data[i];
        }
    }
    return data.filter(item => !item.delete);
};
const handleRow = (data, parent) => {
    if (parent && parent.textContainer) {
        return data;
    }
    if (isSame(data)) {
        //递归处理children
        for (let i = 0; i < data.length; i++) {
            if (Array.isArray(data[i].children) && data[i].children.length > 0) {
                data[i].children = handleRow(data[i].children, data[i]);
            }
        }
        return data;
    }
    //让高度最大的元素放在最前面
    data = data.sort((a, b) => b.structure.height - a.structure.height);
    //处理进行分行
    //同行的元素外面加一个Row容器
    // 结构调整data
    //children本身全部在一行的不需要加Row容器
    //let assignRowList = [];
    // let rowArr = [];
    // for (let i = 0; i < data.length; i++) {
    //     let flag = true;
    //     if (rowArr.length > 0) {
    //         flag = false;
    //         for (let j = 0; j < rowArr.length; j++) {
    //             const item = rowArr[j];
    //             if (data[i].structure.y + data[i].structure.height > item.structure.y && item.structure.y + item.structure.height > data[i].structure.y) {
    //                 flag = true;
    //             }
    //         }
    //         if (!flag) {
    //             assignRowList.push(rowArr);
    //             rowArr = [];
    //         }
    //     }
    //     rowArr.push(data[i]);
    // }
    // if (rowArr.length > 0) {
    //     if (rowArr.length == data.length) {
    //         //等待华哥算法更新后 过滤掉其中已经处理的部分
    //         if (parent && parent.type != '__li') {
    //             data = handleSpan(data);
    //         }
    //         for (let i = 0; i < data.length; i++) {
    //             if (Array.isArray(data[i].children) && data[i].children.length > 0) {
    //                 data[i].children = handleRow(data[i].children, data[i]);
    //             }
    //         }
    //         return data;
    //     } else {
    //         assignRowList.push(rowArr);
    //     }
    // }
    let assignRowList = [];
    for (let i = 0; i < data.length; i++) {
        let flag = true;
        for (let j = 0; j < assignRowList.length; j++) {
            //属于哪个容器就放到哪个容器中
            for (let n = 0; n < assignRowList[j].length; n++) {
                if (flag && ((assignRowList[j][n].structure.y <= data[i].structure.y && data[i].structure.y < (+assignRowList[j][n].structure.y + assignRowList[j][n].structure.height)) ||
                    (+assignRowList[j][n].structure.y < +data[i].structure.y + data[i].structure.height && +data[i].structure.y + data[i].structure.height <= (+assignRowList[j][n].structure.y + assignRowList[j][n].structure.height)))) {
                    assignRowList[j].push(data[i]);
                    flag = false;
                }
            }
        }
        //都不属于则新建容器，放入其中
        if (flag) {
            assignRowList.push([data[i]]);
        }
    }
    /**
     * 分行完成后，给属于同一行的加容器
     * 同时给容器赋值x,y,width,height
     * 获取结构调整后的data
     */
    let rowList = [];
    //children本身全部在一行的不需要加Row容器
    if (assignRowList.length && data.length == assignRowList[0].length) {
        if (parent && parent.sign != '__li') {
            rowList = handleSpan(assignRowList[0]);
        }
        else {
            rowList = assignRowList[0];
        }
        if (parent) {
            parent.class = 'Row';
        }
    }
    else {
        for (let i = 0; i < assignRowList.length; i++) {
            if (assignRowList[i].length == 1) {
                //分行之后进行分列
                if (assignRowList[i][0].children && assignRowList[i].name == 'Row') {
                    assignRowList[i][0].children = handleSpan(assignRowList[i][0].children);
                }
                rowList.push(assignRowList[i][0]);
            }
            else {
                let currRow = [], currDivX = 0, currDivY = 0, currMaxX = 0, currMaxY = 0, zIndex = 0;
                currRow = assignRowList[i].sort((a, b) => a.structure.x - b.structure.x);
                zIndex = currRow[0].structure.zIndex;
                for (let j = 0; j < currRow.length; j++) {
                    zIndex = currRow[j].structure.zIndex > zIndex ? currRow[j].structure.zIndex : zIndex;
                    if (j == 0) {
                        currDivX = currRow[j].structure.x;
                        currDivY = currRow[j].structure.y;
                        currMaxX = currRow[j].structure.x + currRow[j].structure.width;
                        currMaxY = currRow[j].structure.y + currRow[j].structure.height;
                    }
                    else {
                        if (currDivX > currRow[j].structure.x) {
                            currDivX = currRow[j].structure.x;
                        }
                        if (currDivY > currRow[j].structure.y) {
                            currDivY = currRow[j].structure.y;
                        }
                        if (currMaxX < currRow[j].structure.x + currRow[j].structure.width) {
                            currMaxX = currRow[j].structure.x + currRow[j].structure.width;
                        }
                        if (currMaxY < currRow[j].structure.y + currRow[j].structure.height) {
                            currMaxY = currRow[j].structure.y + currRow[j].structure.height;
                        }
                    }
                }
                //分行之后进行分列表
                let currWidth = currMaxX - currDivX;
                let currX = currDivX;
                //特征分列
                let item = isLeftImgRightInfo({
                    id: utils_1.uniqueId(),
                    class: 'Row',
                    type: 'Container',
                    name: 'Row',
                    structure: {
                        zIndex,
                        x: currX,
                        y: currDivY,
                        width: currWidth,
                        height: currMaxY - currDivY,
                    },
                    children: currRow,
                    style: {}
                });
                // if (parent && parent.structure.width) {
                //     currWidth = parent.structure.width;
                //     currX = parent.structure.x;
                //     // 处理border的影响
                //     if (parent.border && parent.border.structure.width) {
                //         currWidth = currWidth - parent.border.structure.width * 2;
                //         currX = currX + parent.border.structure.width;
                //     }
                // }
                rowList.push(item);
            }
        }
    }
    // data = [...data,...positionList];
    data = rowList.sort((a, b) => a.structure.y - b.structure.y);
    data = handleMerge(data);
    //递归处理children
    for (let i = 0; i < data.length; i++) {
        if (Array.isArray(data[i].children) && data[i].children.length > 0) {
            data[i].children = handleRow(data[i].children, data[i]);
        }
    }
    return data;
};
exports.default = handleRow;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/index.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/index.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const IdentifyLayout_1 = __webpack_require__(/*! ./IdentifyLayout */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/IdentifyLayout/index.js");
const handleLayer_1 = __webpack_require__(/*! ./handleLayer */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleLayer.js");
const handleCascading_1 = __webpack_require__(/*! ./handleCascading */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleCascading.js");
const recombine_1 = __webpack_require__(/*! ./recombine */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/index.js");
const formatData_1 = __webpack_require__(/*! ./formatData */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/formatData.js");
const handleRow_1 = __webpack_require__(/*! ./handleRow */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/handleRow.js");
const styleFix_1 = __webpack_require__(/*! ./styleFix */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/styleFix.js");
/**
 * 处理单层图层结构
 */
exports.default = (dsl) => {
    var _a;
    let { baseJson, cascadingJson } = handleCascading_1.default(dsl[0]);
    [baseJson, cascadingJson] = [baseJson, cascadingJson].map(dsl => {
        if (Object.keys(dsl).length === 0) {
            return [];
        }
        // 格式化
        dsl = formatData_1.default([dsl]);
        // 结构处理 方案1 
        // dsl = domFormat(dsl);
        // 结构处理 方案2
        dsl = recombine_1.default(dsl);
        // 行列处理
        dsl = handleRow_1.default(dsl);
        // 列合并
        dsl = IdentifyLayout_1.handleSpanGroup(dsl);
        // 多label标签识别
        dsl = IdentifyLayout_1.handleLabelList(dsl);
        // 同一行中依据元素的聚合特性进行合并
        dsl = IdentifyLayout_1.handleMergeItem(dsl);
        // 处理冗余结构
        dsl = handleLayer_1.default(dsl);
        // 样式修正处理
        dsl = styleFix_1.default(dsl);
        return dsl;
    });
    if (Array.isArray((_a = cascadingJson[0]) === null || _a === void 0 ? void 0 : _a.children)) {
        cascadingJson[0].children = cascadingJson[0].children.map(item => {
            item.isPosition = true;
            return item;
        });
        if (!baseJson[0].children) {
            baseJson[0].children = [];
        }
        baseJson[0].children = [...baseJson[0].children, ...cascadingJson[0].children];
    }
    return baseJson;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/handleDelete.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/handleDelete.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const isCover_1 = __webpack_require__(/*! ./isCover */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/isCover.js");
/**
 * 反向覆盖的元素则进行定位处理
 */
const handleDelete = (data) => {
    for (let i = 0; i < data.length; i++) {
        const currItemI = data[i];
        // if (currItemI.width <= 1) {
        //     console.log(1111)
        //   currItemI.isPosition = true;
        // }
        for (let j = i; j < data.length; j++) {
            const currItemJ = data[j];
            if (currItemI.structure.zIndex > currItemJ.structure.zIndex &&
                isCover_1.default(currItemI, currItemJ)) {
                if (/\,1\)/.test(currItemI.style['background-color'])) {
                    currItemJ.isDelete = true;
                }
                // if (!currItemI.isPosition) {
                //   currItemI.isPosition = true;
                // }
            }
            else if (currItemI.structure.zIndex < currItemJ.structure.zIndex &&
                isCover_1.default(currItemJ, currItemI)) {
                if (/\,1\)/.test(currItemJ.style['background-color'])) {
                    currItemI.isDelete = true;
                }
                // if (!currItemJ.isPosition) {
                //   currItemJ.isPosition = true;
                // }
            }
            //   else if(j!=i&&handleOver(JSON.parse(JSON.stringify(currItemI)),currItemJ)>0){
            //     if (currItemI.structure.zIndex >currItemJ.structure.zIndex ) {
            //         console.log(4111)
            //       currItemI.isPosition = true;
            //     }else{
            //         console.log(5111)
            //       currItemJ.isPosition = true;
            //     }
            //   }
        }
    }
    // 去掉需要删除的
    data = data.filter((item) => !item.isDelete);
    //递归处理children
    for (let i = 0; i < data.length; i++) {
        if (Array.isArray(data[i].children) && data[i].children.length > 0) {
            data[i].children = handleDelete(data[i].children);
        }
    }
    return data;
};
exports.default = handleDelete;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/handleOver.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/handleOver.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理超出
 * @param {*} targetLayer 被比较的图层
 * @param {*} currLayer 比较的图层
 */
exports.default = (targetLayer, currLayer) => {
    if (!targetLayer || !currLayer) {
        return -1;
    }
    let targetLayerLeft = targetLayer.structure.x, targetLayerRight = targetLayer.structure.x + targetLayer.structure.width, targetLayerTop = targetLayer.structure.y, targetLayerBottom = targetLayer.structure.y + targetLayer.structure.height, currLayerLeft = currLayer.structure.x, currLayerRight = currLayer.structure.x + currLayer.structure.width, currLayerTop = currLayer.structure.y, currLayerBottom = currLayer.structure.y + currLayer.structure.height;
    if (currLayerLeft > targetLayerLeft) {
        targetLayer.structure.x = currLayer.structure.x;
        targetLayer.structure.width =
            targetLayer.structure.width - (currLayerLeft - targetLayerLeft) > 0
                ? targetLayer.structure.width - (currLayerLeft - targetLayerLeft)
                : 0;
    }
    if (currLayerTop > targetLayerTop) {
        targetLayer.structure.y = currLayer.structure.y;
        targetLayer.structure.height =
            targetLayer.structure.height - (currLayerTop - targetLayerTop) > 0
                ? targetLayer.structure.height - (currLayerTop - targetLayerTop)
                : 0;
    }
    if (currLayerBottom < targetLayerBottom) {
        targetLayer.structure.height =
            targetLayer.structure.height - (targetLayerBottom - currLayerBottom) > 0
                ? targetLayer.structure.height - (targetLayerBottom - currLayerBottom)
                : 0;
    }
    if (currLayerRight < targetLayerRight) {
        targetLayer.structure.width =
            targetLayer.structure.width - (targetLayerRight - currLayerRight) > 0
                ? targetLayer.structure.width - (targetLayerRight - currLayerRight)
                : 0;
    }
    return targetLayer.structure.width * targetLayer.structure.height;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/index.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/index.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleOver_1 = __webpack_require__(/*! ./handleOver */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/handleOver.js");
const handleDelete_1 = __webpack_require__(/*! ./handleDelete */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/handleDelete.js");
const recombineTreeDataNew = (data) => {
    let currRecord = data[data.length - 1];
    if (data.length > 1) {
        let preLength = data.length;
        for (let i = 0; i < data.length - 1; i++) {
            let record = data[data.length - 2 - i];
            if (currRecord.parentId) {
                if (currRecord.parentId === record.id) {
                    if (!record.children) {
                        record.children = [];
                    }
                    record.children.unshift(JSON.parse(JSON.stringify(currRecord)));
                    data.length = data.length - 1;
                    break;
                }
            }
            else if (isContain(currRecord, record, data[0])) {
                if (!record.children) {
                    record.children = [];
                }
                record.children.unshift(JSON.parse(JSON.stringify(currRecord)));
                data.length = data.length - 1;
                break;
            }
        }
        if (preLength > data.length) {
            recombineTreeDataNew(data);
        }
    }
    return data;
};
const isContain = (target, container, artboard) => {
    if (!target || !container) {
        return false;
    }
    // 如果容器是画板，所有元素都被画板包含
    if (container.id === artboard.id) {
        return true;
    }
    // 如果是旋转
    if (container.istransformContain) {
        return false;
    }
    if (target.structure.x <= container.structure.x &&
        target.structure.y <= container.structure.y &&
        target.structure.x + target.structure.width >=
            container.structure.x + container.structure.width &&
        target.structure.y + target.structure.height >=
            container.structure.y + container.structure.height &&
        !(target.structure.x == container.structure.x &&
            target.structure.y == container.structure.y &&
            target.structure.x + target.structure.width ==
                container.structure.x + container.structure.width &&
            target.structure.y + target.structure.height ==
                container.structure.y + container.structure.height)) {
        return false;
    }
    let currTarget = JSON.parse(JSON.stringify(target));
    let curr = handleOver_1.default(currTarget, container);
    let targetH = target.structure.height;
    if (artboard.structure.y + artboard.structure.height - target.structure.y <
        targetH) {
        targetH =
            artboard.structure.y +
                artboard.structure.height -
                target.structure.y;
        targetH = targetH < 0 ? 0 : targetH;
    }
    if (curr > target.structure.width * targetH * 0.3) {
        return true;
    }
    return false;
};
exports.default = (data, currIndex = { num: 0 }) => {
    // 记录层级标识
    data = data.map((item) => {
        currIndex.num = currIndex.num + 1;
        item.structure.zIndex = currIndex.num;
        return item;
    });
    data = recombineTreeDataNew(data);
    data = handleDelete_1.default(data);
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/isCover.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/recombine/isCover.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 判断包含关系
 * @param {*} target
 * @param {*} contain
 */
const isCover = (target, contain) => {
    if (target.structure.x <= contain.structure.x &&
        target.structure.y <= contain.structure.y &&
        target.structure.x + target.structure.y >= contain.structure.x + contain.structure.y &&
        target.structure.y + target.structure.y >= contain.structure.y + contain.structure.y &&
        !(target.structure.x == contain.structure.x &&
            target.structure.y == contain.structure.y &&
            target.structure.x + target.structure.y == contain.structure.x + contain.structure.y &&
            target.structure.y + target.structure.y == contain.structure.y + contain.structure.y)) {
        return true;
    }
    return false;
};
exports.default = isCover;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/styleFix.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/styleFix.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const styleFix = (dsl) => {
    dsl.map((layer) => {
        var _a;
        // 图片包含子元素的情况
        if (layer.type === 'Image' && ((_a = layer.children) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            layer.type = 'Container';
            layer.style.background = {
                image: {
                    url: layer.value
                },
                size: {
                    width: layer.structure.width,
                    height: layer.structure.height
                }
            };
            delete layer.style.borderRadius;
        }
        if (Array.isArray(layer.children)) {
            layer.children = styleFix(layer.children);
        }
        return layer;
    });
    return dsl;
};
exports.default = styleFix;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/utils.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/utils.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.uniqueId = void 0;
exports.uniqueId = () => {
    return Math.random().toString(32).substr(2, 8);
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateBlock.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateBlock.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleTypeLayout_1 = __webpack_require__(/*! ./handleTypeLayout */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/index.js");
/**
 * 全部为块元素的竖直方向布局
 *
 * @param {*} data
 * @param {*} parent
 * @returns
 */
const calculateBlock = (data, parent) => {
    var _a, _b, _c, _d, _e;
    data = data.sort((a, b) => a.structure.y - b.structure.y);
    //边框处理
    const pBorderWidth = ((_c = (_b = (_a = parent.structure) === null || _a === void 0 ? void 0 : _a.border) === null || _b === void 0 ? void 0 : _b.top) === null || _c === void 0 ? void 0 : _c.width) || 0;
    for (let i = 0; i < data.length; i++) {
        if (!data[i].style) {
            data[i].style = {};
        }
        data[i].style.width = data[i].structure.width;
        if (handleTypeLayout_1.isCenter(data[i], parent)) {
            data[i].isCenter = true;
        }
        if (handleTypeLayout_1.isSingleText(data[i]) && data[i].style.textAlign === 'left') {
            delete data[i].style.width;
        }
        const marginLeft = data[i].structure.x - parent.structure.x - pBorderWidth;
        if (marginLeft) {
            data[i].style.marginLeft = marginLeft;
        }
        //假设所有单行文本都是填满的
        if (handleTypeLayout_1.isSingleText(data[i]) &&
            Math.abs(parent.structure.x + parent.structure.width * 0.5 - (data[i].structure.x + data[i].structure.width * 0.5)) < 3) {
            data[i].style.textAlign = 'center';
            delete data[i].style.width;
            delete data[i].style.marginLeft;
            //去掉 子元素宽度与父元素相同时情况 
        }
        else if (!handleTypeLayout_1.isSingleText(data[i]) && Math.abs(parent.structure.x + parent.structure.width * 0.5 - (data[i].structure.x + data[i].structure.width * 0.5)) < 3 && parent.structure.width != data[i].structure.width) {
            if (data[i].style.display === 'flex' && data[i].textContainer) { //单行多样式文本的处理
                data[i].style.justifyContent = 'center';
                delete data[i].style.width;
                delete data[i].style.marginLeft;
                delete data[i].style.marginRight;
            }
        }
        if (i > 0) {
            let marginTop = data[i].structure.y - (data[i - 1].structure.y + data[i - 1].structure.height);
            if (marginTop) {
                data[i].style.marginTop = marginTop;
            }
        }
        else {
            let pBorderTop = ((_e = (_d = parent.structure.border) === null || _d === void 0 ? void 0 : _d.top) === null || _e === void 0 ? void 0 : _e.width) || 0;
            let paddingTop = data[i].structure.y - parent.structure.y - pBorderWidth - pBorderTop;
            if (paddingTop) {
                data[i].style.marginTop = paddingTop;
                parent.style.paddingTop = 0.1;
            }
        }
    }
    return data;
};
exports.default = calculateBlock;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateClassName.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateClassName.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleContinuousListItem = exports.calculateLeftImgRightInfo = exports.isLeftImgRightInfo = exports.calculateVerticalList = exports.isVerticalList = void 0;
const const_1 = __webpack_require__(/*! ./const */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/const.js");
/**
 * 判断是否为竖排列表
 * @param {Array} data
 *
 */
exports.isVerticalList = (data) => {
    if (!(Array.isArray(data) && data.length > 1)) {
        return false;
    }
    if (data.findIndex(item => item.sign !== '__li') > -1) {
        return false;
    }
    const firstItem = data[0];
    for (let i = 1; i < data.length; i++) {
        const currItem = data[i];
        if (Math.abs(currItem.structure.width - firstItem.structure.width) > 3) {
            return false;
        }
        if (Math.abs((currItem.structure.x + currItem.structure.width * 0.5) - (firstItem.structure.x + firstItem.structure.width * 0.5)) > 3) {
            return false;
        }
    }
    return true;
};
/**
 * 处理竖排的className
 * @param {Array} data
 * @param {Object} parent
 */
exports.calculateVerticalList = (data) => {
    const firstItem = data[0];
    for (let i = 1; i < data.length; i++) {
        const currItem = data[i];
        if (Math.abs(currItem.structure.height - firstItem.structure.height) > 2) {
            data[i].structure.height = firstItem.structure.height;
        }
    }
    data = data.map(item => {
        item.class_name = 'li';
        item.class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
        return item;
    });
    return data;
};
/**
 * 判断左边图片右边信息的左右布局
 * @param {*} data
 * @param {*} parent
 */
exports.isLeftImgRightInfo = (data) => {
    if (Array.isArray(data) &&
        data.length === 2 &&
        data[0].type === 'Image' &&
        Array.isArray(data[1].children) &&
        data[1].children.length >= 3) {
        return true;
    }
    return false;
};
/**
 * 为左边图片右边信息的结构添加className
 * @param {*} data
 * @param {*} parent
 */
exports.calculateLeftImgRightInfo = (data) => {
    data[0].class_name = 'thumb';
    data[0].class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    data[1].class_name = 'info';
    data[1].class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    return data;
};
/**
 * 连续的列表项结构
 * @param {*} data
 * @param {*} parent
 */
exports.handleContinuousListItem = (data) => {
    if (!Array.isArray(data) || data.length < 2) {
        return data;
    }
    //列表起始项
    let currStartItem = data[0];
    //列表起始项
    let currStartIndex = 0;
    //列表中项的数量
    let num = 1;
    //列表总数量
    let count = 0;
    for (let i = 1; i < data.length; i++) {
        const currItem = data[i];
        //是否相同
        if (Math.abs(currItem.structure.width - currStartItem.structure.width) < 3 &&
            Math.abs(currItem.structure.height - currStartItem.structure.height) < 3 &&
            Math.abs((currItem.structure.x + currItem.structure.width * 0.5) - (currStartItem.structure.x + currStartItem.structure.width * 0.5)) < 3 &&
            Array.isArray(currItem.children) &&
            Array.isArray(currStartItem.children) &&
            currItem.children.length === currStartItem.children.length) {
            num++;
        }
        else {
            //判断满足条件
            if (num >= 2) {
                count++;
                for (let j = currStartIndex; j < currStartIndex + num; j++) {
                    data[j].class_name = count > 1 ? 'li' + count : 'li';
                    data[j].class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
                }
            }
            currStartIndex = i;
            currStartItem = data[i];
            num = 1;
        }
    }
    //全量满足条件
    if (num === data.length) {
        data = data.map(item => {
            item.class_name = 'li';
            item.class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
            return item;
        });
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateRow.js":
/*!************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateRow.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理最外层布局
 *
 * @param {Array} data 图层Tree
 * @returns
 */
const calculateRow = (data) => {
    //最外层补偿值
    if (!data.length)
        return;
    let minX = data[0].structure.x;
    for (let i = 0; i < data.length; i++) {
        if (minX > data[i].structure.x) {
            minX = data[i].structure.x;
        }
    }
    for (let i = 0; i < data.length; i++) {
        if (data[i]._class == "artboard") {
            data[i].style["width"] = data[i].structure.width;
            data[i].style["margin"] = `0 auto`;
            data[i].style["overflow"] = "hidden";
            if (i > 0) {
                data[i].style.marginTop = 0;
            }
            return [data[i]];
        }
        else {
            data[i].style["width"] = data[i].structure.width;
            data[i].style["margin"] = `0 auto`;
            data[i].style["overflow"] = "hidden";
            if (i > 0) {
                data[i].style.marginTop = 0;
            }
        }
    }
    return data;
};
exports.default = calculateRow;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/const.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/const.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CLASS_TYPE = void 0;
exports.CLASS_TYPE = {
    "NORMAL": 1,
    "RELY_ON_PARENT": 2,
    "RELY_ON_CHILD_AND_PARENT": 3,
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/getBorderWidth.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/getBorderWidth.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 *获取各边宽度
 *
 * @param {*} layer
 * @returns
 * {
    layerBorderTopWidth,
    layerBorderBottomWidth,
    layerBorderLeftWidth,
    layerBorderRightWidth
  }
 */
const getBorderWidth = (layer) => {
    var _a, _b, _c, _d, _e;
    //父元素边框宽度
    const border = ((_a = layer.structure) === null || _a === void 0 ? void 0 : _a.border) || {};
    return {
        borderTopWidth: ((_b = border.top) === null || _b === void 0 ? void 0 : _b.width) || 0,
        borderBottomWidth: ((_c = border.bottom) === null || _c === void 0 ? void 0 : _c.width) || 0,
        borderLeftWidth: ((_d = border.left) === null || _d === void 0 ? void 0 : _d.width) || 0,
        borderRightWidth: ((_e = border.right) === null || _e === void 0 ? void 0 : _e.width) || 0
    };
};
exports.default = getBorderWidth;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleOverlap.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleOverlap.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const getBorderWidth_1 = __webpack_require__(/*! ./getBorderWidth */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/getBorderWidth.js");
/**
 *处理绝对定位
 *
 * @param {*} dataIsPositionLayout  需要绝对定位的数组
 * @param {*} parent  父图层
 * @param {*} data 通过其他方式布局的数组
 * @returns
 */
const handleOverlap = (dataIsPositionLayout, parent, data) => {
    if (!parent || dataIsPositionLayout.length == 0) {
        return data;
    }
    const { borderTopWidth: parentBorderTopWidth, borderLeftWidth: parentBorderLeftWidth } = getBorderWidth_1.default(parent);
    parent.addClassName = 'clearfloat';
    if (parent._class == 'artboard') {
        parent.style['overflow'] = 'hidden';
    }
    if (!parent.style['position']) {
        parent.style['position'] = 'relative';
    }
    //按照由小到到的顺序排列
    for (let i = 0; i < dataIsPositionLayout.length; i++) {
        dataIsPositionLayout[i].style.position = 'absolute';
        dataIsPositionLayout[i].style['left'] = dataIsPositionLayout[i].structure.x - parent.structure.x - parentBorderLeftWidth;
        dataIsPositionLayout[i].style['top'] = dataIsPositionLayout[i].structure.y - parent.structure.y - parentBorderTopWidth;
        dataIsPositionLayout[i].style['width'] = dataIsPositionLayout[i].structure.width;
        dataIsPositionLayout[i].style['height'] = dataIsPositionLayout[i].structure.height;
    }
    data = [...data, ...dataIsPositionLayout];
    parent.children = data;
    data = parent.children;
    return data;
};
exports.default = handleOverlap;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleParentIsText.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleParentIsText.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理父元素是文本的情况， 子元素使用 absoulte 定位
 *
 * @param {*} data
 */
const handleParentIsText = (data, parent) => {
    parent.style['position'] = parent.style['position'] ? parent.style['position'] : 'relative';
    for (let child of data) {
        child.style = Object.assign(Object.assign({}, child.style), {
            'position': 'absolute',
            'left': child.structure.x - parent.structure.x,
            'top': child.structure.y - parent.structure.y
        });
    }
    return data;
};
exports.default = handleParentIsText;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/index.js":
/*!**********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/index.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ./list */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/list.js"), exports);
__exportStar(__webpack_require__(/*! ./labelList */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/labelList.js"), exports);
__exportStar(__webpack_require__(/*! ./isSingleText */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isSingleText.js"), exports);
__exportStar(__webpack_require__(/*! ./isCenter */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isCenter.js"), exports);
__exportStar(__webpack_require__(/*! ./isLine */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isLine.js"), exports);
__exportStar(__webpack_require__(/*! ./isAlignCenter */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isAlignCenter.js"), exports);
__exportStar(__webpack_require__(/*! ./isOnlyContainer */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isOnlyContainer.js"), exports);
__exportStar(__webpack_require__(/*! ./isVerticalCenter */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isVerticalCenter.js"), exports);
__exportStar(__webpack_require__(/*! ./utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/utils.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isAlignCenter.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isAlignCenter.js ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isAlignCenter = void 0;
/**
 * 判断是否居中
 */
exports.isAlignCenter = (data, parent) => {
    if (Array.isArray(data) && data.length > 1 && parent) {
        const parentY = parent.structure.y + parent.structure.height / 2;
        for (let i = 0; i < data.length; i++) {
            const itemY = data[i].structure.y + data[i].structure.height / 2;
            if (Math.abs(parentY - itemY) > 1) {
                return false;
            }
        }
        return true;
    }
    return false;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isCenter.js":
/*!*************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isCenter.js ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isCenter = void 0;
const isLine_1 = __webpack_require__(/*! ./isLine */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isLine.js");
/**
 * 判断当前图层是否相对于父元素水平居中
 *
 * @param {*} layer
 * @param {*} parent
 */
exports.isCenter = (layer, parent) => {
    if (parent &&
        parent.structure.width > 750 * 0.7 &&
        layer.structure.width < parent.structure.width * 0.9 &&
        layer.name == 'Row' &&
        layer.children &&
        layer.children.length >= 2 &&
        isLine_1.isLine(layer.children) &&
        Math.abs(layer.structure.x - parent.structure.x - (parent.structure.x + parent.structure.width - layer.structure.x - layer.structure.width)) <= 2) {
        return true;
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isLine.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isLine.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isLine = void 0;
/**
 * 判断同层元素是否都在同一行
 *
 * @param {Array} data 同层元素数组
 */
exports.isLine = (data) => {
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        for (let j = i; j < data.length; j++) {
            const itemJ = data[j];
            if (itemJ.structure.y >= item.structure.y + item.structure.height || item.structure.y >= itemJ.structure.y + itemJ.structure.height) {
                return false;
            }
        }
    }
    return true;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isOnlyContainer.js":
/*!********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isOnlyContainer.js ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isOnlyContainer = void 0;
/**
 * 判断图层是否为纯容器
 *
 * @param {Object} layer 图层对象
 */
exports.isOnlyContainer = (layer) => {
    if (layer.type != "Container") {
        return false;
    }
    if (!layer.style) {
        return false;
    }
    if (layer.style['border-radius']
        || layer.style['border']
        || layer.style['background-color']
        || layer.style['background']
        || layer.style['background-image']) {
        return false;
    }
    return true;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isSingleText.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isSingleText.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isSingleText = void 0;
/**
 * 判断图层是否为单行纯文本
 *
 * @param {Object} layer 图层对象
 */
exports.isSingleText = (layer) => {
    if (layer.type != "Text") {
        return false;
    }
    if (!layer.style) {
        return false;
    }
    if (layer.style['border-radius']
        || layer.style['border']
        || layer.style['background-color']
        || layer.style['background']
        || layer.style['background-image']
        || (layer.structure.height && layer.style['font-size'] && layer.style['font-size'] <= layer.structure.height * 0.5)) {
        return false;
    }
    return true;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isVerticalCenter.js":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/isVerticalCenter.js ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isVerticalCenter = void 0;
/**
 * 判断是否垂直居中
 * @param {Array} data
 * @param {Object} parent
 */
exports.isVerticalCenter = (data, parent) => {
    if (Array.isArray(data) && data.length > 1 && parent) {
        const parentX = parent.structure.x + parent.structure.width / 2;
        for (let i = 0; i < data.length; i++) {
            const itemX = data[i].structure.x + data[i].structure.width / 2;
            if (Math.abs(parentX - itemX) > 1) {
                return false;
            }
        }
        return true;
    }
    return false;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/labelList.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/labelList.js ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.layoutLabelList = exports.isLabelList = void 0;
const utils_1 = __webpack_require__(/*! ./utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/utils.js");
/**
 * 排序方法
 * @param {Array} data
 */
const sort = (data) => {
    if (!data.length)
        return data;
    let yList = [data[0].structure.y];
    data.map(item => {
        if (yList[0] != item.structure.y && !yList.includes(item.structure.y)) {
            yList.push(item.structure.y);
        }
    });
    yList = yList.sort((a, b) => a - b);
    let result = [];
    for (let i = 0; i < yList.length; i++) {
        let list = [];
        data.map(item => {
            if (item.structure.y == yList[i]) {
                list.push(item);
            }
        });
        list = list.sort((a, b) => a.structure.x - b.structure.x);
        result = [...result, ...list];
    }
    return result;
};
/**
 *  识别标签列表
 *   1. 标签等宽 只包含文字 允许背景不一致  间距
 */
exports.isLabelList = (data, parent) => {
    if (data.length < 3)
        return false;
    let num = 0; // 记录每行有多少元素
    let first = data[0];
    data.map(item => {
        if (item.structure.y == first.structure.y) {
            num++;
        }
    });
    //每行只有一条数据的时候，既纵向排列，不适用于此
    if (num === 1) {
        return false;
    }
    data = sort(data);
    try {
        let count = 0;
        for (let i = 0; i < data.length; i++) {
            if (utils_1.utils.hasTextType(data[i]) &&
                utils_1.utils.isEqualHeight(data) &&
                (utils_1.utils.isSameSpacing(data) || parent.sign == "__list") &&
                (utils_1.utils.hasBackground(data) || utils_1.utils.hasBorder(data))) {
                count++;
            }
        }
        if (count == data.length) { // 父元素宽度扩展
            parent.structure.width += data[1].structure.x - data[0].structure.x - data[0].structure.width;
            parent.style.width += data[1].structure.x - data[0].structure.x - data[0].structure.width;
            if (parent.style.marginLeft && parent.style.marginLeft == parent.style.marginRight) {
                // 如果父元素位置居中的情况下需要计算偏移量
                parent.style.position = 'relative';
                parent.style.left = (data[1].structure.x - data[0].structure.x - data[0].structure.width) / 2;
            }
        }
        return count == data.length;
    }
    catch (error) {
        console.log(error);
    }
};
exports.layoutLabelList = (data, parent) => {
    data = sort(data);
    parent.name = "labelList";
    let first = data[0];
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", "flex-wrap": "wrap", "padding-left": data[0].structure.x - parent.structure.x, "padding-top": data[0].structure.y - parent.structure.y });
    let marginBottom = 0;
    let marginRight = 0;
    marginRight = parent.marginRight || data[1].structure.x - first.structure.x - first.structure.width;
    for (let i = 1; i < data.length; i++) {
        if (first.structure.x == data[i].structure.x) {
            marginBottom = data[i].structure.y - first.structure.y - first.structure.height;
            break;
        }
    }
    for (let item of data) {
        item.style = Object.assign(Object.assign({}, item.style), { display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", marginBottom: `${marginBottom}`, marginRight: `${marginRight}` });
        delete item.style.lineHeight;
        //   item.addClassName = 'item';
        //   item.element = {
        //       tag: "li"
        //   };
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/list.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/list.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isList = void 0;
/**
 * 判断是否相等
 * @param {*} a
 * @param {*} b
 */
const isEqual = (a, b) => {
    if (Math.abs(a - b) <= 2) {
        return true;
    }
    return false;
};
exports.isList = (data) => {
    let flag = false;
    let flagY = false;
    if (Array.isArray(data) && data.length > 1) {
        let firstItem = data[0];
        flag = true;
        data.forEach(({ structure: { width, height, y } }) => {
            if (!isEqual(width, firstItem.structure.width) || !isEqual(height, firstItem.structure.height)) {
                flag = false;
            }
            if (!isEqual(y, firstItem.structure.y)) {
                flagY = true;
            }
        });
    }
    return flag && flagY;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/utils.js":
/*!**********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/utils.js ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.utils = void 0;
// 公用方法
exports.utils = {
    // 判断是否等宽
    isEqualWidth(data) {
        // 判断所有的元素是否等宽
        let setList = new Set();
        for (let item of data) {
            setList.add(item.structure.width);
        }
        let ary = [...new Set(setList)];
        return ary.length == 1 ? true : false;
    },
    // 判断所有的子元素是否中线对齐
    isAlignMiddle(data, parent) {
        let middlePos = parent.structure.y + parent.structure.height / 2;
        let isAlignMiddle = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if (Math.abs(item.structure.y + item.structure.height / 2 - middlePos) > 2) {
                // 允许 2px 误差
                isAlignMiddle = false;
                break;
            }
        }
        return isAlignMiddle;
    },
    isEqualHeight(data) {
        // 判断所有的元素是否等宽
        let setList = new Set();
        for (let item of data) {
            setList.add(item.structure.height);
        }
        let ary = [...new Set(setList)];
        return ary.length == 1 ? true : false;
    },
    // 第一层级只包含一个文本节点
    hasTextType(data) {
        if (data.type == "Text")
            return true; // 自身是文本的情况返回 true
        if (data.children) {
            let textList = [];
            for (let item of data.children) {
                if (item.type == "Text") {
                    textList.push(item);
                }
            }
            return textList.length == 1;
        }
        return false;
    },
    // 多行之间判断是否是否相同间距
    isSameSpacing(data) {
        let flag = true;
        let space = data[1].structure.x - data[0].structure.x - data[0].structure.width;
        for (let i = 1; i < data.length; i++) {
            if (data[i].structure.y == data[i - 1].structure.y &&
                Math.abs(data[i].structure.x - data[i - 1].structure.x - data[i - 1].structure.width - space) > 4) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 是否有边框
    hasBorder(data) {
        var _a;
        let flag = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if (!((_a = item.structure) === null || _a === void 0 ? void 0 : _a.border)) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 是否有背景
    hasBackground(data) {
        var _a;
        let flag = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if ((_a = item.style) === null || _a === void 0 ? void 0 : _a.background) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 判断所有的子元素和父元素的高度是否一致
    isSameParentHeight(data, parent) {
        let flag = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if (item.structure.height != parent.structure.height) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 判断水平方向子元素贴近父元素
    isHorizontalCloseParent(data, parent) {
        if (data.length < 2)
            return false;
        // 两个元素组合位于父元素中间
        return (data[0].structure.x == parent.structure.x &&
            Math.abs(data[data.length - 1].structure.x +
                data[data.length - 1].structure.width -
                parent.structure.x -
                parent.structure.width) < 2);
    },
    // 判断垂直方向子元素贴近父元素
    isVerticalCloseParent(data, parent) {
        if (data.length < 2)
            return false;
        // 两个元素组合位于父元素中间
        return (data[0].structure.y == parent.structure.y &&
            Math.abs(data[data.length - 1].structure.y +
                data[data.length - 1].structure.height -
                parent.structure.y -
                parent.structure.height) < 2);
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/index.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/index.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleOverlap_1 = __webpack_require__(/*! ./handleOverlap */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleOverlap.js");
const calculateRow_1 = __webpack_require__(/*! ./calculateRow */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateRow.js");
const isBlock_1 = __webpack_require__(/*! ./isBlock */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/isBlock.js");
const calculateBlock_1 = __webpack_require__(/*! ./calculateBlock */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateBlock.js");
const handleParentIsText_1 = __webpack_require__(/*! ./handleParentIsText */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleParentIsText.js");
const markIsOnlyText_1 = __webpack_require__(/*! ./markIsOnlyText */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/markIsOnlyText.js");
const row_1 = __webpack_require__(/*! ./row */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/row.js");
// 特殊布局识别
const handleTypeLayout_1 = __webpack_require__(/*! ./handleTypeLayout */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/index.js");
const calculateClassName_1 = __webpack_require__(/*! ./calculateClassName */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/calculateClassName.js");
/**
 * 布局
 * @param {Layer[]} data
 * @param {Layer} parent
 * @returns
 */
const handleLayout = (data, parent) => {
    //使用绝对定位的图层数组
    let dataIsPositionLayout = [];
    //不使用绝对定位的图层数组
    let dataIsNotPositionLayout = [];
    //图层分组
    data.forEach((item) => {
        if (parent && item.isPosition) {
            dataIsPositionLayout.push(item);
        }
        else {
            dataIsNotPositionLayout.push(item);
        }
    });
    data = dataIsNotPositionLayout;
    // 竖向列表
    if (calculateClassName_1.isLeftImgRightInfo(data)) {
        data = calculateClassName_1.calculateLeftImgRightInfo(data);
    }
    if (calculateClassName_1.isVerticalList(data)) {
        data = calculateClassName_1.calculateVerticalList(data);
    }
    else {
        data = calculateClassName_1.handleContinuousListItem(data);
    }
    switch (true) {
        case parent === undefined:
            data = calculateRow_1.default(data);
            break;
        case parent && parent.textContainer: //一行文本多个样式不走布局
            break;
        case parent && parent._class == "text":
            data = handleParentIsText_1.default(data, parent);
            break;
        case handleTypeLayout_1.isLabelList(data, parent):
            data = handleTypeLayout_1.layoutLabelList(data, parent);
            break;
        case isBlock_1.default(data):
            data = calculateBlock_1.default(data, parent);
            break;
        case row_1.isRow(data):
            data = row_1.layoutRow(data, parent);
            break;
        default:
            break;
    }
    if (parent) {
        markIsOnlyText_1.default(data, parent);
    }
    //使用绝对定位的布局
    data = handleOverlap_1.default(dataIsPositionLayout, parent, data);
    //递归子集
    if (Array.isArray(data)) {
        for (let i = 0; i < data.length; i++) {
            // 单行文本宽度是否全去掉
            try {
                if (handleTypeLayout_1.isSingleText(data[i])) {
                    delete data[i].style.width;
                    //避免纵向排列的,右对齐的部分，text-align=right 也要去掉
                    if (data.length > 1 && data[i].style.textAlign == 'right' && parent && data[i].structure.width < parent.structure.width * 0.9) {
                        delete data[i].style.textAlign;
                    }
                }
            }
            catch (error) {
                console.log('文本宽度剔除异常' + error);
            }
            if (Array.isArray(data[i].children) && data[i].children.length > 0) {
                data[i].children = handleLayout(data[i].children, data[i]);
            }
        }
    }
    return data;
};
exports.default = handleLayout;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/isBlock.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/isBlock.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// 判断是横向还是纵向排列
// 只有满足同级下所有的元素都是纵向才认为是纵向排列， 否则都认为是横向排列
const isBlock = (data) => {
    for (var i = 1; i < data.length; i++) {
        //计算的值误差范围
        if (+data[i].structure.x - data[i - 1].structure.width - data[i - 1].structure.x > 0) {
            // 表示的是横向排列的
            return false;
        }
    }
    return true;
};
exports.default = isBlock;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/markIsOnlyText.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/markIsOnlyText.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// 根据盒子的内容删减没必要的盒子，以适应基本的布局的需要
const markIsOnlyText = (data, parent) => {
    for (var i = 0; i < data.length; i++) {
        if (!data[i].children && parent.children.length == 1) {
            if (data[i].type == 'Text') {
                parent.isOnlyText = true;
            }
        }
        if (data[i].children) {
            markIsOnlyText(data[i].children, data[i]);
        }
    }
    return data;
};
exports.default = markIsOnlyText;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/row.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/row.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.layoutRow = exports.isRow = void 0;
const handleTypeLayout_1 = __webpack_require__(/*! ./handleTypeLayout */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/handleTypeLayout/index.js");
const const_1 = __webpack_require__(/*! ./const */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/const.js");
/**
 * 规则
 * 1.父元素width不为auto
 * @param {Array} data
 * @param {Object} parent
 */
const isTowSpan = (data, parent) => {
    // if (data.length == 2 && parent.structure.width != "auto") {
    if (data.length == 2 && parent) {
        let firstItem = data[0];
        let secondItem = data[1];
        if (firstItem.structure.x + firstItem.structure.width / 2 < parent.structure.x + parent.structure.width / 2 &&
            secondItem.structure.x >= parent.structure.x + parent.structure.width / 2 &&
            (secondItem.structure.x - firstItem.structure.x - firstItem.structure.width) * 0.2 >
                parent.structure.width + parent.structure.x - secondItem.structure.x - secondItem.structure.width &&
            parent.structure.width > 750 * 0.7) {
            return true;
        }
    }
};
const layoutTowSpan = (data, parent) => {
    let firstItem = data[0];
    let secondItem = data[1];
    firstItem.class_name = 'left';
    firstItem.class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    secondItem.class_name = 'right';
    secondItem.class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", justifyContent: "space-between", flexDirection: 'row' });
    if (handleTypeLayout_1.utils.isAlignMiddle(data, parent)) {
        if (!handleTypeLayout_1.utils.isSameParentHeight(data, parent)) {
            parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
        }
    }
    else {
        firstItem.style = Object.assign(Object.assign({}, firstItem.style), { marginTop: firstItem.structure.y - parent.structure.y });
        secondItem.style = Object.assign(Object.assign({}, secondItem.style), { marginTop: secondItem.structure.y - parent.structure.y });
    }
    firstItem.style = Object.assign(Object.assign({}, firstItem.style), { marginLeft: firstItem.structure.x - parent.structure.x });
    if (handleTypeLayout_1.isSingleText(firstItem) || handleTypeLayout_1.isOnlyContainer(firstItem)) {
        delete firstItem.style.width;
    }
    secondItem.style = Object.assign(Object.assign({}, secondItem.style), { marginRight: parent.structure.x + parent.structure.width - secondItem.structure.x - secondItem.structure.width });
    if (handleTypeLayout_1.isSingleText(secondItem) ||
        (handleTypeLayout_1.isOnlyContainer(secondItem) &&
            secondItem.children &&
            secondItem.children.length < 2)) {
        delete secondItem.style.width;
    }
    return data;
};
// 判断是否是图片文案居中的情况
const isimgTextCeneter = (data, parent) => {
    if (data.length !== 2)
        return false; // 只有两个元素的情况
    const isAlignCenter = (data, parent) => {
        // 两个元素组合位于父元素中间
        let firstItem = data[0];
        let secondItem = data[1];
        let leftDis = firstItem.structure.x - parent.structure.x;
        let rightDis = parent.structure.x + parent.structure.width - secondItem.structure.x - secondItem.structure.width;
        return Math.abs(leftDis - rightDis) < 2;
    };
    let existImgLayer = data.find(item => item.type == "Image");
    let existTextLayer = data.find(item => item.type == "Text");
    if (existImgLayer && existTextLayer && isAlignCenter(data, parent)) {
        return true;
    }
    return false;
};
const layoutImgTextCeneter = (data, parent) => {
    let firstItem = data[0];
    let secondItem = data[1];
    if (handleTypeLayout_1.isSingleText(firstItem)) {
        delete firstItem.style.width;
    }
    if (handleTypeLayout_1.isSingleText(secondItem)) {
        delete secondItem.style.width;
    }
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", flexDirection: 'row' });
    if (!handleTypeLayout_1.utils.isHorizontalCloseParent(data, parent)) {
        parent.style = Object.assign(Object.assign({}, parent.style), { justifyContent: "center" });
    }
    if (handleTypeLayout_1.utils.isAlignMiddle(data, parent)) {
        if (!handleTypeLayout_1.utils.isVerticalCloseParent(data, parent)) {
            parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
        }
    }
    else {
        for (let item of data) {
            item.style = Object.assign(Object.assign({}, item.style), { marginTop: item.structure.y - parent.structure.y });
        }
    }
    secondItem.style = Object.assign(Object.assign({}, secondItem.style), { marginLeft: secondItem.structure.x - firstItem.structure.x - firstItem.structure.width });
    return data;
};
const isEqualBolck = (data, parent) => {
    if (data.length >= 2 &&
        handleTypeLayout_1.utils.isEqualWidth(data) &&
        handleTypeLayout_1.utils.isEqualHeight(data) &&
        handleTypeLayout_1.utils.isSameSpacing(data) &&
        data[0].structure.x == parent.structure.x &&
        Math.abs(data[data.length - 1].structure.x +
            data[data.length - 1].structure.width -
            parent.structure.x -
            parent.structure.width) < 2) {
        // 至少两个子元素
        return true;
    }
    return false;
};
const layoutEqualBlock = (data, parent) => {
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", justifyContent: "space-between" });
    data = data.map(item => {
        item.class_name = 'li';
        item.class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
        return item;
    });
    return data;
};
const isBetweenItemList = (data, parent) => {
    if (Array.isArray(data) && data.length > 2 && parent) {
        let firstBetween = data[1].structure.x + data[1].structure.width * 0.5 - (data[0].structure.x + data[0].structure.width * 0.5);
        for (let i = 2; i < data.length; i++) {
            const item = data[i];
            if (item.name != "ItemList") {
                return false;
            }
            if (Math.abs(data[i].structure.x + data[i].structure.width * 0.5 - (data[i - 1].structure.x + data[i - 1].structure.width * 0.5) - firstBetween) > 4) {
                return false;
            }
        }
        return true;
    }
    return false;
};
const layoutBetweenItemList = (data, parent) => {
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", flexDirection: 'row', justifyContent: "space-between" });
    for (let i = 0; i < data.length; i++) {
        if (!data[i].style) {
            data[i].style = {};
        }
        data[i].class_name = "li";
        data[i].class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
    }
    if (handleTypeLayout_1.isAlignCenter(data, parent)) {
        parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
    }
    else {
        for (let i = 0; i < data.length; i++) {
            data[i].style = Object.assign(Object.assign({}, data[i].style), { marginTop: data[i].structure.y - parent.structure.y });
        }
    }
    //第一个元素
    if (data[0].structure.x != parent.structure.x) {
        parent.style = Object.assign(Object.assign({}, parent.style), { paddingLeft: data[0].structure.x - parent.structure.x });
    }
    //最后一个元素
    if (data[data.length - 1].structure.x + data[data.length - 1].structure.width !=
        parent.structure.x + parent.structure.width) {
        parent.style = Object.assign(Object.assign({}, parent.style), { paddingRight: parent.structure.x
                + parent.structure.width - data[data.length - 1].structure.x
                - data[data.length - 1].structure.width });
    }
    //不设置宽度
    for (let i = 0; i < data.length; i++) {
        delete data[i].style.width;
    }
    return data;
};
/**
 * 行布局
 */
exports.isRow = (data) => {
    let flag = true;
    if (Array.isArray(data) && data.length > 1) {
        data = data.sort((a, b) => a.structure.x - b.structure.x);
        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            flag = false;
            for (let j = i; j < data.length; j++) {
                const itemJ = data[j];
                if ((item.structure.y <= itemJ.structure.y && itemJ.structure.y < item.structure.y + item.structure.width) ||
                    (itemJ.structure.y <= item.structure.y && item.structure.y < itemJ.structure.y + itemJ.structure.width)) {
                    flag = true;
                }
            }
        }
    }
    return flag;
};
exports.layoutRow = (data, parent) => {
    if (Array.isArray(data) && data.length > 1) {
        data = data.sort((a, b) => a.structure.x - b.structure.x);
        if (parent) {
            if (!parent.style) {
                parent.style = {};
            }
            //两列两边对齐样式
            if (isTowSpan(data, parent)) {
                return layoutTowSpan(data, parent);
            }
            //itemList情况切符合间距相同
            if (isBetweenItemList(data, parent)) {
                return layoutBetweenItemList(data, parent);
            }
            // 多个子元素，宽度一样，第一个和最后一个紧挨父元素情况
            if (isEqualBolck(data, parent)) {
                return layoutEqualBlock(data, parent);
            }
            // // 子元素组合位于父元素中间位置， 所有子元素垂直方向上居中
            if (isimgTextCeneter(data, parent)) {
                return layoutImgTextCeneter(data, parent);
            }
            parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", flexDirection: "row" });
            // 水平居中
            if (parent.isCenter) {
                parent.style = Object.assign(Object.assign({}, parent.style), { width: "auto", justifyContent: "center" });
                delete parent.style.marginLeft;
            }
            // 垂直方向
            if (handleTypeLayout_1.utils.isAlignMiddle(data, parent)) {
                if (!handleTypeLayout_1.utils.isSameParentHeight(data, parent)) {
                    parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
                }
            }
            else {
                for (let i = 0; i < data.length; i++) {
                    data[i].style = Object.assign(Object.assign({}, data[i].style), { marginTop: data[i].structure.y - parent.structure.y });
                }
            }
            for (let i = 0; i < data.length; i++) {
                const item = data[i];
                if (!data[i].style) {
                    data[i].style = {};
                }
                if (i == 0) {
                    data[i].style = Object.assign(Object.assign({}, data[i].style), { marginLeft: item.structure.x - parent.structure.x });
                }
                else {
                    data[i].style = Object.assign(Object.assign({}, data[i].style), { marginLeft: item.structure.x - data[i - 1].structure.x - data[i - 1].structure.width });
                }
            }
            if ((handleTypeLayout_1.isSingleText(data[data.length - 1]) &&
                data[data.length - 1].style.textAlign === "left") ||
                handleTypeLayout_1.isOnlyContainer(data[data.length - 1])) {
                data[data.length - 1].style.width = "auto";
            }
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/const.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/const.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.fontSizeLineHeightMap = exports.fontWeightTypes = void 0;
/**
 * 字体类型
 */
exports.fontWeightTypes = ["black", "heavy", "ultrabold", "extrabold", "bold", "boldmt", "psboldmt", "semibold", "demibold", "medium", "roman", "regular", "normal", "book", "light", "extralight", "ultralight", "thin"];
/**
 * 0-60 字体行高映射表
 * fontSize => lineHeight
 */
exports.fontSizeLineHeightMap = [0, 1, 3, 4, 5, 7, 8, 9, 11, 13, 14, 16, 17, 18, 20, 21, 22, 24, 25, 26, 28, 29, 30, 32, 33, 36, 37, 38, 40, 41, 42, 44, 45, 46, 48, 49, 50, 52, 53, 54, 56, 57, 59, 61, 62, 63, 65, 66, 67, 59, 70, 71, 73, 74, 75, 77, 78, 79, 81, 83, 84];


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transSketchColor = exports.precisionControl = exports.getEnabledFill = exports.calculateRGB = exports.isAlignCenter = void 0;
/**
 * @description 两个图层进行比较，判断图层layerB是否在layerA中间的位置
 * @param {Layer} layerA
 * @param {Layer} layerB
 * @returns {boolean}
 */
exports.isAlignCenter = (layerA, layerB) => {
    return Math.abs((layerA.frame.x + layerA.frame.width / 2) - (layerB.frame.x + layerB.frame.width / 2)) <= 5;
};
/**
 * @description 颜色值转换
 * @param {number} color 颜色
 * @returns {number}
 */
exports.calculateRGB = (color) => {
    return Math.round(color * 255);
};
// 判断是否包含可用的 fill
exports.getEnabledFill = (layer) => {
    var _a;
    if ((_a = layer.style) === null || _a === void 0 ? void 0 : _a.fills) {
        return layer.style.fills.filter((item) => item.isEnabled).pop();
    }
    return undefined;
};
/**
 * 精度控制
 * @param data 需要处理的数据
 * @param num 精度 eg. 0.1 0.01
 */
exports.precisionControl = (data, num = 1) => {
    const len = Math.round(1 / num).toString().length - 1;
    return +((Math.round(data / num) * num).toFixed(len));
};
/**
 * @description 转换sketch中的color => rgba值
 * @param {*} { red, green, blue, alpha }
 */
exports.transSketchColor = ({ red, green, blue, alpha }) => ({
    red: exports.calculateRGB(red),
    green: exports.calculateRGB(green),
    blue: exports.calculateRGB(blue),
    alpha: exports.precisionControl(alpha, 0.1),
});


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/handleClassName/classNameList.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/handleClassName/classNameList.js ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList = [
    'rat',
    'valley',
    'pence',
    'unconditional',
    'feather',
    'zoo',
    'build',
    'field',
    'nationality',
    'salad',
    'ferry',
    'building',
    'limit',
    'stewardess',
    'water',
    'manage',
    'path',
    'example',
    'purple',
    'valid',
    'hurry',
    'argue',
    'accommodation',
    'mixture',
    'time',
    'picnic',
    'consensus',
    'smoke',
    'protection',
    'conscience',
    'sense',
    'owe',
    'chant',
    'term',
    'urban',
    'considerate',
    'afraid',
    'bandage',
    'table',
    'tennis',
    'candidate',
    'combine',
    'hurricane',
    'independent',
    'cancer',
    'choose',
    'town',
    'desire',
    'visual',
    'life',
    'submit',
    'physics',
    'meaning',
    'country',
    'half',
    'joy',
    'adult',
    'servant',
    'care',
    'search',
    'same',
    'furniture',
    'agree',
    'heart',
    'unemployment',
    'nearly',
    'bond',
    'master',
    'rise',
    'punish',
    'monument',
    'stick',
    'tax',
    'personnel',
    'fact',
    'therefore',
    'ox',
    'ocean',
    'eagle',
    'cloud',
    'fibre',
    'fiber',
    'bingo',
    'fortunate',
    'mommy',
    'wage',
    'along',
    'surplus',
    'add',
    'outdoors',
    'paper',
    'fetch',
    'church',
    'edition',
    'weather',
    'opera',
    'dot',
    'service',
    'disease',
    'symphony',
    'survival',
    'thus',
    'satisfy',
    'arise',
    'sorry',
    'dinosaur',
    'properly',
    'story',
    'appetite',
    'pronounce',
    'socialist',
    'certain',
    'pea',
    'bacterium',
    'contrary',
    'roof',
    'carve',
    'essay',
    'reward',
    'convenience',
    'export',
    'fit',
    'racial',
    'herself',
    'bid',
    'novelist',
    'safety',
    'off',
    'east',
    'misunderstand',
    'razor',
    'waiting',
    'room',
    'short',
    'surprise',
    'pleasure',
    'tidy',
    'garage',
    'analyse',
    'Am',
    'analyze',
    'notice',
    'violinist',
    'ice',
    'deliberately',
    'alike',
    'perfect',
    'broom',
    'welfare',
    'keyboard',
    'dad',
    'daddy',
    'approximately',
    'hopeful',
    'habit',
    'confidential',
    'complex',
    'recreation',
    'data',
    'kindergarten',
    'sniff',
    'we',
    'studio',
    'overlook',
    'barbershop',
    'minority',
    'escape',
    'jeans',
    'videophone',
    'adapt',
    'report',
    'recorder',
    'betray',
    'vast',
    'arrow',
    'usual',
    'eat',
    'spread',
    'agent',
    'spare',
    'conclusion',
    'rock',
    'hometown',
    'bakery',
    'conclude',
    'worry',
    'operate',
    'floor',
    'area',
    'noise',
    'chairwoman',
    'classroom',
    'communicate',
    'attack',
    'event',
    'dream',
    'criminal',
    'authentic',
    'scarf',
    'senior',
    'OK',
    'okay',
    'description',
    'representative',
    'carriage',
    'sacred',
    'run',
    'software',
    'diet',
    'copy',
    'eastern',
    'carbon',
    'sow',
    'universe',
    'folk',
    'tendency',
    'camp',
    'likely',
    'alive',
    'harvest',
    'devote',
    'marathon',
    'Christian',
    'government',
    'Franc',
    'seminar',
    'departure',
    'forward',
    'person',
    'violence',
    'basketball',
    'gas',
    'fox',
    'advance',
    'majority',
    'credit',
    'relief',
    'prefer',
    'qualification',
    'sand',
    'lift',
    'attain',
    'fantasy',
    'trap',
    'interesting',
    'nothing',
    'civilian',
    'besides',
    'homework',
    'container',
    'fireworks',
    'toy',
    'focus',
    'decide',
    'frighten',
    'cleaner',
    'autumn',
    'beneath',
    'hostess',
    'climb',
    'expert',
    'super',
    'significance',
    'hair',
    'phrase',
    'authority',
    'agricultural',
    'explore',
    'framework',
    'caf',
    'consequence',
    'geography',
    'your',
    'match',
    'hall',
    'ship',
    'suppose',
    'signature',
    'borrow',
    'create',
    'companion',
    'direction',
    'except',
    'big',
    'nutrition',
    'anecdote',
    'string',
    'breast',
    'flashlight',
    'unconscious',
    'champion',
    'funeral',
    'since',
    'how',
    'jacket',
    'robot',
    'like',
    'pleasant',
    'airport',
    'compensate',
    'more',
    'sandwich',
    'boring',
    'seldom',
    'jazz',
    'mile',
    'apologize',
    'shout',
    'commit',
    'can',
    'institution',
    'upstairs',
    'abortion',
    'storage',
    'bravery',
    'envelope',
    'amazing',
    'disappoint',
    'advantage',
    'lab',
    'laboratory',
    'foreign',
    'conduct',
    'prison',
    'agreement',
    'botany',
    'famous',
    'mix',
    'level',
    'go',
    'urgent',
    'scholar',
    'jet',
    'cottage',
    'sigh',
    'maid',
    'pop',
    'popular',
    'advertisement',
    'western',
    'course',
    'wound',
    'together',
    'reservation',
    'because',
    'realise',
    'grateful',
    'huge',
    'turn',
    'knowledge',
    'arrive',
    'seaside',
    'assessment',
    'kilometre',
    'plug',
    'impress',
    'else',
    'fail',
    'discuss',
    'temporary',
    'volcano',
    'call',
    'asleep',
    'amateur',
    'material',
    'fragrant',
    'slave',
    'itself',
    'stupid',
    'central',
    'evening',
    'collision',
    'highway',
    'staff',
    'Asia',
    'medicine',
    'shop',
    'pump',
    'discourage',
    'political',
    'continent',
    'bless',
    'jeep',
    'account',
    'zoom',
    'content',
    'trousers',
    'tonight',
    'spend',
    'astronaut',
    'belt',
    'yet',
    'result',
    'gravity',
    'worth',
    'prize',
    'up',
    'quarrel',
    'born',
    'ring',
    'guard',
    'driver',
    'otherwise',
    'repair',
    'back',
    'reasonable',
    'could',
    'disappear',
    'shy',
    'questionnaire',
    'cheers',
    'interview',
    'kindness',
    'gold',
    'gradual',
    'quit',
    'medical',
    'waste',
    'airmail',
    'expensive',
    'wisdom',
    'favourite',
    'attitude',
    'touch',
    'soil',
    'especially',
    'who',
    'suck',
    'breath',
    'rice',
    'stout',
    'version',
    'oxygen',
    'grey',
    'humorous',
    'burn',
    'regard',
    'seaweed',
    'tremble',
    'pillow',
    'garlic',
    'straw',
    'pineapple',
    'hot',
    'tradition',
    'rescue',
    'again',
    'violent',
    'as',
    'terror',
    'fortune',
    'until',
    'pride',
    'foster',
    'home',
    'peace',
    'shorts',
    'vertical',
    'jam',
    'hatch',
    'atmosphere',
    'stadium',
    'main',
    'people',
    'light',
    'injure',
    'witness',
    'component',
    'weekly',
    'right',
    'dialogue',
    'audience',
    'acquire',
    'store',
    'decline',
    'very',
    'user',
    'spit',
    'undertake',
    'terrible',
    'vacation',
    'much',
    'handbag',
    'saucer',
    'officer',
    'whisper',
    'pleased',
    'greedy',
    'horse',
    'little',
    'cloudy',
    'mainland',
    'fee',
    'taste',
    'alternative',
    'opening',
    'toothache',
    'universal',
    'cow',
    'wheel',
    'pipe',
    'profession',
    'dig',
    'conversation',
    'gain',
    'subjective',
    'thunder',
    'clay',
    'hill',
    'give',
    'budget',
    'against',
    'cage',
    'on',
    'unfit',
    'scene',
    'pint',
    'freezing',
    'oilfield',
    'onion',
    'seed',
    'outstanding',
    'wool',
    'crazy',
    'sew',
    'shelf',
    'freeze',
    'speed',
    'behaviour',
    'behavior',
    'TV',
    'television',
    'chest',
    'knock',
    'something',
    'directory',
    'platform',
    'sightseeing',
    'bay',
    'foreigner',
    'another',
    'oh',
    'zero',
    'boy',
    'handsome',
    'rest',
    'study',
    'front',
    'rely',
    'aside',
    'appeal',
    'competence',
    'fresh',
    'question',
    'south',
    'annoy',
    'pretty',
    'conference',
    'communist',
    'sunlight',
    'cure',
    'slide',
    'glance',
    'paint',
    'wine',
    'dive',
    'admire',
    'existence',
    'bureaucratic',
    'price',
    'skill',
    'nor',
    'enthusiastic',
    'volleyball',
    'dam',
    'delicate',
    'someone',
    'post',
    'father',
    'disgusting',
    'radioactive',
    'offense',
    'passer',
    'by',
    'what',
    'human',
    'guarantee',
    'husband',
    'island',
    'painting',
    'nowadays',
    'hardship',
    'counter',
    'collar',
    'appropriate',
    'thriller',
    'repeat',
    'perform',
    'unbelievable',
    'dozen',
    'Easter',
    'noisy',
    'see',
    'idea',
    'uncomfortable',
    'load',
    'reception',
    'look',
    'value',
    'chess',
    'thunderstorm',
    'convenient',
    'kilo',
    'cassette',
    'toward',
    's',
    'wood',
    'theft',
    'chef',
    'businessman',
    'silly',
    'tomato',
    'brunch',
    'laugh',
    'suitcase',
    'coin',
    'spade',
    'mental',
    'comfort',
    'receiver',
    'Africa',
    'percentage',
    'wrong',
    'correspond',
    'reflect',
    'spy',
    'somebody',
    'religious',
    'last',
    'shade',
    'perfume',
    'pity',
    'trouble',
    'necklace',
    'pancake',
    'interest',
    'hen',
    'dynasty',
    'single',
    'puzzle',
    'head',
    'mean',
    'break',
    'among',
    'certificate',
    'crowd',
    'wander',
    'box',
    'fix',
    'clinic',
    'grammar',
    'ball',
    'translate',
    'delete',
    'cheat',
    'adjust',
    'ill',
    'swing',
    'privilege',
    'quarter',
    'brain',
    'orbit',
    'attach',
    'blind',
    'wild',
    'plastic',
    'adaption',
    'lively',
    'reply',
    'yours',
    'assume',
    'saying',
    'composition',
    'sunshine',
    'union',
    'angle',
    'legal',
    'death',
    'observe',
    'splendid',
    'scar',
    'buy',
    'kill',
    'rent',
    'distinguish',
    'lead',
    'vest',
    'effect',
    'mud',
    'refer',
    'globe',
    'zip',
    'power',
    'marriage',
    'brilliant',
    'pick',
    'speech',
    'ancient',
    'director',
    'replace',
    'pig',
    'autonomous',
    'red',
    'output',
    'die',
    'gifted',
    'station',
    'apple',
    'teamwork',
    'revision',
    'revolution',
    'surgeon',
    'link',
    'average',
    'section',
    'fluency',
    'underground',
    'number',
    'amusement',
    'develop',
    'sword',
    'star',
    'greengrocer',
    'lucky',
    'eraser',
    'rainbow',
    'anxious',
    'beyond',
    'news',
    'waitress',
    'reference',
    'switch',
    'caption',
    'rough',
    'rail',
    'photo',
    'photograph',
    'parrot',
    'must',
    'instant',
    'centre',
    'determine',
    'street',
    'voyage',
    'Ms',
    'patient',
    'wake',
    'worker',
    'Internet',
    'coast',
    'benefit',
    'with',
    'already',
    'face',
    'none',
    'broad',
    'feed',
    'shoot',
    'across',
    'male',
    'Antarctic',
    'zone',
    'continue',
    'blackboard',
    'join',
    'defend',
    'tentative',
    'channel',
    'technical',
    'snow',
    'difficult',
    'bird',
    'widespread',
    'war',
    'pear',
    'lot',
    'excuse',
    'actress',
    'tablet',
    'score',
    'pronunciation',
    'such',
    'accent',
    'chat',
    'deer',
    'memorial',
    'within',
    'tent',
    'microwave',
    'success',
    'luggage',
    'ending',
    'noodle',
    'vain',
    'dentist',
    'district',
    'control',
    'bill',
    'professor',
    'indicate',
    'gentle',
    'helicopter',
    'airplane',
    'please',
    'allowance',
    'forehead',
    'stable',
    'fast',
    'lake',
    'quilt',
    'agenda',
    'command',
    'photographer',
    'monitor',
    'gift',
    'middle',
    'means',
    'glare',
    'breakfast',
    'mad',
    'currency',
    'detective',
    'VCD',
    'visual',
    'compact',
    'disk',
    'prisoner',
    'dinner',
    'helmet',
    'handwriting',
    'thankful',
    'enough',
    'psychology',
    'skin',
    'amuse',
    'cut',
    'poisonous',
    'hearing',
    'praise',
    'flight',
    'ash',
    'crime',
    'troublesome',
    'coke',
    'circulate',
    'address',
    'numb',
    'drunk',
    'resign',
    'menu',
    'congratulate',
    'gay',
    'plain',
    'affair',
    'chicken',
    'deed',
    'pure',
    'cover',
    'error',
    'relationship',
    'snowy',
    'ticket',
    'subject',
    'throughout',
    'applicant',
    'ceiling',
    'manner',
    'type',
    'remark',
    'mop',
    'smog',
    'lid',
    'topic',
    'literature',
    'garment',
    'squirrel',
    'aloud',
    'next',
    'barrier',
    'sharp',
    'declare',
    'headline',
    'appreciation',
    'vivid',
    'well',
    'a',
    'm',
    'am',
    'A',
    'M',
    'AM',
    'thief',
    'skirt',
    'wildlife',
    'cater',
    'tissue',
    'leader',
    'hide',
    'bit',
    'pioneer',
    'nation',
    'disagree',
    'relevant',
    'drawer',
    'dip',
    'treatment',
    'regular',
    'duty',
    'metre',
    'download',
    'canal',
    'vague',
    'foot',
    'letter',
    'sadness',
    'skate',
    'motherland',
    'dress',
    'some',
    'major',
    'lie',
    'tractor',
    'plus',
    'honour',
    'bow',
    'public',
    'reform',
    'fill',
    'mathematics',
    'math',
    'maths',
    'admission',
    'throat',
    'civil',
    'goat',
    'watch',
    'environment',
    'taxpayer',
    'whether',
    'anxiety',
    'carrier',
    'captain',
    'apology',
    'broadcast',
    'compete',
    'matter',
    'decision',
    'unwilling',
    'Europe',
    'coincidence',
    'circle',
    'oppose',
    'forty',
    'arrest',
    'shore',
    'unit',
    'origin',
    'use',
    'inn',
    'electronic',
    'volunteer',
    'team',
    'burst',
    'thread',
    'innocent',
    'skyscraper',
    'hero',
    'twin',
    'tiny',
    'expense',
    'surface',
    'swift',
    'thermos',
    'tutor',
    'dimension',
    'god',
    'behave',
    'jog',
    'wax',
    'bad',
    'outside',
    'vital',
    'leaf',
    'Asian',
    'pet',
    'each',
    'no',
    'theater',
    'think',
    'storm',
    'neighbourhood',
    'clock',
    'dare',
    'explode',
    'peaceful',
    'pale',
    'assumption',
    'typewriter',
    'concentrate',
    'several',
    'bell',
    'bitter',
    'reason',
    'dance',
    'pest',
    'shame',
    'bored',
    'point',
    'analysis',
    'bus',
    'identification',
    'need',
    'spoon',
    'nephew',
    'physician',
    'judgment',
    'gallon',
    'meeting',
    'tobacco',
    'wash',
    'relation',
    'breathe',
    'clean',
    'chart',
    'faith',
    'hook',
    'percent',
    'instruction',
    'daughter',
    'intention',
    'yourself',
    'booth',
    'secure',
    'semicircle',
    'voice',
    'food',
    'strait',
    'addicted',
    'cartoon',
    'prepare',
    'shave',
    'fight',
    'apparent',
    'metal',
    'pink',
    'passive',
    'lovely',
    'transparent',
    'click',
    'outward',
    's',
    'adolescent',
    'than',
    'fire',
    'sick',
    'grasp',
    'ashamed',
    'black',
    'interpreter',
    'weed',
    'from',
    'beauty',
    'schoolboy',
    'towel',
    'beg',
    'biochemistry',
    'into',
    'symptom',
    'subscribe',
    'shrink',
    'allow',
    'accountant',
    'disturb',
    'avenue',
    'meet',
    'message',
    'bread',
    'sheet',
    'secret',
    'whenever',
    'pardon',
    'physical',
    'athlete',
    'requirement',
    'glory',
    'surround',
    'violin',
    'aluminium',
    'birthplace',
    'nuclear',
    'equal',
    'most',
    'often',
    'soup',
    'rigid',
    'adjustment',
    'blue',
    'abstract',
    'steady',
    'rope',
    'sink',
    'goose',
    'place',
    'truck',
    'job',
    'wide',
    'compromise',
    'arrival',
    'rooster',
    'tick',
    'intelligence',
    'theme',
    'wait',
    'postpone',
    'hole',
    'deserve',
    'institute',
    'surrounding',
    'twice',
    'coal',
    'draw',
    'yard',
    'destroy',
    'rag',
    'correction',
    'ownership',
    'predict',
    'agency',
    'I',
    'automatic',
    'guess',
    'lunch',
    'rugby',
    'burden',
    'enter',
    'discussion',
    'struggle',
    'editor',
    'reduce',
    'prohibit',
    'persuade',
    'day',
    'sharpener',
    'research',
    'greet',
    'educator',
    'penny',
    'get',
    'cheap',
    'lose',
    'customs',
    'salty',
    'height',
    'find',
    'above',
    'aid',
    'Arctic',
    'fuel',
    'socialism',
    'bend',
    'terminal',
    'compulsory',
    'winner',
    'grass',
    'sweet',
    'stream',
    'irrigation',
    'busy',
    'low',
    'swap',
    'musician',
    'cuisine',
    'sacrifice',
    'recommend',
    'soldier',
    'ruin',
    'possible',
    'anyway',
    'judge',
    'triangle',
    'mother',
    'attraction',
    'pool',
    'birthday',
    'brown',
    'howl',
    'personally',
    'offshore',
    'application',
    'dioxide',
    'suite',
    'obvious',
    'wife',
    'ham',
    'speaker',
    'mistake',
    'least',
    'game',
    'sympathy',
    'league',
    'clumsy',
    'millionaire',
    'tournament',
    'nod',
    'socket',
    'willing',
    'blame',
    'status',
    'sincerely',
    'emergency',
    'nature',
    'seal',
    'pollute',
    'sometimes',
    'contribute',
    'poster',
    'postage',
    'routine',
    'kettle',
    'piece',
    'listen',
    'lesson',
    'painter',
    'neither',
    'postcode',
    'electric',
    'competition',
    'leather',
    'seem',
    'sausage',
    'format',
    'bamboo',
    'expose',
    'protect',
    'accident',
    'cubic',
    'yoghurt',
    'dictation',
    'plate',
    'inspire',
    'grandson',
    'stop',
    'anyhow',
    'merciful',
    'bathroom',
    'journey',
    'patience',
    'cinema',
    'chair',
    'survive',
    'change',
    'litre',
    'onto',
    'dirty',
    'mineral',
    'gather',
    'milk',
    'grill',
    'wall',
    'object',
    'spot',
    'ready',
    'patent',
    'land',
    'policewoman',
    'media',
    'tale',
    'guest',
    'positive',
    'precise',
    'march',
    'speed',
    'o',
    'clock',
    'donate',
    'want',
    'polite',
    'troop',
    'hotel',
    'classify',
    'fingernail',
    'facial',
    'classmate',
    'graduation',
    'pattern',
    'card',
    'powerful',
    'brewery',
    'homeland',
    'distant',
    'trust',
    'stage',
    'is',
    'sell',
    'import',
    'convince',
    'suffering',
    'pork',
    'grocer',
    'satellite',
    'statistics',
    'himself',
    'defence',
    'rate',
    'tense',
    'army',
    'factory',
    'necessary',
    'agriculture',
    'impression',
    'accustomed',
    'few',
    'flow',
    'hold',
    'moustache',
    'corrupt',
    'tasty',
    'swear',
    'condition',
    'steep',
    'courage',
    'marry',
    'extreme',
    'those',
    'that',
    'tourism',
    'ground',
    'glove',
    'contain',
    'chain',
    'midnight',
    'obtain',
    'will',
    'acid',
    'stair',
    'update',
    'pay',
    'evidence',
    'carpet',
    'advocate',
    'cheer',
    'blow',
    'reject',
    'comprehension',
    'bathe',
    'dumpling',
    'high',
    'my',
    'airspace',
    'promise',
    'athletic',
    'headmistress',
    'slim',
    'after',
    'afterward',
    's',
    'refuse',
    'organ',
    'cautious',
    'advise',
    'fountain',
    'wet',
    'PE',
    'physical',
    'education',
    'remind',
    'whole',
    'down',
    'weekend',
    'punctuation',
    'shopping',
    'flag',
    'violate',
    'premier',
    'slice',
    'hunt',
    'healthy',
    'respond',
    'approve',
    'peach',
    'avoid',
    'sort',
    'daily',
    'trick',
    'bean',
    'curd',
    'many',
    'approach',
    'enquiry',
    'rude',
    'slow',
    'cab',
    'band',
    'transform',
    'paragraph',
    'freeway',
    'production',
    'international',
    'invent',
    'security',
    'rectangle',
    'his',
    'treasure',
    'govern',
    'discount',
    'fantastic',
    'sight',
    'delay',
    'restaurant',
    'independence',
    'spoken',
    'might',
    'which',
    'accept',
    'read',
    'every',
    'scientist',
    'so',
    'fever',
    'acre',
    'argument',
    'holy',
    'crew',
    'door',
    'today',
    'meal',
    'walk',
    'scenery',
    'found',
    'gesture',
    'come',
    'ample',
    'due',
    'tree',
    'meanwhile',
    'try',
    'construction',
    'intend',
    'nervous',
    'here',
    'divide',
    'page',
    'movement',
    'decrease',
    'raise',
    'bench',
    'fence',
    'manager',
    'interval',
    'bowl',
    'heel',
    'disability',
    'case',
    'sweat',
    'link',
    'exist',
    'mourn',
    'performance',
    'glad',
    'ancestor',
    'gun',
    'recognise',
    'different',
    'toast',
    'civilization',
    'language',
    'flee',
    'zebra',
    'select',
    'never',
    'broken',
    'mutton',
    'video',
    'twist',
    'shadow',
    'stocking',
    'algebra',
    'help',
    'cookie',
    'elegant',
    'endless',
    'centigrade',
    'glue',
    'concern',
    'basic',
    'wallet',
    'wave',
    'dish',
    'spelling',
    'know',
    'goods',
    'practise',
    'clothes',
    'scientific',
    'instead',
    'teenager',
    'welcome',
    'careless',
    'weigh',
    'parking',
    'human',
    'being',
    'used',
    'north',
    'chopsticks',
    'principle',
    'loud',
    'African',
    'size',
    'strike',
    'biology',
    'absence',
    'deaf',
    'rare',
    'unrest',
    'saleswoman',
    'royal',
    'below',
    'movie',
    'bowling',
    'resist',
    'kingdom',
    'powder',
    'condemn',
    'capsule',
    'let',
    'practical',
    'paddle',
    'temperature',
    'apart',
    'butterfly',
    'stand',
    'concert',
    'maximum',
    'simplify',
    'sleep',
    'spring',
    'tooth',
    'exercise',
    'reach',
    'overhead',
    'heaven',
    'dignity',
    'believe',
    'commitment',
    'parent',
    'tired',
    'tennis',
    'flesh',
    'ping',
    'pong',
    'circuit',
    'decoration',
    'review',
    'courtyard',
    'potato',
    'various',
    'destination',
    'appoint',
    'affection',
    'severe',
    'bush',
    'conductor',
    'sceptical',
    'mask',
    'why',
    'poor',
    'great',
    'solid',
    'permanent',
    'nest',
    'dust',
    'assess',
    'impossible',
    'would',
    'fat',
    'rapid',
    'northeast',
    'oral',
    'typical',
    'harmful',
    'darkness',
    'defeat',
    'spokeswoman',
    'beneficial',
    'wherever',
    'skip',
    'but',
    'Olympic',
    'confuse',
    'preference',
    'artificial',
    'expression',
    'drink',
    'check',
    'ban',
    'interrupt',
    'divorce',
    'variety',
    'altogether',
    'anniversary',
    'herb',
    'jump',
    'foolish',
    'quick',
    'he',
    'deposit',
    'at',
    'train',
    'shabby',
    'ripen',
    'worldwide',
    'computer',
    'sob',
    'kick',
    'thirst',
    'partly',
    'upset',
    'chalk',
    'diagram',
    'appear',
    'lamp',
    'if',
    'lorry',
    'congratulation',
    'forgetful',
    'castle',
    'skatebroad',
    'toothpaste',
    'ordinary',
    'piano',
    'collection',
    'emperor',
    'remove',
    'unlike',
    'encouragement',
    'bungalow',
    'lazy',
    'measure',
    'perhaps',
    'native',
    'ought',
    'wag',
    'become',
    'astronomer',
    'contemporary',
    'villager',
    'rewind',
    'when',
    'receive',
    'other',
    'salary',
    'potential',
    'compass',
    'animal',
    'ear',
    'pension',
    'annual',
    'salesman',
    'month',
    'behind',
    'drug',
    'creature',
    'hire',
    'respect',
    'granddaughter',
    'partner',
    'jaw',
    'mind',
    'total',
    'alarm',
    'aggressive',
    'mobile',
    'attention',
    'require',
    'air',
    'basement',
    'belong',
    'equipment',
    'recite',
    'standard',
    'straight',
    'chief',
    'decade',
    'shot',
    'earthquake',
    'scare',
    'PC',
    'personal',
    'computer',
    'access',
    'inform',
    'rain',
    'envy',
    'feeling',
    'keep',
    'flour',
    'yell',
    'rid',
    'badminton',
    'newspaper',
    'aim',
    'disadvantage',
    'admirable',
    'stress',
    'unable',
    'occupy',
    'laughter',
    'referee',
    'part',
    'introduce',
    'time',
    'pulse',
    'information',
    'soon',
    'theoretical',
    'junior',
    'journalist',
    'chemist',
    'pace',
    'frequent',
    'explicit',
    'bounce',
    'cat',
    'happen',
    'chemistry',
    'sharpen',
    'safe',
    'form',
    'steal',
    'toilet',
    'clothing',
    'prescription',
    'spell',
    'advice',
    'belief',
    'differ',
    'graduate',
    'seek',
    'spirit',
    'nail',
    'female',
    'development',
    'bottle',
    'blank',
    'round',
    'host',
    'cattle',
    'barber',
    'basis',
    'bite',
    'phone',
    'telephone',
    'parallel',
    'friend',
    'gym',
    'gymnasium',
    'equip',
    'way',
    'occupation',
    'appearance',
    'health',
    'bomb',
    'tour',
    'print',
    'addition',
    'apartment',
    'shut',
    'supper',
    'play',
    'guilty',
    'beast',
    'diary',
    'local',
    'dog',
    'progress',
    'boxing',
    'line',
    'diverse',
    'breakthrough',
    'dictionary',
    'supermarket',
    'shower',
    'wise',
    'controversial',
    'background',
    'spiritual',
    'handle',
    'bridge',
    'succeed',
    'calculate',
    'private',
    'reality',
    'accuracy',
    'smart',
    'sad',
    'butter',
    'contradictory',
    'passenger',
    'contribution',
    'beautiful',
    'sideway',
    'brand',
    'maybe',
    'easy',
    'close',
    'bunch',
    'actual',
    'statesman',
    'province',
    'fierce',
    'Mrs',
    'net',
    'age',
    'owner',
    'silver',
    'per',
    'deep',
    'summary',
    'flash',
    'citizen',
    'Christmas',
    'opposite',
    'blanket',
    'pregnant',
    'one',
    'anchor',
    'root',
    'wear',
    'participate',
    'firm',
    'neck',
    'request',
    'refrigerator',
    'pile',
    'changeable',
    'brave',
    'technology',
    'magazine',
    'the',
    'sparrow',
    'cook',
    'evaluate',
    'traditional',
    'man',
    'profit',
    'random',
    'bean',
    'botanical',
    'natural',
    'night',
    'double',
    'shortly',
    'lounge',
    'teapot',
    'scholarship',
    'tease',
    'warehouse',
    'quiet',
    'bag',
    'side',
    'uniform',
    'pray',
    'just',
    'pupil',
    'whale',
    'helpful',
    'tall',
    'hers',
    'outcome',
    'eager',
    'title',
    'northern',
    'bother',
    'silence',
    'sensitive',
    'scissors',
    'oneself',
    'sail',
    'arrange',
    'postcard',
    'ray',
    'clear',
    'kilogram',
    'typhoon',
    'dismiss',
    'law',
    'disappointed',
    'failure',
    'contradict',
    'primitive',
    'artist',
    'boss',
    'Catholic',
    'chemical',
    'aunt',
    'science',
    'operator',
    'outer',
    'dangerous',
    'birth',
    'arm',
    'improve',
    'separate',
    'expand',
    'America',
    'rubber',
    'police',
    'wire',
    'hurt',
    'virus',
    'textbook',
    'away',
    'winter',
    'carry',
    'acknowledge',
    'block',
    'cycle',
    'fisherman',
    'housework',
    'freedom',
    'discrimination',
    'normal',
    'official',
    'reserve',
    'refresh',
    'accurate',
    'finance',
    'cross',
    'everybody',
    'enjoyable',
    'visit',
    'modem',
    'word',
    'raincoat',
    'nationwide',
    'learn',
    'injury',
    'brother',
    'garbage',
    'tomb',
    'unfair',
    'insect',
    'her',
    'jar',
    'vegetable',
    'she',
    'silent',
    'pack',
    'clap',
    'pain',
    'able',
    'remote',
    'heat',
    'dormitory',
    'worthy',
    'choke',
    'send',
    'both',
    'industry',
    'fall',
    'fragile',
    'maple',
    'bank',
    'suspension',
    'minus',
    'mouse',
    'seize',
    'fax',
    'sing',
    'smell',
    'foggy',
    'occur',
    'pie',
    'cushion',
    'absurd',
    'examine',
    'thin',
    'yellow',
    'salt',
    'sea',
    'free',
    'cream',
    'hungry',
    'elect',
    'policeman',
    'confident',
    'drive',
    'room',
    'nobody',
    'board',
    'cash',
    'important',
    'blouse',
    'name',
    'acquisition',
    'write',
    'article',
    'sheep',
    'marble',
    'self',
    'lung',
    'incident',
    'juice',
    'vinegar',
    'overcoat',
    'tea',
    'simple',
    'snake',
    'concrete',
    'wealth',
    'hand',
    'encourage',
    'swell',
    'good',
    'record',
    'pair',
    'package',
    'entry',
    'extraordinary',
    'harmony',
    'ton',
    'him',
    'quite',
    'attract',
    'publish',
    'uncertain',
    'invitation',
    'whose',
    'enjoy',
    'conservative',
    'stare',
    'spray',
    'money',
    'garden',
    'either',
    'map',
    'e',
    'mail',
    'email',
    'theory',
    'noble',
    'nowhere',
    'produce',
    'sunburnt',
    'shape',
    'too',
    'receipt',
    'me',
    'ski',
    'son',
    'fur',
    'date',
    'optimistic',
    'toothbrush',
    'cap',
    'vote',
    'mirror',
    'shoe',
    'butcher',
    'specialist',
    'cake',
    'bachelor',
    'fruit',
    'tongue',
    'pyramid',
    'kite',
    'carpenter',
    'supreme',
    'cousin',
    'special',
    'somehow',
    'honest',
    'generation',
    'figure',
    'capital',
    'friendship',
    'pencil',
    'lantern',
    'social',
    'lame',
    'drop',
    'finger',
    'allocate',
    'boat',
    'farmer',
    'turning',
    'brochure',
    'possess',
    'pull',
    'magic',
    'save',
    'goal',
    'schoolmate',
    'period',
    'smooth',
    'wealthy',
    'merely',
    'serious',
    'dawn',
    'cup',
    'consume',
    'pond',
    'kind',
    'cough',
    'somewhere',
    'mine',
    'soccer',
    'politician',
    'anywhere',
    'second',
    'alphabet',
    'ripe',
    'hopeless',
    'performer',
    'steam',
    'digital',
    'biography',
    'abundant',
    'canteen',
    'introduction',
    'past',
    'mature',
    'quiz',
    'planet',
    'ourselves',
    'start',
    'seashell',
    'insurance',
    'adventure',
    'enemy',
    'appendix',
    'cancel',
    'unite',
    'damage',
    'rob',
    'method',
    'immediately',
    'fun',
    'brief',
    'electricity',
    'football',
    'exit',
    'morning',
    'liberty',
    'swim',
    'assistant',
    'moral',
    'book',
    'umbrella',
    'operation',
    'however',
    'hunger',
    'order',
    'consult',
    'unusual',
    'preserve',
    'headache',
    'teach',
    'palace',
    'desperate',
    'accessible',
    'lay',
    'am',
    'cause',
    'lemon',
    'motto',
    'stainless',
    'slip',
    'mosquito',
    'small',
    'understand',
    'talent',
    'activity',
    'astonish',
    'regardless',
    'training',
    'season',
    'although',
    'fiction',
    'take',
    'key',
    'bonus',
    'hard',
    'republic',
    'railway',
    'early',
    'final',
    'sit',
    'adequate',
    'accelerate',
    'education',
    'voluntary',
    'desert',
    'pollution',
    'pianist',
    'via',
    'settlement',
    'receptionist',
    'alongside',
    'out',
    'arithmetic',
    'foresee',
    'dilemma',
    'madam',
    'madame',
    'purse',
    'exhibition',
    'popular',
    'year',
    'dynamic',
    'CD',
    'compact',
    'disk',
    'awkward',
    'cabbage',
    'conservation',
    'by',
    'leak',
    'note',
    'strange',
    'inspect',
    'tube',
    'symbol',
    'sleepy',
    'acquaintance',
    'slight',
    'scan',
    'national',
    'shopkeeper',
    'sky',
    'behalf',
    'engine',
    'recover',
    'yes',
    'fine',
    'teacher',
    'accomplish',
    'explain',
    'tram',
    'company',
    'transport',
    'fellow',
    'attend',
    'colour',
    'bury',
    'purchase',
    'quake',
    'act',
    'follow',
    'grocery',
    'crash',
    'plane',
    'systematic',
    'network',
    'fundamental',
    'trade',
    'superior',
    'hotdog',
    'dial',
    'complete',
    'cheerful',
    'frontier',
    'battle',
    'pause',
    'warmth',
    'ruler',
    'mild',
    'explanation',
    'drawback',
    'proud',
    'cigarette',
    'strong',
    'tune',
    'offer',
    'long',
    'thought',
    'absorb',
    'mend',
    'invention',
    'victim',
    'responsibility',
    'minister',
    'tell',
    'sun',
    'rot',
    'beside',
    'approval',
    'radium',
    'pressure',
    'sorrow',
    'consider',
    'diamond',
    'drag',
    'apply',
    'useless',
    'register',
    'depth',
    'difference',
    'X',
    'ray',
    'X',
    'lack',
    'sentence',
    'tend',
    'announce',
    'division',
    'initial',
    'income',
    'all',
    'fist',
    'abolish',
    'them',
    'they',
    'grandma',
    'grandmother',
    'stand',
    'bicycle',
    'fear',
    'engineer',
    'arbitrary',
    'spoonful',
    'hang',
    'tape',
    'particular',
    'assistance',
    'mail',
    'hi',
    'settle',
    'forecast',
    'comment',
    'lady',
    'nursery',
    'radiation',
    'passport',
    'prove',
    'road',
    'house',
    'while',
    'row',
    'precious',
    'arch',
    'mass',
    'grape',
    'poison',
    'statement',
    'mouth',
    'merchant',
    'European',
    'roundabout',
    'wish',
    'enlarge',
    'AIDS',
    'abuse',
    'narrow',
    'grandparents',
    'action',
    'quality',
    'beach',
    'acute',
    'yesterday',
    'general',
    'far',
    'celebration',
    'react',
    'elder',
    'doctor',
    'stone',
    'loss',
    'playground',
    'cheque',
    'sneeze',
    'distinction',
    'gymnastics',
    'concept',
    'excellent',
    'common',
    'commercial',
    'demand',
    'presentation',
    'choir',
    'white',
    'stateswoman',
    'southern',
    'crossroads',
    'kitchen',
    'hobby',
    'preview',
    'win',
    'west',
    'hour',
    'haircut',
    'relay',
    'humour',
    'text',
    'possibility',
    'literary',
    'effort',
    'sir',
    'shark',
    'T',
    'shirt',
    'T',
    'art',
    'grow',
    'forever',
    'banana',
    'opinion',
    'awake',
    'invite',
    'administration',
    'slavery',
    'bishop',
    'diploma',
    'attractive',
    'between',
    'watermelon',
    'deadline',
    'car',
    'elephant',
    'minimum',
    'hammer',
    'baby',
    'exchange',
    'kangaroo',
    'crossing',
    'do',
    'work',
    'ambition',
    'base',
    'loaf',
    'president',
    'businesswoman',
    'merry',
    'minibus',
    'insure',
    'drum',
    'dark',
    'mistaken',
    'Moslem',
    'Muslim',
    'weak',
    'hunter',
    'rainy',
    'degree',
    'club',
    'scold',
    'session',
    'whom',
    'tomorrow',
    'cooker',
    'process',
    'library',
    'beat',
    'neighbour',
    'truth',
    'recent',
    'author',
    'dollar',
    'abandon',
    'beard',
    'silk',
    'BC',
    'tight',
    'bat',
    'victory',
    'honey',
    'substitute',
    'themselves',
    'zipper',
    'licence',
    'chapter',
    'unique',
    'hardly',
    'nut',
    'lawyer',
    'aware',
    'being',
    'alcoholic',
    'vehicle',
    'campaign',
    'upper',
    'lamb',
    'track',
    'branch',
    'large',
    'optional',
    'bacon',
    'whichever',
    'fasten',
    'convey',
    'problem',
    'pilot',
    'sickness',
    'hardworking',
    'atom',
    'eggplant',
    'lip',
    'rubbish',
    'hope',
    'embassy',
    'tin',
    'cost',
    'pin',
    'favour',
    'walnut',
    'entire',
    'mom',
    'mum',
    'share',
    'experiment',
    'leave',
    'sugar',
    'bent',
    'serve',
    'permit',
    'missile',
    'pill',
    'earth',
    'upward',
    's',
    'golf',
    'sculpture',
    'fortnight',
    'lend',
    'fish',
    'near',
    'sound',
    'feel',
    'successful',
    'dry',
    'return',
    'only',
    'waist',
    'trial',
    'ride',
    'put',
    'thorough',
    'and',
    'green',
    'sideroad',
    'rebuild',
    'around',
    'bathtub',
    'conventional',
    'discovery',
    'communication',
    'illegal',
    'now',
    'wrist',
    'museum',
    'guidance',
    'rainfall',
    'awful',
    'cosy',
    'tolerate',
    'rank',
    'throw',
    'category',
    'illness',
    'everywhere',
    'retell',
    'member',
    'petrol',
    'bedroom',
    'ceremony',
    'balance',
    'mustard',
    'polish',
    'constant',
    'uncle',
    'tiresome',
    'tailor',
    'disturbing',
    'moment',
    'statue',
    'moon',
    'system',
    'bargain',
    'energetic',
    'alcohol',
    'expectation',
    'instrument',
    'reliable',
    'equality',
    'greeting',
    'generous',
    'shuttle',
    'or',
    'handkerchief',
    'to',
    'fog',
    'everyone',
    'enterprise',
    'trunk',
    'soft',
    'comb',
    'useful',
    'bride',
    'oil',
    'sudden',
    'before',
    'sponsor',
    'always',
    'candy',
    'pavement',
    'hit',
    'biscuit',
    'table',
    'of',
    'modern',
    'kiss',
    'instruct',
    'without',
    'weight',
    'starvation',
    'city',
    'you',
    'consistent',
    'orange',
    'scream',
    'Oceania',
    'shelter',
    'characteristic',
    'evident',
    'inside',
    'trend',
    'appreciate',
    'fan',
    'attempt',
    'ankle',
    'spaceship',
    'indeed',
    'carrot',
    'abrupt',
    'curriculum',
    'depend',
    'plan',
    'market',
    'eventually',
    'schedule',
    'cool',
    'yummy',
    'strength',
    'fluent',
    'pedestrian',
    'claw',
    'suit',
    'party',
    'set',
    'task',
    'seat',
    'school',
    'applaud',
    'world',
    'furnished',
    'anger',
    'seagull',
    'department',
    'bring',
    'cheese',
    'press',
    'sweep',
    'panic',
    'pub',
    'suspect',
    'prevent',
    'challenging',
    'live',
    'bar',
    'pan',
    'corner',
    'temple',
    'pass',
    'real',
    'frost',
    'trip',
    'character',
    'tyre',
    'race',
    'through',
    'aspect',
    'novel',
    'permission',
    'wonder',
    'false',
    'our',
    'energy',
    'microscope',
    'grandchild',
    'exam',
    'examination',
    'climate',
    'suggestion',
    'consultant',
    'college',
    'Pacific',
    'shirt',
    'phenomenon',
    'cotton',
    'organization',
    'vase',
    'bleed',
    'cruel',
    'smoker',
    'terrify',
    'consist',
    'latter',
    'advertise',
    'harbour',
    'mark',
    'proper',
    'empty',
    'curtain',
    'style',
    'restriction',
    'upon',
    'camera',
    'loose',
    'university',
    'boot',
    'melon',
    'sour',
    'border',
    'coat',
    'hear',
    'consideration',
    'open',
    'anyone',
    'rocket',
    'ours',
    'notebook',
    'ambassadress',
    'skillful',
    'sale',
    'beer',
    'criterion',
    'translation',
    'weep',
    'tiger',
    'woollen',
    'have',
    'hesitate',
    'weakness',
    'balcony',
    'armchair',
    'extension',
    'southwest',
    'function',
    'reading',
    'business',
    'ugly',
    'connect',
    'cigar',
    'aboard',
    'grandpa',
    'grandfather',
    'justice',
    'debt',
    'begin',
    'raw',
    'countryside',
    'fry',
    'wipe',
    'smile',
    'fool',
    'everyday',
    'boom',
    'shaver',
    'erupt',
    'brush',
    'frog',
    'this',
    'court',
    'evolution',
    'insist',
    'grand',
    'week',
    'admit',
    'split',
    'forbid',
    'disaster',
    'society',
    'awesome',
    'embarrass',
    'provide',
    'vice',
    'muddy',
    'couple',
    'ant',
    'relax',
    'pocket',
    'cheek',
    'selfish',
    'forget',
    'balloon',
    'memory',
    'p',
    'm',
    'pm',
    'P',
    'M',
    'PM',
    'dead',
    'chocolate',
    'superb',
    'bee',
    'ad',
    'advertisement',
    'truly',
    'valuable',
    'draft',
    'scratch',
    'procedure',
    'be',
    'should',
    'soap',
    'alley',
    'religion',
    'primary',
    'No',
    'number',
    'punishment',
    'granny',
    'mat',
    'waiter',
    'include',
    'oval',
    'finish',
    'flexible',
    'dustbin',
    'any',
    'top',
    'stay',
    'souvenir',
    'left',
    'bone',
    'ability',
    'stomach',
    'basket',
    'available',
    'regret',
    'ever',
    'anything',
    'ago',
    'previous',
    'window',
    'thrill',
    'federal',
    'bottom',
    'physicist',
    'accompany',
    'increase',
    'murder',
    'accumulate',
    'for',
    'excite',
    'bath',
    'traffic',
    'classic',
    'festival',
    'rather',
    'drill',
    'allergic',
    'insert',
    'fare',
    'spear',
    'theirs',
    'conflict',
    'lecture',
    'even',
    'chaos',
    'youth',
    'fault',
    'desk',
    'list',
    'porridge',
    'tasteless',
    'backward',
    's',
    'suggest',
    'influence',
    'disagreement',
    'virtue',
    'personal',
    'guide',
    'damp',
    'future',
    'cent',
    'fold',
    'over',
    'golden',
    'translator',
    'queen',
    'queue',
    'librarian',
    'communism',
    'signal',
    'outgoing',
    'burglar',
    'deal',
    'motor',
    'growth',
    'state',
    'glass',
    'presence',
    'database',
    'office',
    'family',
    'motorcycle',
    'ridiculous',
    'duck',
    'overcome',
    'cafeteria',
    'motivation',
    'culture',
    'poet',
    'preparation',
    'centimetre',
    'gate',
    'tortoise',
    'hospital',
    'they',
    'architect',
    'heavy',
    'chance',
    'messy',
    'solar',
    'multiply',
    'plant',
    'film',
    'guitar',
    'then',
    'sister',
    'count',
    'experience',
    'once',
    'poem',
    'choice',
    'quantity',
    'immigration',
    'inch',
    'also',
    'similar',
    'outline',
    'ministry',
    'remain',
    'grain',
    'baggage',
    'clerk',
    'withdraw',
    'idiom',
    'architecture',
    'alone',
    'ward',
    'flame',
    'thinking',
    'pot',
    'mailbox',
    'academic',
    'bed',
    'hat',
    'caution',
    'pepper',
    'afford',
    'bound',
    'jewellery',
    'dash',
    'lightning',
    'stranger',
    'port',
    'nose',
    'customer',
    'practice',
    'turkey',
    'meat',
    'tail',
    'situation',
    'position',
    'construct',
    'push',
    'secretary',
    'stain',
    'tension',
    'schoolgirl',
    'risk',
    'late',
    'stamp',
    'absent',
    'challenge',
    'shine',
    'cell',
    'grade',
    'full',
    'collect',
    'minute',
    'catalogue',
    'clarify',
    'fade',
    'sunny',
    'worn',
    'roast',
    'picture',
    'horrible',
    'population',
    'nice',
    'AD',
    'colleague',
    'speak',
    'love',
    'child',
    'achieve',
    'discover',
    'spin',
    'adolescence',
    'nurse',
    'active',
    'panda',
    'adore',
    'forgive',
    'tire',
    'cold',
    'earn',
    'travel',
    'distribute',
    'jungle',
    'dull',
    'clever',
    'dislike',
    'pole',
    'radio',
    'former',
    'careful',
    'employ',
    'whistle',
    'separation',
    'happiness',
    'prayer',
    'underwear',
    'pine',
    'downstairs',
    'dizzy',
    'space',
    'cocoa',
    'abnormal',
    'young',
    'passage',
    'sideways',
    'cube',
    'extra',
    'tool',
    'show',
    'plot',
    'express',
    'southeast',
    'girl',
    'cave',
    'ache',
    'monkey',
    'target',
    'Mr',
    'ambulance',
    'unless',
    'noon',
    'range',
    'shake',
    'vocabulary',
    'miss',
    'dessert',
    'painful',
    'connection',
    'true',
    'casual',
    'strengthen',
    'circumstance',
    'knee',
    'tank',
    'handful',
    'gram',
    'during',
    'correct',
    'importance',
    'wheat',
    'ahead',
    'joke',
    'coffee',
    'shock',
    'punctual',
    'leg',
    'ink',
    'brake',
    'its',
    'anybody',
    'washroom',
    'sex',
    'holiday',
    'downtown',
    'mountainous',
    'organise',
    'strawberry',
    'starve',
    'expect',
    'worthwhile',
    'candle',
    'obey',
    'geometry',
    'doubt',
    'DVD',
    'digital',
    'video',
    'disk',
    'ballet',
    'web',
    'housewife',
    'role',
    'roll',
    'wrinkle',
    'tap',
    'make',
    'eye',
    'traveller',
    'neat',
    'where',
    'almost',
    'ask',
    'laundry',
    'move',
    'labour',
    'a',
    'feast',
    'swallow',
    'pen',
    'award',
    'handy',
    'reporter',
    'relate',
    'stubborn',
    'identify',
    'entrance',
    'forest',
    'that',
    'ice',
    'cream',
    'remember',
    'lemonade',
    'dusty',
    'delight',
    'westward',
    's',
    'litter',
    'imagine',
    'support',
    'machine',
    'charge',
    'fancy',
    'end',
    'disabled',
    'associate',
    'entertainment',
    'fond',
    'porter',
    'hate',
    'appointment',
    'woman',
    'class',
    'album',
    'delighted',
    'fork',
    'promote',
    'doll',
    'cry',
    'bright',
    'deliver',
    'catastrophe',
    'comfortable',
    'portable',
    'not',
    'retire',
    'visitor',
    'ecology',
    'own',
    'recipe',
    'history',
    'luck',
    'visa',
    'unfortunate',
    'achievement',
    'rabbit',
    'programme',
    'sofa',
    'battery',
    'postman',
    'electrical',
    'talk',
    'mercy',
    'iron',
    'present',
    'baseball',
    'strict',
    'bare',
    'airline',
    'comedy',
    'century',
    'dear',
    'apron',
    'flat',
    'assist',
    'sport',
    'politics',
    'fly',
    'actor',
    'farm',
    'song',
    'outing',
    'belly',
    'typist',
    'policy',
    'float',
    'buffet',
    'settler',
    'headmaster',
    'happy',
    'catch',
    'medium',
    'steward',
    'riddle',
    'bear',
    'nearby',
    'mess',
    'paperwork',
    'flu',
    'supply',
    'model',
    'mist',
    'Dr',
    'doctor',
    'popcorn',
    'corn',
    'old',
    'chew',
    'exact',
    'aircraft',
    'view',
    'bike',
    'bicycle',
    'hydrogen',
    'astronomy',
    'cupboard',
    'rule',
    'flower',
    'project',
    'test',
    'represent',
    'shallow',
    'weekday',
    'document',
    'thank',
    'purpose',
    'step',
    'bark',
    'overweight',
    'tower',
    'direct',
    'liquid',
    'worm',
    'hello',
    'hamburger',
    'chorus',
    'stove',
    'reputation',
    'sweater',
    'affect',
    'windy',
    'may',
    'niece',
    'regulation',
    'soul',
    'eyesight',
    'brick',
    'till',
    'harm',
    'ambassador',
    'sailor',
    'egg',
    'wind',
    'tourist',
    'mountain',
    'gallery',
    'clone',
    'mushroom',
    'northwest',
    'needle',
    'tie',
    'trolleybus',
    'committee',
    'in',
    'lap',
    'everything',
    'warm',
    'cyclist',
    'widow',
    'shall',
    'yawn',
    'afternoon',
    'Buddhism',
    'timetable',
    'chairman',
    'are',
    'funny',
    'decorate',
    'edge',
    'file',
    'boycott',
    'underline',
    'technique',
    'childhood',
    'blood',
    'pound',
    'crop',
    'celebrate',
    'absolute',
    'describe',
    'sock',
    'breathless',
    'liberation',
    'knife',
    'rose',
    'custom',
    'resemble',
    'bye',
    'graph',
    'worried',
    'salute',
    'amount',
    'ignore',
    'whoever',
    'barbecue',
    'delicious',
    'summer',
    'rich',
    'telescope',
    'abroad',
    'beef',
    'accuse',
    'sleeve',
    'mm',
    'millimetre',
    'body',
    'navy',
    'basin',
    'say',
    'dusk',
    'these',
    'this',
    'student',
    'steel',
    'friendly',
    'music',
    'altitude',
    'sure',
    'wrestle',
    'it',
    'treat',
    'wonderful',
    'probably',
    'button',
    'force',
    'ambiguous',
    'bridegroom',
    'really',
    'gentleman',
    'giraffe',
    'possession',
    'boil',
    'telephone',
    'recycle',
    'cloth',
    'shoulder',
    'park',
    'confirm',
    'compare',
    'answer',
    'mankind',
    'wolf',
    'danger',
    'hug',
    'camel',
    'shortcoming',
    'river',
    'about',
    'tear',
    'antique',
    'thing',
    'unbearable',
    'sneaker',
    'circus',
    'familiar',
    'still',
    'pretend',
    'beddings',
    'whatever',
    'amaze',
    'vacant',
    'suffer',
    'Atlantic',
    'flood',
    'devotion',
    'wedding',
    'rush',
    'difficulty',
    'friction',
    'king',
    'schoolbag',
    'urge',
    'screen',
    'cast',
    'steak',
    'parcel',
    'square',
    'warn',
    'lock',
    'under',
    'debate',
    'tough',
    'design',
    'corporation',
    'negotiate',
    'new',
    'tip',
    'modest',
    'association',
    'adopt',
    'constitution',
    'curious',
    'medal',
    'taxi',
    'arrangement',
    'packet',
    'pour',
    'group',
    'crayon',
    'musical',
    'angry',
    'boundary',
    'spokesman',
    'lonely',
    'though',
    'academy',
    'their',
    'outspoken',
    'length',
    'thick',
    'wing',
    'myself',
    'digest',
    'plenty',
    'fair',
    'squeeze',
    'product',
    'mention',
    'coach',
    'suitable',
    'kid',
    'lion',
    'straight',
    'forward',
    'there',
    'educate',
    'disk',
    'disc',
    'calm',
    'fridge',
    'refrigerator',
    'distance',
    'relative',
    'satisfaction',
    'village',
    'television',
];
exports.default = classNameList;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/handleClassName/index.js":
/*!********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/handleClassName/index.js ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList_1 = __webpack_require__(/*! ./classNameList */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/handleClassName/classNameList.js");
/**
 * 为代码添加className
 * @param data
 * @param numObj
 */
const handleClassName = (data, numObj = { num: 0 }) => {
    for (let i = 0; i < data.length; i++) {
        const layer = data[i];
        const currIndex = numObj.num % classNameList_1.default.length; //英文单词下标
        const numIndex = Math.floor(numObj.num / classNameList_1.default.length) + 1; //数字后缀
        layer.className = numIndex > 1 ? classNameList_1.default[currIndex] + numIndex : classNameList_1.default[currIndex];
        numObj.num++;
        if (Array.isArray(layer.children)) {
            layer.children = handleClassName(layer.children, numObj);
        }
    }
    return data;
};
exports.default = handleClassName;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/index.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/index.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoArtboardCodeParse = exports.picassoArtboardMeatureParse = void 0;
const parseDSL_1 = __webpack_require__(/*! ./parseDSL */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/index.js");
const parseArtboard_1 = __webpack_require__(/*! ./parseArtboard */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/index.js");
const handleClassName_1 = __webpack_require__(/*! ./handleClassName */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/handleClassName/index.js");
const src_1 = __webpack_require__(/*! ../../picasso-group/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-group/src/index.js");
const src_2 = __webpack_require__(/*! ../../picasso-layout/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-layout/src/index.js");
/**
 * @description Picasso 画板标注解析方法
 * @param { SKLayer } layer 当前图层
 * @returns { Promise<DSL> }
 *
 */
exports.picassoArtboardMeatureParse = (layer) => {
    // 画板处理
    layer = parseArtboard_1.default(layer, 'measure');
    // DSL处理
    const DSL = parseDSL_1.default([layer]);
    return DSL[0];
};
/**
 * @description Picasso 画板代码解析方法
 * @param { SKLayer } layer 当前图层
 * @param { Object } imageFrameMap 当前图层
 * @returns { Promise<DSL> }
 *
 */
exports.picassoArtboardCodeParse = (layer) => {
    // 画板处理
    layer = parseArtboard_1.default(layer, 'code');
    // 1.DSL处理
    let DSL = parseDSL_1.default([layer]);
    // 2. 特征分组
    DSL = src_1.default(DSL);
    // 3. 布局处理
    DSL = src_2.default(DSL);
    // 4. 添加className
    DSL = handleClassName_1.default(DSL);
    return DSL[0];
};
// 代码生成
__exportStar(__webpack_require__(/*! ../../picasso-code-browser/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-code-browser/src/index.js"), exports);
// sketch DSL
__exportStar(__webpack_require__(/*! ../../sketch-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/filterHideLayer.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/filterHideLayer.js ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 过滤掉隐藏图层
 * @param layers
 */
const handleHideLayer = (layers) => {
    const layerArr = [];
    layers.forEach((layer) => {
        if (layer.isVisible) {
            if (Array.isArray(layer.layers)) {
                layer.layers = handleHideLayer(layer.layers);
            }
            layerArr.push(layer);
        }
    });
    return layerArr;
};
exports.default = handleHideLayer;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/fixPosition.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/fixPosition.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const _fixPosition = (layers, { x, y }) => {
    // 透明度传递
    layers = layers.map((layer) => {
        // x值修正
        layer.frame.x = layer.frame.x - x;
        // y值修正
        layer.frame.y = layer.frame.y - y;
        if (Array.isArray(layer.layers)) {
            layer.layers = _fixPosition(layer.layers, { x, y });
        }
        return layer;
    });
    return layers;
};
exports.default = (layers) => {
    // 基础坐标系
    const { x = 0, y = 0 } = layers[0] && layers[0].frame ? layers[0].frame : { x: 0, y: 0 };
    return _fixPosition(layers, { x, y });
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/formatCoordinate.js":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/formatCoordinate.js ***!
  \*****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 *
 * 坐标格式转换，将相对坐标系转换为绝对坐标系
 *
 */
const formatCoordinate = (layers, groupX = 0, groupY = 0, sizeX = 1, sizeY = 1, parentList = []) => {
    layers = layers.map((layer) => {
        // 背景色记录
        let bg = '0-0-0-0';
        if (layer.backgroundColor && layer.hasBackgroundColor && layer.includeBackgroundColorInExport) {
            const { red, green, blue, alpha } = layer.backgroundColor;
            bg = `${red}-${green}-${blue}-${alpha}`;
        }
        // 当前父图层属性列表
        let currParentList = [`${layer.frame.x},${layer.frame.y},${layer.frame.imgWidth},${layer.frame.imgHeight},${layer.do_objectID},${layer._class},${bg}`, ...parentList];
        layer.parentList = currParentList;
        layer.frame = {
            _class: 'rect',
            x: layer.frame.x * sizeX + groupX,
            y: layer.frame.y * sizeY + groupY,
            imgWidth: layer.frame.width,
            imgHeight: layer.frame.height,
            width: layer.frame.width * sizeX,
            height: layer.frame.height * sizeY,
            sizeX,
            sizeY,
        };
        // 当前缩放比例
        let currSizeX = sizeX, currSizeY = sizeY;
        //基础缩放比例计算
        if (layer._class === 'symbolInstance' && Array.isArray(layer.layers) && layer.layers.length === 1 && layer.layers[0]._class === 'symbolMaster') {
            let symbolInstanceRect = layer.frame;
            let symbolMasterRect = layer.layers[0].frame;
            currSizeX = sizeX * symbolInstanceRect.width / symbolMasterRect.width;
            currSizeY = sizeY * symbolInstanceRect.height / symbolMasterRect.height;
        }
        if (Array.isArray(layer.layers)) {
            layer.layers = formatCoordinate(layer.layers, layer.frame.x, layer.frame.y, currSizeX, currSizeY, currParentList);
        }
        return layer;
    });
    return layers;
};
exports.default = formatCoordinate;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleBorderCoordinate.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleBorderCoordinate.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleBorderCoordinate = (layers) => {
    layers = layers.map((layer) => {
        if (layer.style && layer.style.borders && layer._class != 'artboard') {
            let borderList = layer.style.borders.filter(item => item.isEnabled);
            // 只处理一层border的情况
            if (borderList.length == 1) {
                let borderStyle = borderList[0];
                if (borderStyle.position == 0) { // 中间边框
                    let w = borderStyle.thickness / 2;
                    layer.frame.width += borderStyle.thickness;
                    layer.frame.height += borderStyle.thickness;
                    layer.frame.x -= w;
                    layer.frame.y -= w;
                }
                else if (borderStyle.position == 2) { // 外边框
                    let w = borderStyle.thickness;
                    layer.frame.width += w * 2;
                    layer.frame.height += w * 2;
                    layer.frame.x -= w;
                    layer.frame.y -= w;
                }
            }
        }
        // 递归
        if (Array.isArray(layer.layers)) {
            layer.layers = handleBorderCoordinate(layer.layers);
        }
        return layer;
    });
    return layers;
};
exports.default = handleBorderCoordinate;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleOpacity.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleOpacity.js ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleOpacity = (layers, commonOpacity = 1) => {
    // 透明度传递
    layers = layers.map((layer) => {
        if (!layer.style) {
            layer.style = {
                _class: 'style'
            };
        }
        if (!layer.style.contextSettings) {
            layer.style.contextSettings = {
                _class: 'graphicsContextSettings',
                opacity: 1
            };
        }
        layer.style.contextSettings.opacity = layer.style.contextSettings.opacity * commonOpacity;
        if (Array.isArray(layer.layers)) {
            layer.layers = handleOpacity(layer.layers, layer.style.contextSettings.opacity);
        }
        return layer;
    });
    return layers;
};
exports.default = handleOpacity;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handlePanel.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handlePanel.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePanel = void 0;
const parsePanel_1 = __webpack_require__(/*! ../parsePanel */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/index.js");
exports.handlePanel = (layers) => {
    for (let i = 0; i < layers.length; i++) {
        layers[i].panel = parsePanel_1.parsePanel(layers[i]);
        if (Array.isArray(layers[i].layers)) {
            layers[i].layers = exports.handlePanel(layers[i].layers);
        }
    }
    return layers;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleSlice.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleSlice.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleSlice = (layers) => {
    // 子元素为切片
    if (Array.isArray(layers) && layers.length > 0) {
        for (let i = 0; i < layers.length; i++) {
            if (layers[i]._class === 'slice' && layers[i].isVisible) {
                let currSliceFrame = layers[i].frame;
                for (let j = 0; j < layers.length; j++) {
                    if (layers[j]._class !== 'slice' &&
                        layers[j].isVisible &&
                        layers[j].frame) {
                        let currFrame = layers[j].frame;
                        if (currFrame.x >= currSliceFrame.x &&
                            currFrame.y >= currSliceFrame.y &&
                            currFrame.x + currFrame.width <= currSliceFrame.x + currSliceFrame.width &&
                            currFrame.y + currFrame.height <= currSliceFrame.y + currSliceFrame.height) {
                            layers[j].isVisible = false;
                        }
                    }
                }
            }
            if (Array.isArray(layers[i].layers)) {
                layers[i].layers = handleSlice(layers[i].layers);
            }
        }
    }
    return layers;
};
exports.default = handleSlice;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleSlicePosition.js":
/*!********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleSlicePosition.js ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// 切片位置调整
const _handleSlicePosition = (layers) => {
    layers.sort((layerA, layerB) => {
        if (layerB._class === 'slice' || layerB._class === 'image') {
            if (layerA.frame.x <= layerB.frame.x
                && layerA.frame.y <= layerB.frame.y
                && layerA.frame.x + layerA.frame.width >= layerB.frame.x + layerB.frame.width
                && layerA.frame.y + layerA.frame.height >= layerB.frame.y + layerB.frame.height) {
                return -1;
            }
        }
        return 0;
    });
    for (let i = 0; i < layers.length; i++) {
        if (Array.isArray(layers[i].layers)) {
            layers[i].layers = _handleSlicePosition(layers[i].layers);
        }
    }
    return layers;
};
exports.default = _handleSlicePosition;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/index.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/index.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const filterHideLayer_1 = __webpack_require__(/*! ./filterHideLayer */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/filterHideLayer.js");
const handleBorderCoordinate_1 = __webpack_require__(/*! ./handleBorderCoordinate */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleBorderCoordinate.js");
const handleOpacity_1 = __webpack_require__(/*! ./handleOpacity */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleOpacity.js");
const fixPosition_1 = __webpack_require__(/*! ./fixPosition */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/fixPosition.js");
const handleSlice_1 = __webpack_require__(/*! ./handleSlice */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleSlice.js");
const formatCoordinate_1 = __webpack_require__(/*! ./formatCoordinate */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/formatCoordinate.js");
const handleSlicePosition_1 = __webpack_require__(/*! ./handleSlicePosition */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handleSlicePosition.js");
const trimByMask_1 = __webpack_require__(/*! ./trimByMask */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/trimByMask.js");
const handlePanel_1 = __webpack_require__(/*! ./handlePanel */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/handlePanel.js");
/**
 * 分别对每个画板进行处理
 */
exports.default = (layer, type) => {
    let layers = [layer];
    // border坐标处理(仅代码模式)
    if (type !== 'measure') {
        layers = handleBorderCoordinate_1.default(layers);
    }
    // 透明度透传
    layers = handleOpacity_1.default(layers);
    // 相对坐标系 => 绝对坐标系
    layers = formatCoordinate_1.default(layers);
    // 修正坐标值 基础坐标系调整为：0,0;
    layers = fixPosition_1.default(layers);
    // Mask剪切处理
    layers = trimByMask_1.default(layers);
    if (type === 'measure') {
        // 切片排序
        layers = handleSlicePosition_1.default(layers);
    }
    else {
        // 代码模式，处理切片
        layers = handleSlice_1.default(layers);
    }
    // 过滤隐藏图层
    layers = filterHideLayer_1.default(layers);
    // 属性面板解析
    layers = handlePanel_1.handlePanel(layers);
    return layers[0];
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/trimByMask.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseArtboard/trimByMask.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const calculateMaskIntersection = (parentMask, childMask) => {
    const maskFrame = Object.assign({}, childMask);
    const defaultFrame = { _class: 'rect', x: 0, y: 0, width: 0, height: 0 };
    if (maskFrame.x + maskFrame.width <= parentMask.x) {
        return defaultFrame;
    }
    if (maskFrame.y + maskFrame.height <= parentMask.y) {
        return defaultFrame;
    }
    if (maskFrame.x >= parentMask.x + parentMask.width) {
        return defaultFrame;
    }
    if (maskFrame.y >= parentMask.y + parentMask.height) {
        return defaultFrame;
    }
    if (maskFrame.x < parentMask.x) {
        maskFrame.width = maskFrame.x + maskFrame.width - parentMask.x;
        maskFrame.x = parentMask.x;
    }
    if (maskFrame.y < parentMask.y) {
        maskFrame.height = maskFrame.y + maskFrame.height - parentMask.y;
        maskFrame.y = parentMask.y;
    }
    if (maskFrame.x + maskFrame.width > parentMask.x + parentMask.width) {
        maskFrame.width = parentMask.x + parentMask.width - maskFrame.x;
    }
    if (maskFrame.y + maskFrame.height > parentMask.y + parentMask.height) {
        maskFrame.height = parentMask.y + parentMask.height - maskFrame.y;
    }
    return maskFrame;
};
/**
 * Mask剪切处理
 *
 * 作用范围：Mask上层的兄弟元素及其子元素
 * 关键点：
 * 1. Artboard是最大的Mask
 * 2. hasClippingMask Mask图层标识
 * 3. shouldBreakMaskChain 中断Mask标识
 * @param layers
 * @param param1
 */
const _mask = (layers, { flag = false, frame }) => {
    let currFrame;
    let maskFlag = false;
    // 标记阶段
    for (let i = 0; i < layers.length; i++) {
        // 中断mark, 从本层开始
        if (layers[i].shouldBreakMaskChain) {
            maskFlag = false;
        }
        if (flag || maskFlag) {
            if (flag && maskFlag) {
                frame = calculateMaskIntersection(frame, currFrame);
            }
            else if (maskFlag) {
                frame = Object.assign({}, currFrame);
            }
            flag = true;
            // 存在mask的时候用mask进行剪切
            layers[i].frame = calculateMaskIntersection(frame, layers[i].frame);
        }
        // 是否中断
        if (layers[i].hasClippingMask) {
            maskFlag = true;
            currFrame = layers[i].frame;
        }
        // 递归子元素
        if (Array.isArray(layers[i].layers)) {
            layers[i].layers = _mask(layers[i].layers, { flag, frame });
        }
    }
    // 删除超出画板的图层
    layers = layers.filter((layer) => {
        if (layer.frame.width === 0 || layer.frame.height === 0) {
            return false;
        }
        return true;
    });
    return layers;
};
exports.default = (layers) => {
    return _mask(layers, { flag: true, frame: layers[0].frame });
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/filterGroupLayer.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/filterGroupLayer.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description 去掉分组，同时去掉图层层级
 * @param {SKLayer[]} layers
 * @param {SKLayer[]} [afterLayer=[]]
 * @returns {SKLayer[]}
 */
const filterGroupLayer = (layers, afterLayer = []) => {
    layers.forEach((layer) => {
        if (layer._class !== 'group') {
            afterLayer.push(Object.assign(Object.assign({}, layer), { layers: [] }));
        }
        if (Array.isArray(layer.layers)) {
            filterGroupLayer(layer.layers, afterLayer);
        }
    });
    return afterLayer;
};
exports.default = filterGroupLayer;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/index.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/index.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const parseText_1 = __webpack_require__(/*! ./parseText */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/index.js");
const parseStructure_1 = __webpack_require__(/*! ./parseStructure */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStructure/index.js");
const parseStyle_1 = __webpack_require__(/*! ./parseStyle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/index.js");
const parseImage_1 = __webpack_require__(/*! ./parseImage */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseImage.js");
const filterGroupLayer_1 = __webpack_require__(/*! ./filterGroupLayer */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/filterGroupLayer.js");
const _parseDSL = (sketchData) => {
    const dsl = [];
    sketchData.forEach((layer) => {
        let dslLayer = {
            type: 'Container',
            id: layer.do_objectID,
            name: layer.name
        };
        // 面板解析
        dslLayer.panel = layer.panel;
        // 结构解析
        dslLayer.structure = Object.assign(Object.assign({}, dslLayer.structure), parseStructure_1.default(layer));
        // 样式解析
        dslLayer.style = Object.assign(Object.assign({}, dslLayer.style), parseStyle_1.default(layer));
        // 文本处理
        dslLayer = parseText_1.default(dslLayer, layer);
        // 图片处理
        dslLayer = parseImage_1.default(dslLayer, layer);
        if (dslLayer.type !== 'Text' && Array.isArray(layer.layers)) {
            dslLayer.children = _parseDSL(layer.layers);
        }
        dsl.push(dslLayer);
    });
    return dsl;
};
exports.default = (sketchData) => {
    const layers = [];
    for (let i = 0; i < sketchData.length; i++) {
        let layer = sketchData[i];
        layer.layers = filterGroupLayer_1.default(layer.layers);
        layers.push(layer);
    }
    const dsl = _parseDSL(layers);
    return dsl;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseImage.js":
/*!******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseImage.js ***!
  \******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 切片(Slice) => 图片
 * @param image Picasso-DSL图层
 * @param layer Sketch图层
 */
const parseImage = (image, layer) => {
    // 画板图赋值
    if (layer._class === 'artboard') {
        image.value = layer.imageUrl;
        // 切片转换为图片
    }
    else if (layer.imageUrl) {
        image.type = 'Image';
        image.value = layer.imageUrl;
    }
    return image;
};
exports.default = parseImage;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStructure/index.js":
/*!****************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStructure/index.js ***!
  \****************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const parseBorder_1 = __webpack_require__(/*! ./parseBorder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStructure/parseBorder.js");
const utils_1 = __webpack_require__(/*! ../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
const parseStructure = (layer) => {
    const { x, y, height, width } = layer.frame;
    return {
        x: utils_1.precisionControl(x),
        y: utils_1.precisionControl(y),
        width: utils_1.precisionControl(width),
        height: utils_1.precisionControl(height),
        border: parseBorder_1.default(layer),
    };
};
exports.default = parseStructure;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStructure/parseBorder.js":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStructure/parseBorder.js ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(/*! ../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 * 'position': 属性表示 border 设置的位置
 * 1 => Inside border 位于盒子的内部
 * 0 => Center border 盒子便于位于 boder 之间
 * 2 =>  Outside 外边框
 */
exports.default = (layer) => {
    //没有处理多边框的情况，现在只支持单边框，其实borders是一个数组
    if (layer.style && layer.style.borders && layer.style.borders.length && layer._class != 'artboard') {
        let borderList = layer.style.borders.filter(item => item.isEnabled);
        if (borderList.length) {
            let borderStyle = borderList[0]; // 不规则 border 已经导出为图片
            let borderAlpha = borderStyle.color.alpha;
            // 只要判断是否存在即可， 因为可能 Opacity 的值为 0 的情况
            if (layer.style && layer.style.contextSettings) {
                borderAlpha = layer.style.contextSettings.opacity * borderAlpha;
            }
            // 设置边框
            const border = {
                width: utils_1.precisionControl(borderStyle.thickness),
                style: 'solid',
                color: {
                    red: utils_1.calculateRGB(borderStyle.color.red),
                    green: utils_1.calculateRGB(borderStyle.color.green),
                    blue: utils_1.calculateRGB(borderStyle.color.blue),
                    alpha: utils_1.precisionControl(borderAlpha, 0.1),
                },
            };
            return {
                left: border,
                top: border,
                right: border,
                bottom: border
            };
        }
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/index.js":
/*!************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/index.js ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const parseFill_1 = __webpack_require__(/*! ./parseFill */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/index.js");
const parseShadow_1 = __webpack_require__(/*! ./parseShadow */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseShadow.js");
const parseBorderRadius_1 = __webpack_require__(/*! ./parseBorderRadius */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseBorderRadius.js");
const parseBackGroundColor_1 = __webpack_require__(/*! ./parseBackGroundColor */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseBackGroundColor.js");
const parseStyle = (layer) => (Object.assign(Object.assign({}, parseShadow_1.default(layer)), { borderRadius: parseBorderRadius_1.default(layer), background: Object.assign(Object.assign({}, parseBackGroundColor_1.default(layer)), parseFill_1.default(layer)) }));
exports.default = parseStyle;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseBackGroundColor.js":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseBackGroundColor.js ***!
  \***************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(/*! ../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
exports.default = (layer) => {
    var _a;
    let { alpha, red, green, blue } = layer.backgroundColor || {};
    // 如果设置了 Opacity 属性，则 fills border 需要乘以这个数值
    if ((_a = layer.style) === null || _a === void 0 ? void 0 : _a.contextSettings) {
        alpha = layer.style.contextSettings.opacity * alpha;
    }
    if (alpha > 0) {
        return {
            color: {
                red: utils_1.calculateRGB(red),
                green: utils_1.calculateRGB(green),
                blue: utils_1.calculateRGB(blue),
                alpha: utils_1.precisionControl(alpha, 0.1),
            },
        };
    }
    return {};
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseBorderRadius.js":
/*!************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseBorderRadius.js ***!
  \************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(/*! ../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 * 计算圆角
 * @param {*} layer 图层
 *  pointRadiusBehaviour: 1 round Corners
 *  pointRadiusBehaviour: 2 smooth Corners
 */
const calculateBorderRadius = (layer) => {
    var _a;
    if (layer.points && layer.points.length !== 4) { // 不是 4 个锚点组成的不计算圆角
        return {};
    }
    // 如果 points 的模式是   curveMode: 1 的情况， 以四个角的角度作为圆角的大小
    if (layer.points && layer.points.length == 4 && layer.points[0].curveMode == 1 && layer.points[1].curveMode == 1 && layer.points[2].curveMode == 1 && layer.points[3].curveMode == 1 && layer.fixedRadius !== undefined) {
        const cornerRadiusList = [];
        for (let item of layer.points) {
            cornerRadiusList.push(item.cornerRadius);
        }
        const [topLeft, topRight, bottomRight, bottomLeft] = cornerRadiusList; // 上、右、下、左
        return {
            topLeft: utils_1.precisionControl(topLeft),
            topRight: utils_1.precisionControl(topRight),
            bottomRight: utils_1.precisionControl(bottomRight),
            bottomLeft: utils_1.precisionControl(bottomLeft)
        };
    }
    // 如果 points 的模式是 curveMode: 2 cornerRadius: 0 的情况，为正圆
    if (((_a = layer.points) === null || _a === void 0 ? void 0 : _a.length) === 4 && layer.points[0].curveMode === 2 && layer.points[1].curveMode === 2 && layer.points[2].curveMode === 2 && layer.points[3].curveMode === 2) {
        const cornerRadiusList = [];
        for (let item of layer.points) {
            cornerRadiusList.push(item.cornerRadius);
        }
        const [topLeft, topRight, bottomRight, bottomLeft] = cornerRadiusList; // 上、右、下、左
        if (topLeft === 0 && topRight === 0 && bottomRight === 0 && bottomLeft === 0) {
            return {
                topLeft: '50%',
                topRight: '50%',
                bottomRight: '50%',
                bottomLeft: '50%',
            };
        }
    }
    // 按照比例计算
    let radius;
    if (layer.layers && layer.layers.length && layer.layers[0].fixedRadius) {
        radius = layer.layers[0].fixedRadius > layer.frame.height / 2 ? layer.frame.height / 2 : layer.layers[0].fixedRadius;
    }
    else if (layer.fixedRadius) { //兼容52.2版本
        radius = layer.fixedRadius > layer.frame.height / 2 ? layer.frame.height / 2 : layer.fixedRadius;
    }
    return {
        topLeft: utils_1.precisionControl(radius),
        topRight: utils_1.precisionControl(radius),
        bottomRight: utils_1.precisionControl(radius),
        bottomLeft: utils_1.precisionControl(radius)
    };
};
exports.default = calculateBorderRadius;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/handleLinearGradient.js":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/handleLinearGradient.js ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const twoPointsAngle_1 = __webpack_require__(/*! ./twoPointsAngle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsAngle.js");
const twoPointsDistance_1 = __webpack_require__(/*! ./twoPointsDistance */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsDistance.js");
const utils_1 = __webpack_require__(/*! ../../../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
exports.default = (gradient, layer, contextSettings = 1) => {
    let frame = layer.frame;
    let changePointList = [];
    let startPointStr = gradient.from;
    let startX = +startPointStr.split('{')[1].split(',')[0] * frame.width;
    let startY = -startPointStr.split(',')[1].split('}')[0] * frame.height;
    let endPointStr = gradient.to;
    let endX = +endPointStr.split('{')[1].split(',')[0] * frame.width;
    let endY = -endPointStr.split(',')[1].split('}')[0] * frame.height;
    let gAngle = twoPointsAngle_1.default(startX, startY, endX, endY);
    let gDistance = twoPointsDistance_1.default(startX, startY, endX, endY);
    let startPoint = {
        x: startX,
        y: startY
    };
    let endPoint = {
        x: endX,
        y: endY
    };
    let stops = gradient.stops;
    if (endX < startX) {
        startPoint = {
            x: endX,
            y: endY
        };
        endPoint = {
            x: startX,
            y: startY
        };
        gAngle = twoPointsAngle_1.default(endX, endY, startX, startY);
        gDistance = twoPointsDistance_1.default(endX, endY, startX, startY);
        stops = stops.reverse();
        stops = stops.map(item => {
            item.position = 1 - item.position;
            return item;
        });
    }
    let point1 = {
        x: 0,
        y: 0
    };
    let point2 = {
        x: frame.width,
        y: 0
    };
    let point3 = {
        x: frame.width,
        y: -frame.height
    };
    let point4 = {
        x: 0,
        y: -frame.height
    };
    let mainStart = point1;
    let mainEnd = point3;
    //根据不同角度，选取起始点和终止点
    if (gAngle >= 0 && gAngle < Math.PI / 2) {
        mainStart = point4;
        mainEnd = point2;
    }
    else if (gAngle >= Math.PI / 2 && gAngle < Math.PI) {
        mainStart = point1;
        mainEnd = point3;
    }
    let lengthStart = 0;
    let lengthEnd = 0;
    let startColor = {};
    let endColor = {};
    //计算向量距离
    const verticalDistance = (point1, point2, lineAngle) => {
        return Math.abs(twoPointsDistance_1.default(point1.x, point1.y, point2.x, point2.y)) *
            Math.cos(twoPointsAngle_1.default(point1.x, point1.y, point2.x, point2.y) - lineAngle);
    };
    //起始点和起始坐标点之间的向量距离
    if (!(startPoint.x == mainStart.x && startPoint.y == mainStart.y)) {
        lengthStart = verticalDistance(mainStart, startPoint, gAngle);
    }
    //结束点和结束坐标点之间的向量距离
    if (!(endPoint.x == mainEnd.x && endPoint.y == mainEnd.y)) {
        lengthEnd = verticalDistance(endPoint, mainEnd, gAngle);
    }
    //渐变起始坐标处理(起始距离为正值和负值两种情况)
    if (lengthStart < 0) {
        for (let i = 1; i < stops.length; i++) {
            if (stops[i].position > -lengthStart / gDistance) {
                let currColor = stops[i].color;
                let preColor = stops[i - 1].color;
                const getVal = (prop) => {
                    return preColor[prop] + (currColor[prop] - preColor[prop]) / (stops[i].position - stops[i - 1].position) * (-lengthStart / gDistance - stops[i - 1].position);
                };
                startColor = {
                    index: i,
                    color: {
                        'alpha': getVal('alpha'),
                        'blue': getVal('blue'),
                        'green': getVal('green'),
                        'red': getVal('red')
                    },
                    position: -lengthStart / gDistance
                };
                break;
            }
        }
    }
    else {
        startColor = {
            index: 0,
            color: stops[0].color,
            position: -lengthStart / gDistance
        };
    }
    //渐变结束坐标处理(结束距离为正值和负值两种情况)
    if (lengthEnd < 0) {
        for (let i = 0; i < stops.length - 1; i++) {
            if (stops[i + 1].position > 1 + lengthEnd / gDistance) {
                let currColor = stops[i].color;
                let nextColor = stops[i + 1].color;
                const getVal = (prop) => {
                    return currColor[prop] + (nextColor[prop] - currColor[prop]) / (stops[i + 1].position - stops[i].position) * (1 + lengthEnd / gDistance - stops[i].position);
                };
                endColor = {
                    index: i,
                    color: {
                        'alpha': getVal('alpha'),
                        'blue': getVal('blue'),
                        'green': getVal('green'),
                        'red': getVal('red')
                    },
                    position: 1 + lengthEnd / gDistance
                };
                break;
            }
        }
    }
    else {
        endColor = {
            index: stops.length - 1,
            color: stops[stops.length - 1].color,
            position: 1 + lengthEnd / gDistance
        };
    }
    if (startColor.color) {
        changePointList.push(startColor);
    }
    for (let n = 0; n < stops.length; n++) {
        if (n >= startColor.index && n <= endColor.index) {
            changePointList.push(stops[n]);
        }
    }
    if (endColor.color) {
        changePointList.push(endColor);
    }
    changePointList = changePointList.map(({ color, position }) => {
        position = (position - changePointList[0].position) / (changePointList[changePointList.length - 1].position - changePointList[0].position);
        return {
            color,
            position
        };
    });
    const valList = changePointList.map(({ color, position }) => {
        let { red, green, blue, alpha } = color;
        if (layer.style && layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * contextSettings * alpha;
        }
        return {
            color: {
                red: utils_1.calculateRGB(red),
                green: utils_1.calculateRGB(green),
                blue: utils_1.calculateRGB(blue),
                alpha: utils_1.precisionControl(alpha, 0.1)
            },
            position: utils_1.precisionControl(position, 0.01),
        };
        // return `rgba(${Math.round(red * 255)},${Math.round(green * 255)},${Math.round(blue * 255)},${Math.round(alpha * 100) / 100}) ${Math.round(position * 10000) / 100}%`;
    });
    return {
        gAngle: Math.round(gAngle / Math.PI * 180 * 10) / 10,
        gList: valList,
    };
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/handleRadialGradient.js":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/handleRadialGradient.js ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const twoPointsDistance_1 = __webpack_require__(/*! ./twoPointsDistance */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsDistance.js");
const utils_1 = __webpack_require__(/*! ../../../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
exports.default = (gradient, layer, fillStyle, contextSettings = 1) => {
    let frame = layer.frame;
    let startPointStr = gradient.from;
    let startX = +startPointStr.split('{')[1].split(',')[0] * frame.width;
    let startY = -startPointStr.split(',')[1].split('}')[0] * frame.height;
    let endPointStr = gradient.to;
    let endX = +endPointStr.split('{')[1].split(',')[0] * frame.width;
    let endY = -endPointStr.split(',')[1].split('}')[0] * frame.height;
    let r = Math.abs(twoPointsDistance_1.default(startX, startY, endX, endY));
    let stops = gradient.stops;
    const valList = stops.map(({ color, position }) => {
        let { red, green, blue, alpha } = color;
        if (layer.style && layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * contextSettings * alpha;
        }
        return {
            color: {
                red: utils_1.calculateRGB(red),
                green: utils_1.calculateRGB(green),
                blue: utils_1.calculateRGB(blue),
                alpha: utils_1.precisionControl(alpha, 0.1)
            },
            position: utils_1.precisionControl(position, 0.01),
        };
    });
    if (fillStyle.gradient.elipseLength > 0) { //椭圆渐变
        let elipseLength = fillStyle.gradient.elipseLength;
        if (Math.abs(endY - startY) < 1) {
            return {
                smallRadius: utils_1.precisionControl(r),
                largeRadius: utils_1.precisionControl(elipseLength * r),
                position: {
                    left: utils_1.precisionControl(startX),
                    top: utils_1.precisionControl(-startY),
                },
                gList: valList
            };
        }
        else if (Math.abs(endX - startX) < 1) {
            return {
                smallRadius: utils_1.precisionControl(elipseLength * r),
                largeRadius: utils_1.precisionControl(r),
                position: {
                    left: utils_1.precisionControl(startX),
                    top: utils_1.precisionControl(-startY),
                },
                gList: valList
            };
        }
    }
    else { //圆形渐变
        return {
            smallRadius: utils_1.precisionControl(r),
            largeRadius: utils_1.precisionControl(r),
            position: {
                left: utils_1.precisionControl(startX),
                top: utils_1.precisionControl(-startY),
            },
            gList: valList
        };
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/index.js":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/index.js ***!
  \**********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleLinearGradient_1 = __webpack_require__(/*! ./handleLinearGradient */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/handleLinearGradient.js");
const handleRadialGradient_1 = __webpack_require__(/*! ./handleRadialGradient */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/handleRadialGradient.js");
exports.default = (fillStyle, layer) => {
    if (!fillStyle.gradient) {
        return {};
    }
    let gradient = fillStyle.gradient;
    let contextSettings = fillStyle.contextSettings ? fillStyle.contextSettings.opacity : 1;
    let gradientType = gradient.gradientType;
    if (gradientType === 0) { // 线性渐变
        return {
            linearGradient: handleLinearGradient_1.default(gradient, layer, contextSettings)
        };
    }
    if (gradientType === 1) { // 径向渐变
        return {
            radialGradient: handleRadialGradient_1.default(gradient, layer, fillStyle, contextSettings)
        };
    }
    if (gradientType === 2) { // 环形渐色，导出该图层为图片
        return {};
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsAngle.js":
/*!*******************************************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsAngle.js ***!
  \*******************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 依据两点坐标计算两点与原点之间连线的夹角
 *
 * @param {*} startX 第一个点X轴坐标
 * @param {*} startY 第一个点Y轴坐标
 * @param {*} endX 第二个点X轴坐标
 * @param {*} endY 第二个点Y轴坐标
 * @returns
 */
exports.default = (startX, startY, endX, endY) => {
    let x = endX - startX;
    let y = endY - startY;
    if (x > 0 && y == 0) {
        return Math.PI * 0.5;
    }
    if (x < 0 && y == 0) {
        return Math.PI * 1.5;
    }
    if (y > 0 && x == 0) {
        return 0;
    }
    if (y < 0 && x == 0) {
        return Math.PI;
    }
    if (x >= 0 && y >= 0) {
        return Math.atan(x / y);
    }
    if (x >= 0 && y < 0) {
        return Math.PI + Math.atan(x / y);
    }
    if (x < 0 && y > 0) {
        return 2 * Math.PI + Math.atan(x / y);
    }
    if (x < 0 && y <= 0) {
        return Math.PI + Math.atan(x / y);
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsDistance.js":
/*!**********************************************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/twoPointsDistance.js ***!
  \**********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 计算两点之间的距离
 * 根据X轴方向判断正负
 *
 * @param {*} startX
 * @param {*} startY
 * @param {*} endX
 * @param {*} endY
 * @returns
 */
exports.default = (startX, startY, endX, endY) => {
    let x = endX - startX;
    let y = endY - startY;
    if (x >= 0) {
        return Math.sqrt(x * x + y * y);
    }
    else {
        return -Math.sqrt(x * x + y * y);
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleImgFill.js":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleImgFill.js ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * fillStyle.patternFillType == 0   Mask_Tile repeat 平铺
 * fillStyle.patternFillType == 1  Mask_Fill  cover  填充
 * fillStyle.patternFillType == 2  Mask_Stretch  100% 100% 拉伸
 * fillStyle.patternFillType == 3   Mask_Fit  contain 包含
 */
exports.default = (fillStyle, layer) => {
    const background = {};
    if (!fillStyle.image) {
        return;
    }
    if (fillStyle.patternFillType == 0) {
        background.repeat = 'repeat';
    }
    if (fillStyle.patternFillType == 1) {
        background.repeat = 'no-repeat';
        background.position = {
            left: 'center',
            top: 'center'
        };
        background.size = 'cover';
    }
    if (fillStyle.patternFillType == 2) {
        background.repeat = 'no-repeat';
        background.position = {
            left: 'center',
            top: 'center'
        };
        background.size = {
            width: '100%',
            height: '100%',
        };
    }
    if (fillStyle.patternFillType == 3) {
        background.repeat = 'no-repeat';
        background.position = {
            left: 'center',
            top: 'center'
        };
        background.size = 'contain';
    }
    // TODO
    // if (layer.realFrame) {
    //     const realFrame = JSON.parse(JSON.stringify(layer.realFrame));
    //     layer.maskStyle['background-position'] = `${realFrame.x - layer.frame.x}px ${realFrame.y - layer.frame.y}px`;
    //     layer.maskStyle['background-size'] = `${realFrame.width}px ${realFrame.height}px`;
    //     layer.maskStyle['background-repeat'] = 'no-repeat';
    // }
    let imgPath = fillStyle.image._ref.slice(fillStyle.image._ref.lastIndexOf('/') + 1);
    if (!/.(png|pdf)$/.test(imgPath)) {
        imgPath = imgPath + '.png';
    }
    background.image = {
        url: imgPath
    };
    //图片类型，背景色去掉
    // TODO
    // delete record.style['background-color'];
    return background;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleSolidColorFill.js":
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleSolidColorFill.js ***!
  \*************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(/*! ../../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
exports.default = (fillStyle, layer) => {
    let { alpha, red, green, blue } = fillStyle.color;
    // 如果设置了 Opacity 属性，则 fills border 需要乘于这个数值
    if (layer.style && layer.style.contextSettings) {
        alpha = layer.style.contextSettings.opacity * alpha;
    }
    if (alpha > 0) {
        return {
            color: {
                red: utils_1.calculateRGB(red),
                green: utils_1.calculateRGB(green),
                blue: utils_1.calculateRGB(blue),
                alpha: utils_1.precisionControl(alpha, 0.1),
            }
        };
    }
    return {};
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/index.js":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/index.js ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleSolidColorFill_1 = __webpack_require__(/*! ./handleSolidColorFill */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleSolidColorFill.js");
const handleGradientColorFill_1 = __webpack_require__(/*! ./handleGradientColorFill */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleGradientColorFill/index.js");
const handleImgFill_1 = __webpack_require__(/*! ./handleImgFill */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleImgFill.js");
/**
  * 处理填充
  * 填充类型
  * fillStyle.fillType
  *           0  纯色
  *           1  渐变色
  *           2
  *           3
  *           4  填充图
  *           5  纹理效果
  * fillStyle.fillType fillStyle.gradient.gradientType
  *        1                    0   线性渐变色 完全css解析
  *        1                    1   径向渐变色
  *                                 - 圆形或者椭圆但是没有斜角度的CSS解析
  *                                 - 导出为图片
  *        1                    2   环形渐变色  css实验属性暂时不支持 ，导出为图片处理
  *
  * @param {Object} layer 图层
  */
exports.default = (layer) => {
    let fillList = [];
    // 过滤无效填充
    if (layer.style && Array.isArray(layer.style.fills)) {
        fillList = layer.style.fills.filter(fillItem => {
            return fillItem.isEnabled;
        });
    }
    if (fillList.length === 0 || layer._class === 'text') {
        return {};
    }
    // 只解析单层渐变
    const fillStyle = fillList[fillList.length - 1];
    const fillType = fillStyle.fillType;
    //填充为纯色的情况
    if (fillType == 0) {
        return handleSolidColorFill_1.default(fillStyle, layer);
    }
    //填充为渐变色的情况
    if (fillType == 1) {
        return handleGradientColorFill_1.default(fillStyle, layer);
    }
    //填充图片
    if (fillType == 4) {
        return handleImgFill_1.default(fillStyle, layer);
    }
    return {};
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseShadow.js":
/*!******************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseShadow.js ***!
  \******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(/*! ../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 *  处理阴影
 *  box-shadow 只解析一层的情况
 *  多个 shadow 的情况将导成图片, 每一层的 shadow 的模式都是 blendMode： 0 表示是正常的
 */
const getShadowStyle = (shadow, layer, type = '') => {
    let { alpha, red, green, blue } = shadow.color;
    alpha = shadow.contextSettings.opacity * alpha;
    const offY = !layer.hasScale && layer.isFlippedVertical ? -shadow.offsetY : shadow.offsetY;
    const offX = !layer.hasScale && layer.isFlippedHorizontal ? -shadow.offsetX : shadow.offsetX;
    return {
        type,
        blurRadius: utils_1.precisionControl(shadow.blurRadius),
        spread: utils_1.precisionControl(shadow.spread),
        offsetX: utils_1.precisionControl(offX),
        offsetY: utils_1.precisionControl(offY),
        color: {
            red: utils_1.calculateRGB(red),
            green: utils_1.calculateRGB(green),
            blue: utils_1.calculateRGB(blue),
            alpha: utils_1.precisionControl(alpha, 0.1),
        },
    };
};
// 获取文本的 shadow 样式
const getTextShadowStyle = (shadow, layer) => {
    let { alpha, red, green, blue } = shadow.color;
    alpha = shadow.contextSettings.opacity * alpha;
    let offY = !layer.hasScale && layer.isFlippedVertical ? -shadow.offsetY : shadow.offsetY;
    let offX = !layer.hasScale && layer.isFlippedHorizontal ? -shadow.offsetX : shadow.offsetX;
    return {
        blurRadius: utils_1.precisionControl(shadow.blurRadius),
        spread: utils_1.precisionControl(shadow.spread),
        offsetX: utils_1.precisionControl(offX),
        offsetY: utils_1.precisionControl(offY),
        color: {
            red: utils_1.calculateRGB(red),
            green: utils_1.calculateRGB(green),
            blue: utils_1.calculateRGB(blue),
            alpha: utils_1.precisionControl(alpha, 0.1),
        }
    };
};
exports.default = (layer) => {
    if (layer._class === 'text') {
        let shadowStyleList = [];
        // 处理文本外阴影
        if (layer.style && layer.style.shadows) {
            // 查找所有可用的阴影
            let shadowList = [];
            layer.style.shadows.map(item => {
                if (item.isEnabled) {
                    shadowList.push(item);
                }
            });
            for (let item of shadowList) {
                let proStyle = getTextShadowStyle(item, layer);
                shadowStyleList.push(proStyle);
            }
            return {
                textShadow: shadowStyleList
            };
        }
    }
    else {
        // 盒子阴影的设置
        let shadowStyleList = [], innerShadowStyleList = [];
        if (layer.style && layer.style.shadows) {
            // 查找所有可用的阴影
            let shadowList = [];
            layer.style.shadows.map(item => {
                if (item.isEnabled) {
                    shadowList.push(item);
                }
            });
            for (let item of shadowList) {
                let proStyle = getShadowStyle(item, layer);
                shadowStyleList.push(proStyle);
            }
        }
        if (layer.style && layer.style.innerShadows) {
            let innerShadowList = [];
            layer.style.innerShadows.map(item => {
                if (item.isEnabled) {
                    innerShadowList.push(item);
                }
            });
            for (let item of innerShadowList) {
                let proStyle = getShadowStyle(item, layer, 'inset');
                innerShadowStyleList.push(proStyle);
            }
        }
        return {
            boxShadow: [...shadowStyleList.reverse(), ...innerShadowStyleList.reverse()]
        };
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealColor.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealColor.js ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(/*! ../../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
const handleSolidColorFill_1 = __webpack_require__(/*! ../parseStyle/parseFill/handleSolidColorFill */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseStyle/parseFill/handleSolidColorFill.js");
exports.default = (color, layer) => {
    //01. 如果文本有填充的时候，使用填充色
    let fillList = [];
    // 过滤无效填充
    if (layer.style && Array.isArray(layer.style.fills)) {
        fillList = layer.style.fills.filter(fillItem => {
            return fillItem.isEnabled;
        });
    }
    if (fillList.length > 0) {
        // 只解析单层渐变
        const fillStyle = fillList[fillList.length - 1];
        const fillType = fillStyle.fillType;
        //填充为纯色的情况
        if (fillType === 0) {
            return handleSolidColorFill_1.default(fillStyle, layer);
        }
    }
    //02. 没有填充的时候，使用默认颜色
    let alpha = color.alpha;
    if (layer.style && layer.style.contextSettings) { // colorStyle 里的 alpha 的值都是 1
        alpha = layer.style.contextSettings.opacity * color.alpha; // 设置透明度
    }
    return {
        color: {
            alpha: utils_1.precisionControl(alpha, 0.1),
            red: utils_1.calculateRGB(color.red),
            green: utils_1.calculateRGB(color.green),
            blue: utils_1.calculateRGB(color.blue),
        }
    };
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealFont.js":
/*!**************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealFont.js ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 获取字体大小, 文字字体, 字体粗细
 */
const getFontWeight_1 = __webpack_require__(/*! ./getFontWeight */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getFontWeight.js");
exports.default = (fontStyle, size = 1) => {
    var _a, _b, _c;
    return ({
        fontSize: ((_a = fontStyle.attributes) === null || _a === void 0 ? void 0 : _a.size) * size,
        fontFamily: (_b = fontStyle.attributes) === null || _b === void 0 ? void 0 : _b.name,
        fontWeight: getFontWeight_1.default((_c = fontStyle.attributes) === null || _c === void 0 ? void 0 : _c.name)
    });
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealLetterSpacing.js":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealLetterSpacing.js ***!
  \***********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理字间距
 */
exports.default = (kerning) => {
    if (kerning !== undefined && kerning !== 0) {
        return {
            letterSpacing: Math.round(kerning * 10) / 10
        };
    }
    return {};
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealParagraph.js":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealParagraph.js ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const const_1 = __webpack_require__(/*! ../../common/const */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/const.js");
/**
 * 处理段落
 */
exports.default = (paragraphStyle, fontStyle, size = 1) => {
    var _a;
    const textStyle = {};
    if (paragraphStyle) {
        switch (paragraphStyle.alignment) {
            case 2:
                textStyle.textAlign = 'center';
                break;
            case 1:
                textStyle.textAlign = 'right';
                break;
            case 0:
                textStyle.textAlign = 'left';
                break;
            case 3: //两边对齐
                textStyle.textAlign = 'justify';
                break;
        }
        textStyle.lineHeight = paragraphStyle.maximumLineHeight ? paragraphStyle.maximumLineHeight : const_1.fontSizeLineHeightMap[((_a = fontStyle.attributes) === null || _a === void 0 ? void 0 : _a.size) * size];
    }
    return textStyle;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealTextDecorate.js":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealTextDecorate.js ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理文字转换问题
 */
exports.default = (attributes) => {
    const textStyle = {};
    // 文字大小写转换
    if (attributes.MSAttributedStringTextTransformAttribute == 1) {
        textStyle.textTransform = 'uppercase';
    }
    else if (attributes.MSAttributedStringTextTransformAttribute == 2) {
        textStyle.textTransform = 'lowercase';
    }
    if (attributes.underlineStyle == 1) {
        textStyle.textDecoration = 'underline';
    }
    if (attributes.strikethroughStyle == 1) {
        textStyle.textDecoration = 'line-through';
    }
    return textStyle;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getFontWeight.js":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getFontWeight.js ***!
  \*******************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (attrName) => {
    if (/black|heavy/i.test(attrName)) {
        return 900;
    }
    else if (/ultrabold|extrabold/i.test(attrName)) {
        return 800;
    }
    else if (/bold|boldmt|psboldmt/i.test(attrName)) {
        return 700;
    }
    else if (/semibold|demibold/i.test(attrName)) {
        return 600;
    }
    else if (/medium/i.test(attrName)) {
        return 500;
    }
    else if (/roman|regular|normal|book/i.test(attrName)) {
        return 400;
    }
    else if (/light/i.test(attrName)) {
        return 300;
    }
    else if (/extralight|ultralight/i.test(attrName)) {
        return 200;
    }
    else if (/thin/i.test(attrName)) {
        return 100;
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getString.js":
/*!***************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getString.js ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (layer) => {
    // 直接可以获取string值
    if (layer.attributedString &&
        layer.attributedString.string) {
        return layer.attributedString.string;
    }
    return '';
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getStringStyle.js":
/*!********************************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getStringStyle.js ***!
  \********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const dealParagraph_1 = __webpack_require__(/*! ./dealParagraph */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealParagraph.js");
const dealColor_1 = __webpack_require__(/*! ./dealColor */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealColor.js");
const dealFont_1 = __webpack_require__(/*! ./dealFont */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealFont.js");
const dealLetterSpacing_1 = __webpack_require__(/*! ./dealLetterSpacing */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealLetterSpacing.js");
const dealTextDecorate_1 = __webpack_require__(/*! ./dealTextDecorate */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/dealTextDecorate.js");
exports.default = (layer) => {
    // 直接解析text字体样式有字体大小的情况下
    if (layer.attributedString && layer.attributedString.string && layer.attributedString.attributes) {
        let size = 1;
        // TODO
        // if (layer.frame.sizeY) {
        //     size = layer.frame.sizeY;
        // }
        let attrList = layer.attributedString.attributes;
        let strStyleList = [];
        let minFontSize = 0;
        for (let attrItem of attrList) {
            if (attrItem._class == 'stringAttribute') {
                let attributes = attrItem.attributes;
                let fontStyle = attributes['MSAttributedStringFontAttribute'];
                let colorStyle = attributes['MSAttributedStringColorAttribute'];
                let paragraphStyleObj = attributes['paragraphStyle'];
                let kerning = attributes['kerning'];
                const textStyle = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, dealParagraph_1.default(paragraphStyleObj, fontStyle, size)), dealColor_1.default(colorStyle, layer)), dealFont_1.default(fontStyle, size)), dealLetterSpacing_1.default(kerning)), dealTextDecorate_1.default(attributes));
                if (minFontSize > textStyle.fontSize) {
                    minFontSize = textStyle.fontSize;
                }
            }
        }
        let isTextBreak = false;
        if (minFontSize && minFontSize > 0.5 * layer.frame.height) {
            // 单行文字的情况
            isTextBreak = true;
            // TODO
            // layer.istransformContain = true;
        }
        // attrList = isTextBreak ? attrList : attrList.slice(0, 1);
        for (let attrItem of attrList) {
            if (attrItem._class == 'stringAttribute') {
                let attributes = attrItem.attributes;
                let fontStyle = attributes['MSAttributedStringFontAttribute'];
                let colorStyle = attributes['MSAttributedStringColorAttribute'];
                let paragraphStyleObj = attributes['paragraphStyle'];
                let kerning = attributes['kerning'];
                const style = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ pos: [attrItem.location, attrItem.length] }, dealParagraph_1.default(paragraphStyleObj, fontStyle, size)), dealColor_1.default(colorStyle, layer)), dealFont_1.default(fontStyle, size)), dealLetterSpacing_1.default(kerning)), dealTextDecorate_1.default(attributes));
                strStyleList.push(style);
            }
        }
        return strStyleList;
    }
    return [];
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/index.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/index.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const getString_1 = __webpack_require__(/*! ./getString */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getString.js");
const getStringStyle_1 = __webpack_require__(/*! ./getStringStyle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parseDSL/parseText/getStringStyle.js");
exports.default = (text, layer) => {
    if (layer._class !== 'text') {
        return text;
    }
    // 设置类型
    text.type = 'Text';
    if (!text.style.textStyle) {
        text.style.textStyle = {};
    }
    text.value = getString_1.default(layer);
    let strStyleList = getStringStyle_1.default(layer);
    if (Array.isArray(strStyleList) && strStyleList.length > 0) {
        if (strStyleList[0].paragraphSpacing) {
            text.style.textStyle.paragraphSpacing = strStyleList[0].paragraphSpacing;
        }
        for (let i = 0; i < strStyleList.length; i++) {
            delete strStyleList[i].paragraphSpacing;
        }
    }
    // 默认取第一个文本样式
    const style = getStringStyle_1.default(layer)[0];
    if (style.pos) {
        delete style.pos;
    }
    text.style.textStyle = style;
    // 多段文本处理
    if (Array.isArray(strStyleList) && strStyleList.length > 1) {
        // TODO
        // if (!text.textStyle['lineHeight'] && text.textStyle['fontSize'] &&
        //     +text.textStyle['fontSize'] > text.height * 0.5
        // ) {
        //     text.textStyle['line-height'] = text.height;
        // }
        // text.style = {
        //     ...text.style,
        //     ...JSON.parse(JSON.stringify(text.textStyle))
        // };
        // text.type = 'Text';
        // Todo
        // if (/[a-zA-Z]+/.test(text.value) && text.style.textStyle.fontSize <= +text.structure.height * 0.5) { // 包含英文单词需要换行处理
        //     text.style.textStyle.wordBreak = 'break-all'
        // }
        // } else {
        // 处理一串字符多个样式的情况
        // TODO
        // if (layer.istransformContain) {
        //     text.istransformContain = true;
        // }
        // text.children = [];
        // text.textContainer = true;
        // if (!text.style) {
        //     text.style = {}
        // }
        // 存储多行文本。
        text.children = [];
        for (let i = 0; i < strStyleList.length; i++) {
            let strStyle = strStyleList[i];
            let tempObj = {
                type: 'Text',
                value: '',
                style: {
                    textStyle: {
                        lineHeight: +text.structure.height
                    }
                },
                structure: {
                    height: text.structure.height,
                    y: text.structure.y,
                }
                // parentId: layer.do_objectID,
            };
            if (i == 0) { // 第一个元素继承父元素的左偏移量
                tempObj.structure.x = text.structure.x;
                //todo ?
                // if (strStyle['font-size'] && 0.5 * text.structure.height < strStyle['font-size']) {
                //     text.style.display = 'flex';
                // }
            }
            for (let key in strStyle) {
                if (key === 'pos') {
                    let [location, length] = strStyle[key];
                    // 标注模式
                    tempObj.value = text.value.substr(location, length);
                    // 代码模式
                    // tempObj.value = text.value.substr(location, length).replace(/ | /g, '&nbsp;');
                    // if (i == strStyleList.length - 1) {
                    //     tempObj.value = tempObj.value.replace(/(&nbsp;)+$/, '');
                    // }
                    // TODO
                    // if (tempObj.value && /[a-zA-Z]+/.test(tempObj.value)) { // 包含英文单词需要换行处理
                    //     tempObj.style.textStyle.wordBreak = 'break-all';
                    // }
                    delete strStyle.pos;
                }
                else {
                    tempObj.style.textStyle[key] = strStyle[key];
                }
            }
            text.children.push(tempObj);
        }
    }
    return text;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/index.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/index.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parsePanel = void 0;
const parseProperty_1 = __webpack_require__(/*! ./parseProperty */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseProperty.js");
const parseFill_1 = __webpack_require__(/*! ./parseFill */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseFill.js");
const parseTypeFace_1 = __webpack_require__(/*! ./parseTypeFace */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseTypeFace.js");
const parseBorder_1 = __webpack_require__(/*! ./parseBorder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseBorder.js");
const parseShadow_1 = __webpack_require__(/*! ./parseShadow */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseShadow.js");
exports.parsePanel = (layer) => {
    return {
        properties: parseProperty_1.parseProperty(layer),
        fills: parseFill_1.parseFill(layer),
        typefaces: parseTypeFace_1.parseTypeFace(layer),
        borders: parseBorder_1.parseBorder(layer),
        shadows: parseShadow_1.parseShadow(layer),
        code: '',
    };
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseBorder.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseBorder.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseBorder = void 0;
const utils_1 = __webpack_require__(/*! ../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 * 边框解析
 * 1. 对纯色填充、渐变填充进行了解析。
 * 2. TODO 图片填充及其他填充未进行解析。
 *
 * @param layer
 */
exports.parseBorder = (layer) => {
    const { borders = [] } = layer.style;
    return borders.filter(({ isEnabled, fillType }) => isEnabled && ([0, 1].includes(fillType))) // 过滤出纯色、渐变切可用的填充边框才解析
        .map(({ position, thickness, color, fillType, gradient }) => {
        let fill;
        // 纯色填充
        if (fillType === 0) {
            fill = {
                type: 0,
                color: utils_1.transSketchColor(color)
            };
            // 渐变填充
        }
        else if (fillType === 1 && [0, 1, 2].includes(gradient.gradientType)) {
            fill = {
                type: gradient.gradientType + 1,
                stops: gradient.stops.map(({ position, color }) => ({
                    position,
                    color: utils_1.transSketchColor(color),
                }))
            };
        }
        return {
            position: +position,
            thickness,
            fill
        };
    });
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseFill.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseFill.js ***!
  \*******************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseFill = void 0;
const utils_1 = __webpack_require__(/*! ../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 * 填充解析
 * 1. 对纯色填充、渐变填充进行了解析。
 * 2. TODO 图片填充及其他填充未进行解析。
 *
 * @param layer
 */
exports.parseFill = (layer) => {
    const { fills = [] } = layer.style;
    return fills.filter(({ isEnabled, fillType }) => isEnabled && ([0, 1].includes(fillType))) // 过滤出纯色、渐变切可用的填充
        .map(({ fillType, color, gradient }) => {
        // 纯色填充
        if (fillType === 0) {
            return {
                type: 0,
                color: utils_1.transSketchColor(color)
            };
        }
        // 渐变填充
        if (fillType === 1 && [0, 1, 2].includes(gradient.gradientType)) {
            return {
                type: gradient.gradientType + 1,
                stops: gradient.stops.map(({ position, color }) => ({
                    position,
                    color: utils_1.transSketchColor(color),
                }))
            };
        }
    });
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseProperty.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseProperty.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseProperty = void 0;
const utils_1 = __webpack_require__(/*! ../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 * 基础属性解析
 * @param layer
 */
exports.parseProperty = (layer) => {
    var _a;
    const { frame, name, style, fixedRadius } = layer;
    return {
        name,
        position: {
            x: frame.x,
            y: frame.y,
        },
        size: {
            width: frame.width,
            height: frame.height,
        },
        opacity: utils_1.precisionControl((_a = style.contextSettings) === null || _a === void 0 ? void 0 : _a.opacity, 0.01),
        radius: fixedRadius,
    };
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseShadow.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseShadow.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseShadow = void 0;
const utils_1 = __webpack_require__(/*! ../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
/**
 * 边框解析
 * 1. 对纯色填充、渐变填充进行了解析。
 * 2. TODO 图片填充及其他填充未进行解析。
 *
 * @param layer
 */
exports.parseShadow = (layer) => {
    const { shadows = [], innerShadows = [] } = layer.style;
    return [...shadows, ...innerShadows].filter(({ isEnabled }) => isEnabled) // 过滤出可用的阴影
        .map(({ offsetX, offsetY, blurRadius, spread, color, _class }) => ({
        type: _class === 'innerShadow' ? 0 : 1,
        offsetX,
        offsetY,
        blurRadius,
        spread,
        color: utils_1.transSketchColor(color)
    }));
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseTypeFace.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/parsePanel/parseTypeFace.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTypeFace = void 0;
const utils_1 = __webpack_require__(/*! ../common/utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/utils.js");
const const_1 = __webpack_require__(/*! ../common/const */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/common/const.js");
/**
 * 基础属性解析
 * @param layer
 */
exports.parseTypeFace = (layer) => {
    const { attributedString, style } = layer;
    if (!attributedString) {
        return [];
    }
    const { string: textContent, // 文本内容
    attributes // 分段样式
     } = attributedString;
    // 分段处理
    const typefaces = attributes.map(({ location, length, attributes }) => {
        var _a, _b, _c, _d, _e, _f, _g;
        const { name: fontFamily, // 获取字体类型
        size: fontSize, } = (_a = attributes.MSAttributedStringFontAttribute) === null || _a === void 0 ? void 0 : _a.attributes;
        // 获取字体重量, 默认 Regular;
        const val = fontFamily.split('-').pop();
        const fontWeight = fontFamily.split('-').length >= 2 && const_1.fontWeightTypes.includes(val.toLowerCase()) ? val : '';
        // 获取字体颜色
        const { red, green, blue, alpha } = attributes.MSAttributedStringColorAttribute;
        const color = utils_1.transSketchColor({ red, green, blue, alpha });
        // 获取字间距
        const letterSpacing = attributes.kerning || 0;
        /**
         * 获取行间距
         * 1. maximumLineHeight存在，则取maximumLineHeight值
         * 2. maximumLineHeight不存在，则根据字体映射出对应的默认行高
         */
        const lineHeight = ((_b = attributes.paragraphStyle) === null || _b === void 0 ? void 0 : _b.maximumLineHeight) ? (_c = attributes.paragraphStyle) === null || _c === void 0 ? void 0 : _c.maximumLineHeight : const_1.fontSizeLineHeightMap[fontSize];
        // 获取段间距
        const paragraphSpacing = ((_d = attributes.paragraphStyle) === null || _d === void 0 ? void 0 : _d.paragraphSpacing) || 0;
        /**
         * 获取字体水平居中方式
         * 0 水平左对齐
         * 1 水平居中对齐
         * 2 水平右对齐
         * 3 水平两端对齐
         */
        const alignment = ((_e = attributes.paragraphStyle) === null || _e === void 0 ? void 0 : _e.alignment) !== undefined ? +((_f = attributes.paragraphStyle) === null || _f === void 0 ? void 0 : _f.alignment) : 0;
        /**
         * 获取字体垂直居中方式
         * 0 垂直顶部对齐
         * 1 垂直居中对齐
         * 2 垂直底部对齐
         */
        const verticalAlignment = +((_g = style.textStyle) === null || _g === void 0 ? void 0 : _g.verticalAlignment);
        // 获取该段文本内容
        const content = textContent.substr(location, length);
        return {
            fontFamily,
            fontWeight,
            alignment,
            verticalAlignment,
            color,
            fontSize,
            letterSpacing,
            lineHeight,
            paragraphSpacing,
            content
        };
    });
    return typefaces;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/codeTrans.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/codeTrans.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeCodeTrans = exports.decodeMeatureTrans = exports.encodeTrans = void 0;
/**
 * Base64 加密、解密算法封装：
 */
function Base64() {
    // private property
    let _keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    // private method for UTF-8 encoding
    function _utf8_encode(string) {
        string = string.replace(/\r\n/g, '\n');
        let utftext = '';
        for (let n = 0; n < string.length; n++) {
            let c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
        }
        return utftext;
    }
    // private method for UTF-8 decoding
    function _utf8_decode(utftext) {
        let string = '';
        let i = 0;
        let c2, c1, c3;
        let c = c1 = c2 = 0;
        while (i < utftext.length) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
    // public method for encoding
    this.encode = function (input) {
        let output = '';
        let chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        let i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            }
            else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
                _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
                _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    };
    // public method for decoding
    this.decode = function (input) {
        let output = '';
        let chr1, chr2, chr3;
        let enc1, enc2, enc3, enc4;
        let i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, '');
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    };
}
const base64Instance = new Base64();
// 编码
exports.encodeTrans = base64Instance.encode;
// 解码标注数据
exports.decodeMeatureTrans = (data) => {
    try {
        // base64解码
        let dsl = base64Instance.decode(data);
        dsl = dsl ? JSON.parse(dsl) : [];
        // 数据结构调整
        return [Object.assign(Object.assign({}, dsl), { children: [] }), ...(Array.isArray(dsl.children) ? dsl.children : [])];
    }
    catch (error) {
        console.log(error);
        return [];
    }
};
// 解码代码数据
exports.decodeCodeTrans = (data) => {
    // base64解码
    let dsl = base64Instance.decode(data);
    dsl = dsl ? JSON.parse(dsl) : dsl;
    // 数据结构调整
    return dsl;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/colorTrans.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/colorTrans.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.colorTrans = exports.color2HSLA = exports.color2RGBA = exports.color2HEXA = exports.color2AHEX = exports.color2HEX = void 0;
/**
 * Color => HEX
 * @param color
 */
exports.color2HEX = (color) => {
    const { red, green, blue, alpha } = color;
    const hex = "#" + ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1);
    return {
        hex: hex.toUpperCase(),
        alpha: `${Math.round(alpha * 100)}%`,
    };
};
/**
 * Color => AHEX
 * @param color
 */
exports.color2AHEX = (color) => {
    const { red, green, blue, alpha } = color;
    const hex = ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1);
    const a = ((1 << 8) + Math.round(alpha * 255)).toString(16).slice(1);
    return "#" + (a + hex).toUpperCase();
};
/**
 * Color => HEXA
 * @param color
 */
exports.color2HEXA = (color) => {
    const { red, green, blue, alpha } = color;
    const hex = ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1);
    const a = ((1 << 8) + Math.round(alpha * 255)).toString(16).slice(1);
    return `#${hex.slice(0, 6).toLowerCase()}${a.toUpperCase()}`;
};
/**
 * Color => RGBA
 * @param color
 */
exports.color2RGBA = (color) => {
    const { red, green, blue, alpha } = color;
    return `${red},${green},${blue},${alpha}`;
};
/**
 * Color => HSLA
 * @param color
 */
exports.color2HSLA = (color) => {
    let { red, green, blue, alpha } = color;
    red /= 255, green /= 255, blue /= 255;
    const max = Math.max(red, green, blue), min = Math.min(red, green, blue);
    let h, s, l = (max + min) / 2;
    if (max == min) {
        h = s = 0; // achromatic
    }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case red:
                h = (green - blue) / d + (green < blue ? 6 : 0);
                break;
            case green:
                h = (blue - red) / d + 2;
                break;
            case blue:
                h = (red - green) / d + 4;
                break;
        }
        h /= 6;
    }
    return `${Math.round(h * 360)},${Math.round(s * 100)}%,${Math.round(l * 100)}%,${alpha}`;
};
/**
 * Color 产出不同格式的颜色值
 * @param color
 */
exports.colorTrans = (color) => {
    const hex = exports.color2HEX(color);
    const ahex = exports.color2AHEX(color);
    const hexa = exports.color2HEXA(color);
    const rgba = exports.color2RGBA(color);
    const hsla = exports.color2HSLA(color);
    return [{
            type: 'HEX',
            value: hex.hex,
            alpha: hex.alpha
        }, {
            type: 'AHEX',
            value: ahex,
        }, {
            type: 'HEXA',
            value: hexa,
        }, {
            type: 'RGBA',
            value: rgba,
        }, {
            type: 'HSLA',
            value: hsla,
        }];
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/common.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/common.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports._scale = exports.precisionControl = void 0;
/**
 * 精度控制
 * @param data 需要处理的数据
 * @param num 精度 eg. 0.1 0.01
 */
exports.precisionControl = (data, num = 1) => {
    const len = Math.round(1 / num).toString().length - 1;
    return +((Math.round(data / num) * num).toFixed(len));
};
exports._scale = (data, scale) => typeof data === 'number' ? exports.precisionControl(data / scale, 0.01) : data;


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/cssOrder.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/cssOrder.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * css顺序数组
 */
const cssList = [
    'position',
    'top',
    'right',
    'bottom',
    'left',
    'z-index',
    'display',
    'float',
    'width',
    'height',
    'max-width',
    'max-height',
    'min-width',
    'min-height',
    'padding',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
    'margin',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'margin-collapse',
    'margin-top-collapse',
    'margin-right-collapse',
    'margin-bottom-collapse',
    'margin-left-collapse',
    'overflow',
    'overflow-x',
    'overflow-y',
    'clip',
    'clear',
    'font',
    'font-family',
    'font-size',
    'font-smoothing',
    'osx-font-smoothing',
    'font-style',
    'font-weight',
    'hyphens',
    'src',
    'line-height',
    'letter-spacing',
    'word-spacing',
    'color',
    'text-align',
    'text-decoration',
    'text-indent',
    'text-overflow',
    'text-rendering',
    'text-size-adjust',
    'text-shadow',
    'text-transform',
    'word-break',
    'word-wrap',
    'white-space',
    'vertical-align',
    'list-style',
    'list-style-type',
    'list-style-position',
    'list-style-image',
    'pointer-events',
    'cursor',
    'background',
    'background-attachment',
    'background-color',
    'background-image',
    'background-position',
    'background-repeat',
    'background-size',
    'border',
    'border-collapse',
    'border-top',
    'border-right',
    'border-bottom',
    'border-left',
    'border-color',
    'border-image',
    'border-top-color',
    'border-right-color',
    'border-bottom-color',
    'border-left-color',
    'border-spacing',
    'border-style',
    'border-top-style',
    'border-right-style',
    'border-bottom-style',
    'border-left-style',
    'border-width',
    'border-top-width',
    'border-right-width',
    'border-bottom-width',
    'border-left-width',
    'border-radius',
    'border-top-right-radius',
    'border-bottom-right-radius',
    'border-bottom-left-radius',
    'border-top-left-radius',
    'border-radius-topright',
    'border-radius-bottomright',
    'border-radius-bottomleft',
    'border-radius-topleft',
    'content',
    'quotes',
    'outline',
    'outline-offset',
    'opacity',
    'filter',
    'visibility',
    'size',
    'zoom',
    'transform',
    'box-align',
    'box-flex',
    'box-orient',
    'box-pack',
    'box-shadow',
    'box-sizing',
    'table-layout',
    'animation',
    'animation-delay',
    'animation-duration',
    'animation-iteration-count',
    'animation-name',
    'animation-play-state',
    'animation-timing-function',
    'animation-fill-mode',
    'transition',
    'transition-delay',
    'transition-duration',
    'transition-property',
    'transition-timing-function',
    'background-clip',
    'backface-visibility',
    'resize',
    'appearance',
    'user-select',
    'interpolation-mode',
    'direction',
    'marks',
    'page',
    'set-link-source',
    'unicode-bidi',
    'speak'
];
// 驼峰改连接符
const toKebabCase = (str) => str.replace(/([A-Z])/g, '-$1').toLowerCase();
/**
 * css 排序方法
 */
const order = (item) => {
    // 驼峰转连接符
    item = toKebabCase(item);
    let itemIndex = cssList.length;
    if (cssList.indexOf(item) > -1) {
        itemIndex = cssList.indexOf(item);
    }
    return itemIndex;
};
/**
 * css 格式化
 */
exports.default = (styleObj) => {
    if (styleObj instanceof Object && Object.keys(styleObj).length > 0) {
        // 生成的样式排序
        let styleKeysList = Object.keys(styleObj);
        styleKeysList.sort((a, b) => {
            return order(a) - order(b);
        });
        let styleOrderObj = {};
        for (let i = 0; i < styleKeysList.length; i++) {
            styleOrderObj[styleKeysList[i]] = styleObj[styleKeysList[i]];
        }
        return styleOrderObj;
    }
    else {
        return {};
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/dslPxtoRem.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/dslPxtoRem.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.dslPxtoRem = void 0;
// 处理阴影
const formatShadowPxToRem = (styleVal, remScale) => {
    let styleValArr = styleVal.split('px');
    const tailArr = styleValArr.splice(4, styleValArr.length - 4);
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
    });
    styleValArr = styleValArr.concat(tailArr);
    return styleValArr.join(' ');
};
// 处理背景
const formatBGPxToRem = (styleVal, remScale) => {
    let styleValArr = styleVal.split(' ');
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
    });
    return styleValArr.join(' ');
};
// 处理背景
const formatBGradientPxToRem = (styleVal, remScale) => {
    let stylePxArr = styleVal.split(',');
    const tailArr = stylePxArr.splice(1, stylePxArr.length - 1);
    stylePxArr = stylePxArr[0].split('(')[1];
    stylePxArr = stylePxArr.split(' ');
    stylePxArr = stylePxArr.map(item => {
        if (item.includes('px')) {
            return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
        }
        return item;
    });
    stylePxArr[0] = `radial-gradient(${stylePxArr[0]}`;
    const styleValArr = stylePxArr.concat(tailArr);
    // styleValArr = styleValArr.map(itemFirst => {
    //     if (itemFirst.includes('px')) {
    //         const splitStyle = itemFirst.split(' ');
    //         itemFirst = splitStyle.map(itemSecond => {
    //             if (itemSecond.includes('px')) {
    //                 return `${Math.round(+itemSecond.split('px')[0] * 100 / remScale) /100 }rem`
    //             }
    //             return itemSecond
    //         })
    //     }
    //     return itemFirst
    // })
    return styleValArr.join(',');
};
exports.dslPxtoRem = (styleObj, remScale) => {
    for (let styleKey in styleObj) {
        let styleVal = styleObj[styleKey];
        // if (styleKey !== 'font-weight') {
        //     if (typeof (styleObj[styleKey]) === 'number') {
        //         const styleObjItem = `${Number(styleObj[styleKey]) * this.scaleNum}${this.tag}`;
        //         styleObj[styleKey] = styleObjItem;
        //     }
        // }
        if (typeof styleVal == 'string' && styleVal.includes('px')) {
            // 常规处理
            if (styleKey == 'width' ||
                styleKey == 'height' ||
                styleKey == 'line-height' ||
                styleKey == 'font-size' ||
                styleKey == 'text-indent' ||
                styleKey == 'left' ||
                styleKey == 'right' ||
                styleKey == 'top' ||
                styleKey == 'bottom') {
                styleVal = `${Math.round(+styleVal.split('px')[0] * 100 / remScale) / 100}rem`;
            }
            // margin、padding
            if (styleKey.includes('margin') ||
                styleKey.includes('padding')) {
                const styleValArr = styleVal.split(' ');
                const styleValList = [];
                styleValArr.forEach((item) => {
                    styleValList.push(`${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`);
                });
                styleVal = styleValList.join(' ');
            }
            // 边框
            if (styleKey.includes('border')) {
                const styleValArr = styleVal.split(' ');
                styleValArr[0] = `${Math.round(+styleValArr[0].split('px')[0] * 100 / remScale) / 100}rem`;
                styleVal = styleValArr.join(' ');
            }
            // 背景 position、size
            if (styleKey.includes('background-')) {
                styleVal = formatBGPxToRem(styleVal, remScale);
            }
            // 背景 radial-gradient
            if (styleKey == 'background') {
                styleVal = formatBGradientPxToRem(styleVal, remScale);
            }
            // 边框阴影、文字阴影
            if (styleKey.includes('box-shadow') ||
                styleKey.includes('text-shadow')) {
                styleVal = formatShadowPxToRem(styleVal, remScale);
            }
        }
        styleObj[styleKey] = styleVal;
    }
    return styleObj;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/dslPxtoRpx.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/dslPxtoRpx.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.dslPxtoRpx = void 0;
//处理背景
const formarBGPxToRpx = (styleVal, scale) => {
    // const scale = 750 / size;
    let styleValArr = styleVal.split(' ');
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`;
    });
    return styleValArr.join(' ');
};
//处理径向渐变
const formarBGradientPxToRpx = (styleVal, scale) => {
    // const scale = 750 / size;
    let stylePxArr = styleVal.split(',');
    const tailArr = stylePxArr.splice(1, stylePxArr.length - 1);
    stylePxArr = stylePxArr[0].split('(')[1];
    stylePxArr = stylePxArr.split(' ');
    stylePxArr = stylePxArr.map(item => {
        if (item.includes('px')) {
            return `${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`;
        }
        return item;
    });
    stylePxArr[0] = `radial-gradient(${stylePxArr[0]}`;
    const styleValArr = stylePxArr.concat(tailArr);
    return styleValArr.join(',');
};
//处理阴影
const formatShadowPxToRpx = (styleVal, scale) => {
    // const scale = 750 / size;
    let styleValArr = styleVal.split('px');
    const tailArr = styleValArr.splice(4, styleValArr.length - 4);
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`;
    });
    styleValArr = styleValArr.concat(tailArr);
    return styleValArr.join(' ');
};
exports.dslPxtoRpx = (styleObj, scale) => {
    // const scale = 750 / size;
    for (let styleKey in styleObj) {
        let styleVal = styleObj[styleKey];
        if (styleKey !== 'font-weight') {
            if (typeof (styleObj[styleKey]) === 'number') {
                // const styleObjItem = `${Number(styleObj[styleKey]) * this.scaleNum}${this.tag}`;
                const styleObjItem = `${Number(styleObj[styleKey])}`;
                styleObj[styleKey] = styleObjItem;
            }
        }
        if (typeof styleVal == 'string' && styleVal.includes('px')) {
            // 常规处理
            if (styleKey == 'width' ||
                styleKey == 'height' ||
                styleKey == 'line-height' ||
                styleKey == 'font-size' ||
                styleKey == 'text-indent' ||
                styleKey == 'left' ||
                styleKey == 'right' ||
                styleKey == 'top' ||
                styleKey == 'bottom') {
                styleVal = `${Math.round(+styleVal.split('px')[0] * 10 * scale) / 10}rpx`;
            }
            // margin、padding
            if (styleKey.includes('margin') ||
                styleKey.includes('padding')) {
                const styleValArr = styleVal.split(' ');
                const styleValList = [];
                styleValArr.forEach((item) => {
                    styleValList.push(`${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`);
                });
                styleVal = styleValList.join(' ');
            }
            // 边框
            if (styleKey.includes('border')) {
                const styleValArr = styleVal.split(' ');
                styleValArr[0] = `${Math.round(+styleValArr[0].split('px')[0] * scale * 10) / 10}rpx`;
                styleVal = styleValArr.join(' ');
            }
            // 背景 position、size
            if (styleKey.includes('background-')) {
                styleVal = formarBGPxToRpx(styleVal, scale);
            }
            // 径向渐变 radial-gradient
            if (styleKey == 'background') {
                styleVal = formarBGradientPxToRpx(styleVal, scale);
            }
            // 边框阴影、文字阴影
            if (styleKey.includes('box-shadow') ||
                styleKey.includes('text-shadow')) {
                styleVal = formatShadowPxToRpx(styleVal, scale);
            }
        }
        styleObj[styleKey] = styleVal;
    }
    return styleObj;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/formateDslStyle.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/formateDslStyle.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.formateDslStyle = exports.formatDslRpxStyle = exports.formateDslRemStyle = void 0;
const utils_1 = __webpack_require__(/*! ./utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/utils.js");
const dslPxtoRem_1 = __webpack_require__(/*! ./dslPxtoRem */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/dslPxtoRem.js");
const dslPxtoRpx_1 = __webpack_require__(/*! ./dslPxtoRpx */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/dslPxtoRpx.js");
const cssOrder_1 = __webpack_require__(/*! ./cssOrder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/cssOrder.js");
// 驼峰改连接符
const toKebabCase = (str) => str.replace(/([A-Z])/g, '-$1').toLowerCase();
const addPx = (val) => {
    if (typeof val == 'number')
        return `${val}px`;
    return val;
};
// 转rem
exports.formateDslRemStyle = (formateDsl, remScale) => {
    // 标注稿以rem形式展示
    if (!remScale || isNaN(Number(remScale)))
        return formateDsl;
    for (let item of formateDsl) {
        let remStyle = {}; // 样式集合
        remStyle = dslPxtoRem_1.dslPxtoRem(item.style, remScale);
        item.style = remStyle;
        if (item.children && item.children.length) {
            exports.formateDslRemStyle(item.children, remScale);
        }
    }
    return formateDsl;
};
//转rpx
exports.formatDslRpxStyle = (formateDsl, size) => {
    for (let item of formateDsl) {
        let rpxStyle = {}; // 样式集合
        rpxStyle = dslPxtoRpx_1.dslPxtoRpx(item.style, size);
        item.style = rpxStyle;
        if (item.children && item.children.length) {
            exports.formatDslRpxStyle(item.children, size);
        }
    }
    return formateDsl;
};
/**
 * DSL=> webStyle 转换方法
 * @param data
 */
exports.formateDslStyle = (data) => {
    //let formateDsl = JSON.parse(JSON.stringify(data))
    for (let i = 0; i < data.length; i++) {
        let style = {}; // 样式集合
        const item = data[i];
        // 处理 structure
        if (item.structure && Object.keys(item.structure).length) {
            for (var key in item.structure) {
                let currValue = item.structure[key];
                // sketch 设计稿解析过来的没有 margin 和 padding
                switch (key) {
                    case 'border':
                        style = Object.assign(Object.assign({}, style), utils_1.generateProperty(currValue));
                        break;
                    case 'width':
                        style[key] = `${Math.round(currValue * 100) / 100}px`;
                        break;
                    case 'height':
                        style[key] = `${Math.round(currValue * 100) / 100}px`;
                        break;
                    case 'x':
                    case 'y':
                        if (style.position) {
                            style[key] = `${Math.round(currValue * 100) / 100}px`;
                        }
                        break;
                    case 'zIndex':
                        if (style.position) {
                            style[toKebabCase(key)] = currValue;
                        }
                        break;
                    default:
                        style[toKebabCase(key)] = utils_1.generateMargin(currValue);
                        break;
                }
            }
        }
        // 处理 style
        if (item.style && Object.keys(item.style).length) {
            for (var key in item.style) {
                if (item.style.hasOwnProperty(key) &&
                    item.style[key] != undefined) {
                    let currValue = item.style[key];
                    switch (key) {
                        case 'textStyle': // text样式直接放在style里
                            for (let textKey of Object.keys(currValue)) {
                                let textVal = currValue[textKey];
                                // 颜色处理
                                if (textKey == 'color') {
                                    textVal = utils_1.generateColor(textVal);
                                }
                                // px处理
                                if (textKey == 'lineHeight' || textKey == 'fontSize' || textKey == 'textIndent' || textKey == 'letterSpacing') {
                                    textVal = `${Math.round(currValue[textKey] * 100) / 100}px`;
                                }
                                // 其他不处理
                                style[toKebabCase(textKey)] = textVal;
                            }
                            break;
                        case 'background': // background样式放到background里
                            let propertyVal;
                            for (let backgroundKey of Object.keys(currValue)) {
                                let backgroundVal = currValue[backgroundKey];
                                if (backgroundKey == 'linearGradient') {
                                    let { gAngle, gList } = backgroundVal;
                                    let list = gList.map((ref) => {
                                        return `${utils_1.generateColor(ref.color)} ${ref.position * 100}%`;
                                    });
                                    list = [...new Set(list)];
                                    style['background'] = `linear-gradient(${Math.round(gAngle * 100) / 100}deg, ${list.join(',')})`;
                                }
                                else if (backgroundKey == 'radialGradient') {
                                    let { backgroundVal: any, smallRadius, largeRadius, position, gList, } = backgroundVal;
                                    let list = gList.map((ref) => {
                                        return `${utils_1.generateColor(ref.color)} ${ref.position * 100}%`;
                                    });
                                    style['background'] = `radial-gradient(${Math.round(smallRadius * 100) / 100}px ${Math.round(largeRadius * 100) / 100}px at ${Math.round(position.left * 100) / 100}px ${Math.round(-position.top * 100) / 100}px, ${list.join(',')})`;
                                }
                                else if (typeof backgroundVal == 'object') {
                                    if (backgroundKey == 'color') {
                                        propertyVal = utils_1.generateColor(backgroundVal);
                                    }
                                    else if (backgroundKey == 'image' && item.type !== 'Image') {
                                        propertyVal = `url(../images/${backgroundVal.url})`;
                                    }
                                    else { // position、size
                                        let valList = [];
                                        for (let ref of Object.keys(backgroundVal)) {
                                            valList.push(addPx(backgroundVal[ref]));
                                        }
                                        propertyVal = valList.join(' ');
                                    }
                                    style[`background-${backgroundKey}`] = propertyVal;
                                    // 如果为图片，则背景色无效
                                    if (item.type === 'Image') {
                                        delete style['background-color'];
                                    }
                                }
                                else if (backgroundKey == 'repeat') {
                                    // style[`background-${backgroundKey}`] = backgroundVal
                                }
                            }
                            break;
                        case 'textShadow':
                        case 'boxShadow':
                            let shodowList = [];
                            for (let item of currValue) {
                                let { offsetX, offsetY, spread, blurRadius, color, type, } = item;
                                shodowList.push(type
                                    ? `${offsetX}px ${offsetY}px ${blurRadius}px ${spread}px ${utils_1.generateColor(color)} ${type}`
                                    : `${offsetX}px ${offsetY}px ${blurRadius}px ${spread}px ${utils_1.generateColor(color)}`);
                            }
                            if (shodowList.length) {
                                style[toKebabCase(key)] = shodowList.join(', ');
                            }
                            break;
                        case 'transform':
                            let { scale = {}, rotate } = currValue;
                            let transform = [];
                            if (scale.horizontal != undefined &&
                                scale.vertical != undefined) {
                                transform.push(`scale(${scale.horizontal},${scale.vertical})`);
                            }
                            if (rotate != undefined) {
                                transform.push(`rotate(${rotate}deg)`);
                            }
                            if (transform && transform.length) {
                                style['transform'] = transform.join(' ');
                            }
                            break;
                        case 'borderRadius':
                            let borderRadius = utils_1.generateBorderRadius(currValue);
                            if (borderRadius) {
                                style['border-radius'] = borderRadius;
                            }
                            break;
                        case 'zIndex':
                        case 'fontWeight':
                            style[key] = currValue;
                            break;
                        case 'lineHeight':
                            style[toKebabCase(key)] = currValue;
                            break;
                        case 'width':
                        case 'height':
                        case 'marginTop':
                        case 'marginRight':
                        case 'marginLeft':
                        case 'marginBottom':
                        case 'paddingTop':
                        case 'paddingRight':
                        case 'paddingLeft':
                        case 'paddingBottom':
                            typeof currValue == 'string'
                                ? (style[toKebabCase(key)] = currValue)
                                : (style[toKebabCase(key)] = `${currValue}px`);
                            break;
                        default:
                            typeof currValue == 'string'
                                ? (style[toKebabCase(key)] = currValue)
                                : (style[toKebabCase(key)] = `${currValue}px`);
                    }
                }
            }
        }
        // css 排序
        data[i].style = cssOrder_1.default(style);
        if (data[i].children && data[i].children.length) {
            data[i].children = exports.formateDslStyle(data[i].children);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/index.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/index.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoTrans = void 0;
const formateDslStyle_1 = __webpack_require__(/*! ./formateDslStyle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/formateDslStyle.js");
const transRNStyle_1 = __webpack_require__(/*! ./transRNStyle */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transRNStyle.js");
const transAndroidCode_1 = __webpack_require__(/*! ./transAndroidCode */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transAndroidCode.js");
const transIOSCode_1 = __webpack_require__(/*! ./transIOSCode */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transIOSCode.js");
const transWebCode_1 = __webpack_require__(/*! ./transWebCode */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transWebCode.js");
const transPanel_1 = __webpack_require__(/*! ./transPanel */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transPanel.js");
const transScale_1 = __webpack_require__(/*! ./transScale */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transScale.js");
const types_1 = __webpack_require__(/*! ./types */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/types.js");
__exportStar(__webpack_require__(/*! ./codeTrans */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/codeTrans.js"), exports);
__exportStar(__webpack_require__(/*! ./colorTrans */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/colorTrans.js"), exports);
/**
 *
 * @param {Array} data DSL
 * @param {Number} remScale rem换算参数
 * @returns 处理后的DSL样式
 */
exports.picassoTrans = (data, { scale = types_1.WebScale.Points, unit = types_1.Unit.WebPx, colorFormat = types_1.ColorFormat.RGBA, codeType = types_1.CodeType.WebPx, }) => {
    // 属性面板处理
    data = transPanel_1.transPanel(data, { scale, unit, colorFormat, codeType });
    // 画板宽度
    // const artboardWidth = data[0].structure.width * scale;
    const scaleData = transScale_1.transScale(data, { scale, unit, colorFormat, codeType });
    switch (codeType) {
        case types_1.CodeType.WebPx:
            const codeData = formateDslStyle_1.formateDslStyle(scaleData);
            return transWebCode_1.transWebCode(data, codeData);
        case types_1.CodeType.WebRem:
            // 样式转换px
            const dataPx = formateDslStyle_1.formateDslStyle(scaleData);
            // 样式转换rem
            const dataRem = formateDslStyle_1.formateDslRemStyle(dataPx, 1);
            return transWebCode_1.transWebCode(data, dataRem);
        case types_1.CodeType.Weapp:
            // 样式转换px
            const dataweappPx = formateDslStyle_1.formateDslStyle(scaleData);
            // 样式转换rpx
            const dataRpx = formateDslStyle_1.formatDslRpxStyle(dataweappPx, 1);
            return transWebCode_1.transWebCode(data, dataRpx);
        case types_1.CodeType.ReactNative:
            const codeRNData = transRNStyle_1.transRNStyle(scaleData);
            return transWebCode_1.transWebCode(data, codeRNData);
        case types_1.CodeType.IOS:
            return transIOSCode_1.transIOSCode(data);
        case types_1.CodeType.Android:
            return transAndroidCode_1.transAndroidCode(data);
        default:
            break;
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transAndroidCode.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transAndroidCode.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transAndroidCode = void 0;
const colorTrans_1 = __webpack_require__(/*! ./colorTrans */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/colorTrans.js");
const _getAndroidWithHeight = (panel) => "android:layout_width=\"" + panel.properties.size.width + "\"\r\n" + "android:layout_height=\"" + panel.properties.size.height + "\"\r\n";
const _getAndroidShapeBackground = (panel) => {
    const pureColorFill = panel.fills.find(item => item.type === 0);
    if (pureColorFill) {
        return "android:background=\"" + colorTrans_1.color2AHEX(pureColorFill.color) + "\"\r\n";
    }
    return '';
};
exports.transAndroidCode = (data) => {
    for (let i = 0; i < data.length; i++) {
        const { panelData: panel } = data[i];
        const androidCode = [];
        if (data[i].type === "Text") {
            androidCode.push("<TextView\r\n" + _getAndroidWithHeight(panel)
                + "android:text=\"" + data[i].value + "\"\r\n" + "android:textColor=\"" + colorTrans_1.color2AHEX(panel.typefaces[0].color) + "\"\r\n"
                + "android:textSize=\"" + panel.typefaces[0].fontSize.replace('dp', 'sp') + "\"\r\n" + "/>" + '</textarea></label>');
        }
        else if (data[i].type === "Container") {
            androidCode.push("<View\r\n" + _getAndroidWithHeight(panel)
                + _getAndroidShapeBackground(panel)
                + "/>");
        }
        data[i].panelData.code = androidCode.join('');
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            data[i].children = exports.transAndroidCode(data[i].children);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transIOSCode.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transIOSCode.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transIOSCode = void 0;
exports.transIOSCode = (data) => {
    for (let i = 0; i < data.length; i++) {
        const { panelData: panel } = data[i];
        const iosCode = [];
        if (data[i].type === "Text") {
            iosCode.push("UILabel *label = [[UILabel alloc] init];\r\n"
                + "label.frame = CGRectMake(" + panel.properties.position.x + "\, " + panel.properties.position.y + "\, "
                + panel.properties.size.width + "\, " + panel.properties.size.height + ");\r\n"
                + "label.text = \@\"" + data[i].value + "\";\r\n"
                + "label.font = [UIFont fontWithName:\@\"" + panel.typefaces[0].fontFamily + "\" size:" + panel.typefaces[0].fontSize + "];\r\n"
                + "label.textColor = [UIColor colorWithRed:" + panel.typefaces[0].color.red + "/255.0 green:" + panel.typefaces[0].color.red + "/255.0 blue:" + panel.typefaces[0].color.blue + "/255.0 alpha:" + panel.typefaces[0].color.alpha + "/1.0];\r\n");
        }
        else if (data[i].type === "Container") {
            let bgColorCode = '';
            const pureColorFill = panel.fills.find(item => item.type === 0);
            if (pureColorFill) {
                bgColorCode = "view.backgroundColor = [UIColor colorWithRed:" + pureColorFill.color.red + "/255.0 green:" + pureColorFill.color.green + "/255.0 blue:" + pureColorFill.color.blue + "/255.0 alpha:" + pureColorFill.color.alpha + "/1.0]\;\r\n";
            }
            iosCode.push("UIView *view = [[UIView alloc] init];\r\n"
                + "view.frame = CGRectMake(" + panel.properties.position.x + "\, " + panel.properties.position.y + "\, "
                + panel.properties.size.width + "\, " + panel.properties.size.height + ");\r\n"
                + bgColorCode);
        }
        data[i].panelData.code = iosCode.join('');
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            data[i].children = exports.transIOSCode(data[i].children);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transPanel.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transPanel.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transPanel = void 0;
const common_1 = __webpack_require__(/*! ./common */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/common.js");
exports.transPanel = (data, options) => {
    const { scale, unit } = options;
    for (let i = 0; i < data.length; i++) {
        const { panel } = data[i];
        if (panel) {
            const { properties, fills, typefaces, borders, shadows, code } = panel;
            // panel转换
            data[i].panelData = {
                properties: {
                    name: properties.name,
                    position: {
                        x: `${common_1._scale(properties.position.x, scale)}${unit}`,
                        y: `${common_1._scale(properties.position.y, scale)}${unit}`,
                    },
                    size: {
                        width: `${common_1._scale(properties.size.width, scale)}${unit}`,
                        height: `${common_1._scale(properties.size.height, scale)}${unit}`
                    },
                    opacity: properties.opacity ? `${properties.opacity * 100}%` : '',
                    radius: properties.radius ? `${common_1._scale(properties.radius, scale)}${unit}` : ''
                },
                fills,
                typefaces: typefaces.map(typeface => {
                    const { fontSize, letterSpacing, lineHeight, paragraphSpacing } = typeface;
                    return Object.assign(Object.assign({}, typeface), { fontSize: `${common_1._scale(fontSize, scale)}${unit}`, letterSpacing: `${common_1._scale(letterSpacing, scale)}${unit}`, lineHeight: `${common_1._scale(lineHeight, scale)}${unit}`, paragraphSpacing: `${common_1._scale(paragraphSpacing, scale)}${unit}` });
                }),
                borders: borders.map(border => {
                    const { thickness } = border;
                    return Object.assign(Object.assign({}, border), { thickness: `${common_1._scale(thickness, scale)}${unit}` });
                }),
                shadows: shadows.map((shadow) => {
                    const { offsetX, offsetY, blurRadius, spread } = shadow;
                    return Object.assign(Object.assign({}, shadow), { offsetX: `${common_1._scale(offsetX, scale)}${unit}`, offsetY: `${common_1._scale(offsetY, scale)}${unit}`, blurRadius: `${common_1._scale(blurRadius, scale)}${unit}`, spread: `${common_1._scale(spread, scale)}${unit}` });
                }),
                code
            };
        }
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            data[i].children = exports.transPanel(data[i].children, options);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transRNStyle.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transRNStyle.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transRNStyle = void 0;
/*
 * @Author: iChengbo
 * @Date: 2020-07-08 10:59:55
 * @LastEditors: iChengbo
 * @LastEditTime: 2020-09-08 19:07:57
 * @FilePath: /picasso-core/packages/picasso-trans/src/transRNStyle.ts
 */
const utils_1 = __webpack_require__(/*! ./utils */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/utils.js");
const cssOrder_1 = __webpack_require__(/*! ./cssOrder */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/cssOrder.js");
// const humpKey2 = key.replace(/-(\w)/g, ($, $1) => $1.toUpperCase());
const toHumpKey = (str) => str.replace(/-(\w)/g, ($, $1) => $1.toUpperCase());
const getValidValue = (object, key) => {
    if (!!object && !!object.key) {
        return object.key;
    }
};
exports.transRNStyle = (data) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
    // console.log("------------------------")
    // console.log("data: ", data)
    for (let item of data) {
        // 样式集合
        let style = {};
        // 布局
        if (item.structure && Object.keys(item.structure).length) {
            for (var key in item.structure) {
                let currValue = item.structure[key];
                // console.log("布局：", key)
                switch (key) {
                    case 'x':
                    case 'y':
                        // case 'zIndex':
                        break;
                    case 'width':
                    case 'height':
                        if (item.type == 'Text') {
                            if (key == 'width') {
                                const _fontSize = (item.style && item.style.textStyle && item.style.textStyle.fontSize) ? item.style.textStyle.fontSize : 28;
                                const dis = parseInt(item.style.width) - _fontSize * item.value.length;
                                if (Math.abs(dis) < 100) {
                                    style['textAlign'] = 'left';
                                }
                                else {
                                    style[key] = parseInt(currValue);
                                }
                            }
                            else {
                                // TODO：文本设高度的话，需处理垂直居中问题
                                style[key] = parseInt(currValue);
                                // style['lineHeight'] = parseInt(currValue) / 2;
                                // style['flexDirection'] = 'row';
                                // style['alignItems'] = 'center';
                                style['textAlignVertical'] = 'center';
                            }
                        }
                        else {
                            style[key] = parseInt(currValue);
                        }
                        break;
                    case 'border':
                        if (!!currValue) {
                            if (currValue.top && currValue.left && currValue.right && currValue.bottom
                                && JSON.stringify(currValue.top) === JSON.stringify(currValue.right)
                                && JSON.stringify(currValue.top) === JSON.stringify(currValue.left)
                                && JSON.stringify(currValue.top) === JSON.stringify(currValue.bottom)) {
                                style['borderStyle'] = (_a = currValue.top) === null || _a === void 0 ? void 0 : _a.style;
                                style['borderWidth'] = (_b = currValue.top) === null || _b === void 0 ? void 0 : _b.width;
                                style['borderColor'] = utils_1.generateColor((_c = currValue.top) === null || _c === void 0 ? void 0 : _c.color);
                            }
                            else {
                                style['borderTopStyle'] = (_d = currValue.top) === null || _d === void 0 ? void 0 : _d.style;
                                style['borderTopWidth'] = (_e = currValue.top) === null || _e === void 0 ? void 0 : _e.width;
                                style['borderTopColor'] = utils_1.generateColor((_f = currValue.top) === null || _f === void 0 ? void 0 : _f.color);
                                style['borderRigthStyle'] = (_g = currValue.right) === null || _g === void 0 ? void 0 : _g.style;
                                style['borderRightWidth'] = (_h = currValue.right) === null || _h === void 0 ? void 0 : _h.width;
                                style['borderRightColor'] = utils_1.generateColor((_j = currValue.right) === null || _j === void 0 ? void 0 : _j.color);
                                style['borderBottomStyle'] = (_k = currValue.bottom) === null || _k === void 0 ? void 0 : _k.style;
                                style['borderBottomWidth'] = (_l = currValue.bottom) === null || _l === void 0 ? void 0 : _l.width;
                                style['borderBottomColor'] = utils_1.generateColor((_m = currValue.bottom) === null || _m === void 0 ? void 0 : _m.color);
                                style['borderLeftStyle'] = (_o = currValue.left) === null || _o === void 0 ? void 0 : _o.style;
                                style['borderLeftWidth'] = (_p = currValue.left) === null || _p === void 0 ? void 0 : _p.width;
                                style['borderLeftColor'] = utils_1.generateColor((_q = currValue.left) === null || _q === void 0 ? void 0 : _q.color);
                            }
                        }
                        break;
                    case 'margin':
                        if (!!currValue) {
                            style['marginTop'] = currValue.top;
                            style['marginBottom'] = currValue.bottom;
                            style['marginLeft'] = currValue.left;
                            style['marginRight'] = currValue.right;
                        }
                        break;
                    case 'padding':
                        if (!!currValue) {
                            style['paddingTop'] = currValue.top;
                            style['paddingBottom'] = currValue.bottom;
                            style['paddingLeft'] = currValue.left;
                            style['paddingRight'] = currValue.right;
                        }
                        break;
                    default:
                        style[key] = currValue;
                        break;
                }
            }
        }
        // 样式
        if (item.style && Object.keys(item.style).length) {
            for (var key in item.style) {
                if (item.style.hasOwnProperty(key) && item.style[key] != undefined) {
                    let currValue = item.style[key];
                    // console.log("样式：", key)
                    switch (key) {
                        case 'marginTop':
                        case 'marginRight':
                        case 'marginLeft':
                        case 'marginBottom':
                        case 'paddingTop':
                        case 'paddingRight':
                        case 'paddingLeft':
                        case 'paddingBottom':
                            const _currValue = parseInt(currValue);
                            style[key] = !Number.isNaN(_currValue) ? _currValue : 0;
                            // style[key] = parseInt(currValue) / 2;
                            break;
                        case 'borderRadius':
                            if (currValue['topLeft']
                                && currValue['topLeft'] === currValue['topRight']
                                && currValue['topLeft'] === currValue['bottomLeft']
                                && currValue['topLeft'] === currValue['bottomRight']) {
                                style['borderRadius'] = currValue['topLeft'];
                            }
                            else {
                                if (currValue['topLeft']) {
                                    style['borderTopLeftRadius'] = currValue['topLeft'];
                                }
                                if (currValue['topRight']) {
                                    style['borderTopRightRadius'] = currValue['topRight'];
                                }
                                if (currValue['bottomLeft']) {
                                    style['borderBottomLeftRadius'] = currValue['bottomLeft'];
                                }
                                if (currValue['bottomRight']) {
                                    style['borderBottomRightRadius'] = currValue['bottomRight'];
                                }
                            }
                            break;
                        case 'justifyContent':
                        case 'alignItems':
                        case 'flexDirection':
                            style[key] = currValue;
                            break;
                        case 'textStyle':
                            for (let textKey of Object.keys(currValue)) {
                                if (!!currValue && !!currValue[textKey]) {
                                    let textVal = currValue[textKey];
                                    switch (textKey) {
                                        case 'wordBreak':
                                        case 'fontFamily':
                                            break;
                                        case 'fontWeight':
                                            style[textKey] = String(textVal);
                                            break;
                                        case 'lineHeight':
                                            // 确保行高稍大于文字尺寸，避免Android端文本被切头
                                            if (textVal - currValue['fontSize'] > 4) {
                                                style[textKey] = parseInt(textVal);
                                            }
                                            break;
                                        case 'fontSize':
                                            style[textKey] = parseInt(textVal);
                                            break;
                                        case 'color':
                                            textVal = utils_1.generateColor(textVal);
                                            style[textKey] = textVal;
                                            break;
                                        case 'textAlign':
                                            // 布局为主
                                            if (!style['textAlign']) {
                                                style[textKey] = textVal;
                                            }
                                            break;
                                        default:
                                            style[textKey] = textVal;
                                            break;
                                    }
                                }
                            }
                            break;
                        case 'textShadow':
                            // TODO
                            break;
                        case 'background':
                            // console.log("背景样式", currValue)
                            for (let bgKey of Object.keys(currValue)) {
                                let bgVal = currValue[bgKey];
                                switch (bgKey) {
                                    case 'position':
                                        style['position'] = 'absolute';
                                        break;
                                    case 'color':
                                        bgVal = utils_1.generateColor(bgVal);
                                        style['backgroundColor'] = bgVal;
                                        break;
                                    case 'image':
                                        // 背景图特殊处理，最终生成样式时需删除此属性
                                        style['backgroundImage'] = bgVal.url;
                                        break;
                                    case 'linearGradient':
                                        // 渐变特殊处理，最终生成样式时需删除此属性
                                        style['linearGradient'] = bgVal;
                                        break;
                                    case 'size':
                                        style['backgroundSize'] = bgVal;
                                        break;
                                    default:
                                        break;
                                }
                            }
                            break;
                        case 'boxShadow':
                            // console.log("阴影样式", currValue)
                            if (!!currValue && !!currValue.color && item.type == 'Container') {
                                style = Object.assign(Object.assign({}, style), { elevation: 5, 
                                    // 以下属性，仅 IOS 可用
                                    shadowColor: utils_1.generateColor(currValue.color), shadowOffset: {
                                        width: currValue.offsetX,
                                        height: currValue.offsetY,
                                    }, shadowRadius: currValue.blurRadius });
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        // css 排序
        item.style = cssOrder_1.default(style);
        if (item.children && item.children.length) {
            exports.transRNStyle(item.children);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transScale.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transScale.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transScale = void 0;
const common_1 = __webpack_require__(/*! ./common */ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/common.js");
exports.transScale = (data, options) => {
    var _a;
    const { scale } = options;
    const scaleData = JSON.parse(JSON.stringify(data));
    for (let i = 0; i < scaleData.length; i++) {
        const { structure } = scaleData[i];
        scaleData[i].structure = Object.assign(Object.assign({}, scaleData[i].structure), { x: common_1._scale(structure.x, scale), y: common_1._scale(structure.y, scale), width: common_1._scale(structure.width, scale), height: common_1._scale(structure.height, scale) });
        if (scaleData[i].structure.border) {
            scaleData[i].structure.border = {
                top: Object.assign(Object.assign({}, scaleData[i].structure.border.top), { width: common_1._scale(scaleData[i].structure.border.top.width, scale) }),
                right: Object.assign(Object.assign({}, scaleData[i].structure.border.right), { width: common_1._scale(scaleData[i].structure.border.right.width, scale) }),
                bottom: Object.assign(Object.assign({}, scaleData[i].structure.border.bottom), { width: common_1._scale(scaleData[i].structure.border.bottom.width, scale) }),
                left: Object.assign(Object.assign({}, scaleData[i].structure.border.left), { width: common_1._scale(scaleData[i].structure.border.left.width, scale) })
            };
        }
        if (scaleData[i].style.width) {
            scaleData[i].style.width = common_1._scale(scaleData[i].style.width, scale);
        }
        if (scaleData[i].style.height) {
            scaleData[i].style.height = common_1._scale(scaleData[i].style.height, scale);
        }
        if (scaleData[i].style.textStyle) {
            if (scaleData[i].style.textStyle.fontSize) {
                scaleData[i].style.textStyle.fontSize = common_1._scale(scaleData[i].style.textStyle.fontSize, scale);
            }
            if (scaleData[i].style.textStyle.letterSpacing) {
                scaleData[i].style.textStyle.letterSpacing = common_1._scale(scaleData[i].style.textStyle.letterSpacing, scale);
            }
            if (scaleData[i].style.textStyle.lineHeight) {
                scaleData[i].style.textStyle.lineHeight = common_1._scale(scaleData[i].style.textStyle.lineHeight, scale);
            }
        }
        if (scaleData[i].style.lineHeight) {
            scaleData[i].style.lineHeight = common_1._scale(scaleData[i].style.lineHeight, scale);
        }
        if (scaleData[i].style.boxShadow) {
            scaleData[i].style.boxShadow = scaleData[i].style.boxShadow.map(shadow => (Object.assign(Object.assign({}, shadow), { offsetX: common_1._scale(shadow.offsetX, scale), offsetY: common_1._scale(shadow.offsetY, scale), spread: common_1._scale(shadow.spread, scale), blurRadius: common_1._scale(shadow.blurRadius, scale) })));
        }
        if (scaleData[i].style.textShadow) {
            scaleData[i].style.textShadow = scaleData[i].style.textShadow.map(shadow => (Object.assign(Object.assign({}, shadow), { offsetX: common_1._scale(shadow.offsetX, scale), offsetY: common_1._scale(shadow.offsetY, scale), spread: common_1._scale(shadow.spread, scale), blurRadius: common_1._scale(shadow.blurRadius, scale) })));
        }
        if (scaleData[i].style.borderRadius) {
            const { bottomLeft, bottomRight, topLeft, topRight } = scaleData[i].style.borderRadius;
            scaleData[i].style.borderRadius = {
                bottomLeft: common_1._scale(bottomLeft, scale),
                bottomRight: common_1._scale(bottomRight, scale),
                topLeft: common_1._scale(topLeft, scale),
                topRight: common_1._scale(topRight, scale),
            };
        }
        if ((_a = scaleData[i].style.background) === null || _a === void 0 ? void 0 : _a.radialGradient) {
            const { smallRadius, largeRadius, position } = scaleData[i].style.background.radialGradient;
            scaleData[i].style.background.radialGradient = Object.assign(Object.assign({}, scaleData[i].style.background.radialGradient), { smallRadius: common_1._scale(smallRadius, scale), largeRadius: common_1._scale(largeRadius, scale), position: {
                    left: common_1._scale(position.left, scale),
                    top: common_1._scale(position.top, scale),
                } });
        }
        if (Array.isArray(scaleData[i].children)) {
            scaleData[i].children = exports.transScale(scaleData[i].children, options);
        }
    }
    return scaleData;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transWebCode.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/transWebCode.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transWebCode = void 0;
exports.transWebCode = (data, codeData) => {
    for (let i = 0; i < data.length; i++) {
        // let code = '';
        // Object.keys(codeData[i].style).forEach(item=> {
        //     code += `${item}: ${codeData[i].style[item]};\r\n`;
        // })
        if (!data[i].panelData) {
            data[i].panelData = {};
        }
        // 属性面板兼容
        data[i].panelData.code = codeData[i].style;
        // 样式复值
        data[i].style = codeData[i].style;
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            exports.transWebCode(data[i].children, codeData[i].children);
        }
    }
    return data;
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/types.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/types.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(/*! ../../sketch-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js"), exports);
__exportStar(__webpack_require__(/*! ../../picasso-dsl/src */ "./node_modules/@wubafe/picasso-parse/dist/picasso-dsl/src/index.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/utils.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/picasso-trans/src/utils.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.generateMargin = exports.generateBorderRadius = exports.generateProperty = exports.generateColor = void 0;
exports.generateColor = ({ red = '', green = '', blue = '', alpha = 1, } = {}) => {
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
};
// border处理
exports.generateProperty = (obj) => {
    let rst = {};
    if (Object.prototype.toString.call(obj) !== "[object Object]")
        return rst;
    let keys = Object.keys(obj);
    if (!keys || !keys.length)
        return rst;
    const isObjValEqual = (obj1, obj2) => {
        let isEqual = true;
        let objItem = Object.keys(obj1);
        for (let i = 0; i < objItem.length; i++) {
            if (objItem[i] == 'color') {
                if (obj1.color.alpha != obj2.color.alpha ||
                    obj1.color.red != obj2.color.red ||
                    obj1.color.blue != obj2.color.blue ||
                    obj1.color.green != obj2.color.green) {
                    isEqual = false;
                }
            }
            else {
                if (obj1[objItem[i]] != obj2[objItem[i]]) {
                    isEqual = false;
                    break;
                }
            }
        }
        return isEqual;
    };
    // 判断四个方向的值都是一样的
    if (keys.length == 4 &&
        isObjValEqual(obj.top, obj.bottom) &&
        isObjValEqual(obj.left, obj.right) &&
        isObjValEqual(obj.top, obj.left)) {
        let { width, color, style } = obj.left;
        rst.border = `${width}px ${style} ${exports.generateColor(color)}`;
    }
    else {
        for (let key of keys) {
            // top right bottom left
            if (obj[key] != undefined) {
                let { width, color, style } = obj[key];
                rst[`border-${key}`] = `${width}px ${style} ${exports.generateColor(color)}`;
            }
        }
    }
    return rst;
};
// border-radius处理
exports.generateBorderRadius = (obj) => {
    if (typeof obj == 'string')
        return obj;
    if (typeof obj == 'object') {
        let values = Object.values(obj);
        if (!values.length || !values[0])
            return '';
        if (values.length == 4 && new Set(values).size === 1) {
            return typeof obj.topLeft === 'string' ? obj.topLeft : `${obj.topLeft}px`;
        }
        return `${obj.topLeft}px ${obj.topRight}px ${obj.bottomRight}px ${obj.bottomLeft}px`;
    }
};
// margin、padding处理
exports.generateMargin = (obj) => {
    if (typeof obj == 'string')
        return obj;
    if (typeof obj == 'object') {
        let values = Object.values(obj);
        if (!values.length)
            return '';
        if (values.length == 4 && new Set(values).size == 1) {
            return `${obj.top}px`;
        }
        return `${obj.top}px ${obj.right}px ${obj.bottom}px ${obj.left}px`;
    }
};


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/Panel.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/Panel.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Alignment;
(function (Alignment) {
    Alignment[Alignment["Left"] = 0] = "Left";
    Alignment[Alignment["Right"] = 1] = "Right";
    Alignment[Alignment["Center"] = 2] = "Center";
    Alignment[Alignment["Justify"] = 3] = "Justify"; // 水平两边对齐
})(Alignment || (Alignment = {}));
var VerticalAlignment;
(function (VerticalAlignment) {
    VerticalAlignment[VerticalAlignment["Top"] = 0] = "Top";
    VerticalAlignment[VerticalAlignment["Center"] = 1] = "Center";
    VerticalAlignment[VerticalAlignment["Bottom"] = 2] = "Bottom";
})(VerticalAlignment || (VerticalAlignment = {}));
var FillType;
(function (FillType) {
    FillType[FillType["PureColor"] = 0] = "PureColor";
    FillType[FillType["linearGradient"] = 1] = "linearGradient";
    FillType[FillType["radialGradient"] = 2] = "radialGradient";
    FillType[FillType["angularGradient"] = 3] = "angularGradient";
})(FillType || (FillType = {}));
/**
 * 边框位置
 */
var BorderPosition;
(function (BorderPosition) {
    BorderPosition[BorderPosition["Center"] = 0] = "Center";
    BorderPosition[BorderPosition["Inside"] = 1] = "Inside";
    BorderPosition[BorderPosition["Outside"] = 2] = "Outside";
})(BorderPosition || (BorderPosition = {}));
/**
 * 阴影类型
 */
var ShadowType;
(function (ShadowType) {
    ShadowType[ShadowType["Inner"] = 0] = "Inner";
    ShadowType[ShadowType["Normal"] = 1] = "Normal";
})(ShadowType || (ShadowType = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/PanelOptions.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/PanelOptions.js ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CodeType = exports.ColorFormat = exports.Unit = exports.AndroidScale = exports.IOSScale = exports.WebScale = void 0;
var WebScale;
(function (WebScale) {
    WebScale[WebScale["Points"] = 1] = "Points";
    WebScale[WebScale["Retina"] = 2] = "Retina";
})(WebScale = exports.WebScale || (exports.WebScale = {}));
var IOSScale;
(function (IOSScale) {
    IOSScale[IOSScale["Points"] = 1] = "Points";
    IOSScale[IOSScale["Retina"] = 2] = "Retina";
    IOSScale[IOSScale["RetinaHD"] = 3] = "RetinaHD";
})(IOSScale = exports.IOSScale || (exports.IOSScale = {}));
var AndroidScale;
(function (AndroidScale) {
    AndroidScale[AndroidScale["MDPI"] = 1] = "MDPI";
    AndroidScale[AndroidScale["HDPI"] = 1.5] = "HDPI";
    AndroidScale[AndroidScale["XHDPI"] = 2] = "XHDPI";
    AndroidScale[AndroidScale["XXHDPI"] = 3] = "XXHDPI";
    AndroidScale[AndroidScale["XXXHDPI"] = 4] = "XXXHDPI";
})(AndroidScale = exports.AndroidScale || (exports.AndroidScale = {}));
var Unit;
(function (Unit) {
    Unit["IOS"] = "pt";
    Unit["Android"] = "dp";
    Unit["WebPx"] = "px";
    Unit["WebRem"] = "rem";
    Unit["Weapp"] = "rpx";
    Unit["ReactNative"] = "";
})(Unit = exports.Unit || (exports.Unit = {}));
var ColorFormat;
(function (ColorFormat) {
    ColorFormat["HEX"] = "hex";
    ColorFormat["AHEX"] = "ahex";
    ColorFormat["HEXA"] = "hexa";
    ColorFormat["RGBA"] = "rgba";
    ColorFormat["HSLA"] = "hsla";
})(ColorFormat = exports.ColorFormat || (exports.ColorFormat = {}));
var CodeType;
(function (CodeType) {
    CodeType["IOS"] = "ios";
    CodeType["Android"] = "android";
    CodeType["WebPx"] = "webpx";
    CodeType["WebRem"] = "webrem";
    CodeType["Weapp"] = "weapp";
    CodeType["ReactNative"] = "reactnative";
})(CodeType = exports.CodeType || (exports.CodeType = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKAttributedString.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKAttributedString.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description 段落文本分布方式
 * @enum {number}
 */
var SKAlignment;
(function (SKAlignment) {
    SKAlignment[SKAlignment["Left"] = 0] = "Left";
    SKAlignment[SKAlignment["Right"] = 1] = "Right";
    SKAlignment[SKAlignment["Center"] = 2] = "Center";
    SKAlignment[SKAlignment["Justify"] = 3] = "Justify";
})(SKAlignment || (SKAlignment = {}));
var SKTextTransformAttribute;
(function (SKTextTransformAttribute) {
    SKTextTransformAttribute[SKTextTransformAttribute["Normal"] = 0] = "Normal";
    SKTextTransformAttribute[SKTextTransformAttribute["LowerCase"] = 1] = "LowerCase";
    SKTextTransformAttribute[SKTextTransformAttribute["UpperCase"] = 2] = "UpperCase"; // 转成小写
})(SKTextTransformAttribute || (SKTextTransformAttribute = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKColor.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKColor.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKFrame.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKFrame.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKImage.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKImage.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKBlur.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKBlur.js ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKBorders.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKBorders.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description Sketch 边框位置
 * @enum {number}
 */
var SKBorderPosition;
(function (SKBorderPosition) {
    SKBorderPosition[SKBorderPosition["Inside"] = 0] = "Inside";
    SKBorderPosition[SKBorderPosition["Center"] = 1] = "Center";
    SKBorderPosition[SKBorderPosition["Outside"] = 2] = "Outside"; // 外边框
})(SKBorderPosition || (SKBorderPosition = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKContextSettings.js":
/*!*********************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKContextSettings.js ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKFills.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKFills.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description 渐变类型
 * @enum {number}
 */
var SKGradientType;
(function (SKGradientType) {
    SKGradientType[SKGradientType["Linear"] = 0] = "Linear";
    SKGradientType[SKGradientType["Radial"] = 1] = "Radial";
    SKGradientType[SKGradientType["Angular"] = 2] = "Angular"; // 环形渐变
})(SKGradientType || (SKGradientType = {}));
/**
 * @description 填充类型
 * @enum {number}
 */
var SKFillType;
(function (SKFillType) {
    SKFillType[SKFillType["Color"] = 0] = "Color";
    SKFillType[SKFillType["Gradient"] = 1] = "Gradient";
    SKFillType[SKFillType["Image"] = 4] = "Image";
    SKFillType[SKFillType["Texture"] = 5] = "Texture"; // 纹理效果填充
})(SKFillType || (SKFillType = {}));
/**
 * @description 图片填充模式类型
 * @enum {number}
 */
var SKPatternFillType;
(function (SKPatternFillType) {
    SKPatternFillType[SKPatternFillType["Mask_Tile"] = 0] = "Mask_Tile";
    SKPatternFillType[SKPatternFillType["Mask_Fill"] = 1] = "Mask_Fill";
    SKPatternFillType[SKPatternFillType["Mask_Stretch"] = 2] = "Mask_Stretch";
    SKPatternFillType[SKPatternFillType["Mask_Fit"] = 3] = "Mask_Fit"; // 包含(contain)
})(SKPatternFillType || (SKPatternFillType = {}));


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKShadows.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKShadows.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/index.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/index.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
// 类型导出
__exportStar(__webpack_require__(/*! ./SKBorders */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKBorders.js"), exports);
__exportStar(__webpack_require__(/*! ./SKContextSettings */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKContextSettings.js"), exports);
__exportStar(__webpack_require__(/*! ./SKFills */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKFills.js"), exports);
__exportStar(__webpack_require__(/*! ./SKBlur */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKBlur.js"), exports);
__exportStar(__webpack_require__(/*! ./SKShadows */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/SKShadows.js"), exports);


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/common.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/common.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),

/***/ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/index.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
// 类型导出
__exportStar(__webpack_require__(/*! ./common */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/common.js"), exports);
__exportStar(__webpack_require__(/*! ./SKColor */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKColor.js"), exports);
__exportStar(__webpack_require__(/*! ./SKFrame */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKFrame.js"), exports);
__exportStar(__webpack_require__(/*! ./SKStyle */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKStyle/index.js"), exports);
__exportStar(__webpack_require__(/*! ./SKImage */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKImage.js"), exports);
__exportStar(__webpack_require__(/*! ./SKAttributedString */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/SKAttributedString.js"), exports);
__exportStar(__webpack_require__(/*! ./Panel */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/Panel.js"), exports);
__exportStar(__webpack_require__(/*! ./PanelOptions */ "./node_modules/@wubafe/picasso-parse/dist/sketch-dsl/src/PanelOptions.js"), exports);


/***/ }),

/***/ "./src/handleImage/handleJudge/isOval.js":
/*!***********************************************!*\
  !*** ./src/handleImage/handleJudge/isOval.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// 判断是否是正圆
var isOval = function isOval(layer) {
  var points = layer.points;

  if (layer.points && layer.points.length !== 4) {
    return false;
  }

  for (var i = 0; i < points.length; i++) {
    var _points$i = points[i],
        pointType = _points$i.pointType,
        curveFrom = _points$i.curveFrom,
        curveTo = _points$i.curveTo,
        point = _points$i.point; // 非镜像属于不规则圆形

    if (pointType !== 'Mirrored') {
      return false;
    }

    if (i == 0 || i == 2) {
      if (curveFrom.y !== curveTo.y || curveTo.y !== point.y) {
        return false;
      }
    } else if (i == 1 || i == 3) {
      if (curveFrom.x !== curveTo.x || curveTo.x !== point.x) {
        return false;
      }
    }
  } // 判断是否是正圆


  if (Math.abs(layer.frame.width - layer.frame.height) >= 0.1) {
    // 表示是一个椭圆
    return false;
  }

  return true;
};

/* harmony default export */ __webpack_exports__["default"] = (isOval);

/***/ }),

/***/ "./src/handleImage/handleJudge/isRect.js":
/*!***********************************************!*\
  !*** ./src/handleImage/handleJudge/isRect.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _twoPointsAngle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./twoPointsAngle */ "./src/handleImage/handleJudge/twoPointsAngle.js");

/**
 * 获取夹角
 *
 * @param {Object} startPoint 起始点
 * @param {Object} midPoint 焦点
 * @param {Object} endPoint 结束点
 * @returns
 */

var getAngle = function getAngle(startPoint, midPoint, endPoint) {
  return Object(_twoPointsAngle__WEBPACK_IMPORTED_MODULE_0__["default"])(midPoint.x, midPoint.y, endPoint.x, endPoint.y) - Object(_twoPointsAngle__WEBPACK_IMPORTED_MODULE_0__["default"])(startPoint.x, startPoint.y, midPoint.x, midPoint.y);
};
/**
 * 判断是的为矩形
 *
 * @param {Array} pointArr 4个点数据组信息
 * @returns
 */


/* harmony default export */ __webpack_exports__["default"] = (function (pointArr) {
  /**
   * 四边形4个点顺时针依次为 A,B,C,D
   * {
   *   x:0,
   *   y:0
   * }
   */
  var pointA = pointArr[0].point;
  var pointB = pointArr[1].point;
  var pointC = pointArr[2].point;
  var pointD = pointArr[3].point; // 计算4个角度对应的点

  var anglePointArr = [[pointA, pointB, pointC], [pointB, pointC, pointD], [pointC, pointD, pointA], [pointD, pointA, pointB]];

  for (var i = 0; i < anglePointArr.length; i++) {
    if (Math.abs(Math.abs(getAngle(anglePointArr[i][0], anglePointArr[i][1], anglePointArr[i][2])) - Math.PI / 2) > 0.02 && Math.abs(Math.abs(getAngle(anglePointArr[i][0], anglePointArr[i][1], anglePointArr[i][2])) - Math.PI * 1.5) > 0.02) {
      return false;
    }
  }

  return true;
});

/***/ }),

/***/ "./src/handleImage/handleJudge/isRectangle.js":
/*!****************************************************!*\
  !*** ./src/handleImage/handleJudge/isRectangle.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _isRect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isRect */ "./src/handleImage/handleJudge/isRect.js");
 // 判断是否是正规的矩形

var isRectangle = function isRectangle(layer) {
  var points = layer.points;

  if (layer.points && layer.points.length != 4) {
    return false;
  }

  for (var i = 0; i < points.length; i++) {
    var pointType = points[i].pointType; // 非直点属于不规则矩形

    if (pointType !== 'Straight') {
      return false;
    }
  }

  return Object(_isRect__WEBPACK_IMPORTED_MODULE_0__["default"])(points);
};

/* harmony default export */ __webpack_exports__["default"] = (isRectangle);

/***/ }),

/***/ "./src/handleImage/handleJudge/isRegularBorder.js":
/*!********************************************************!*\
  !*** ./src/handleImage/handleJudge/isRegularBorder.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// 判断是否有边框
var isRegularBorder = function isRegularBorder(layer) {
  var _layer$style;

  if ((_layer$style = layer.style) !== null && _layer$style !== void 0 && _layer$style.borders && layer.style.borders.length) {
    // 获取激活的所有边框
    var borderList = layer.style.borders.filter(function (item) {
      return item.enabled;
    }); // 多层边框

    if (borderList.length > 1) {
      return false;
    } // fillType: Color 纯色填充
    // fillType: Gradient 线性渐变填充|径向纯色填充|锥形渐变


    if (borderList.length === 1 && borderList[0].fillType !== 'Color') {
      // 单层边框
      return false;
    }

    return true;
  }

  return true;
};

/* harmony default export */ __webpack_exports__["default"] = (isRegularBorder);

/***/ }),

/***/ "./src/handleImage/handleJudge/isRegularShadow.js":
/*!********************************************************!*\
  !*** ./src/handleImage/handleJudge/isRegularShadow.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * 判断是否为规则阴影
 * @param {*} layer
 */
var isRegularShadow = function isRegularShadow(layer) {
  var shadowList = [];

  if (layer.style && layer.style.shadows) {
    // 查找所有可用的阴影
    layer.style.shadows.map(function (item) {
      if (item.enabled) {
        shadowList.push(item);
      }
    });
  }

  if (layer.style && layer.style.innerShadows) {
    layer.style.innerShadows.map(function (item) {
      if (item.enabled) {
        shadowList.push(item);
      }
    });
  }

  if (layer.type === 'Text') {
    // 文本具有阴影则导出图片
    return shadowList.length === 0;
  }

  return true;
};

/* harmony default export */ __webpack_exports__["default"] = (isRegularShadow);

/***/ }),

/***/ "./src/handleImage/handleJudge/isSupportedFill.js":
/*!********************************************************!*\
  !*** ./src/handleImage/handleJudge/isSupportedFill.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// TBD 需要改造
var isSupportedFill = function isSupportedFill(layer) {
  var _layer$style, _layer$style2, _layer$style2$fills;

  if (!(layer.type === 'Artboard') && layer.style && Array.isArray((_layer$style = layer.style) === null || _layer$style === void 0 ? void 0 : _layer$style.fills) && (_layer$style2 = layer.style) !== null && _layer$style2 !== void 0 && (_layer$style2$fills = _layer$style2.fills) !== null && _layer$style2$fills !== void 0 && _layer$style2$fills.length && layer.style.fills.filter(function (item) {
    return item.enabled;
  }).length > 0) {
    // 处理填充 fills,fills是数组，只支持单个情况,处理成背景色, 文本的背景另外设置
    // 填充类型
    // fillStyle.fillType
    //       Color  纯色
    //       Gradient 渐变色
    //       Pattern 填充图
    // fillStyle.fillType fillStyle.gradient.gradientType
    //        Gradient  Linear   线性渐变色  完全css解析
    //        Gradient  Radial   径向渐变色  1.圆形或者椭圆但是没有倾斜角度的 css解析 2.导出为图片
    //        Gradient  Angular  直角渐变色  css实验属性暂时不支持 ，导出为图片
    var fills = layer.style.fills.filter(function (item) {
      return item.enabled;
    });

    if (fills.length >= 2) {
      return false;
    }

    var fillStyle = fills[fills.length - 1];
    var fillType = fillStyle.fillType;

    if (layer.type === 'Text' && fillType != 'Color') {
      return false;
    }

    if (fillType == 'Pattern') {
      return false;
    }

    if (fillType == 'Gradient' && fillStyle.gradient) {
      var gradient = fillStyle.gradient;
      var frame = layer.frame;
      var gradientType = gradient.gradientType;

      if (gradientType === 'Radial') {
        // 径向渐变
        var startPoint = gradient.from;
        var startX = startPoint.x * frame.width;
        var startY = startPoint.y * frame.height;
        var endPoint = gradient.to;
        var endX = endPoint.x * frame.width;
        var endY = endPoint.y * frame.height;

        if (fillStyle.gradient.elipseLength > 0) {
          // 椭圆渐变
          if (!(Math.abs(endY - startY) < 1 || Math.abs(endX - startX) < 1)) {
            // 可解析
            // 如果倾斜则 导出该图层
            return false;
          }
        }
      } else if (gradientType === 'Angular') {
        // 直角渐变色
        // 导出该图层
        return false;
      }
    }
  }

  return true;
};

/* harmony default export */ __webpack_exports__["default"] = (isSupportedFill);

/***/ }),

/***/ "./src/handleImage/handleJudge/twoPointsAngle.js":
/*!*******************************************************!*\
  !*** ./src/handleImage/handleJudge/twoPointsAngle.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * 依据两点坐标计算两点与原点之间连线的夹角
 *
 * @param {*} startX 第一个点X轴坐标
 * @param {*} startY 第一个点Y轴坐标
 * @param {*} endX 第二个点X轴坐标
 * @param {*} endY 第二个点Y轴坐标
 * @returns
 */
/* harmony default export */ __webpack_exports__["default"] = (function (startX, startY, endX, endY) {
  var x = endX - startX;
  var y = endY - startY;

  if (x > 0 && y == 0) {
    return Math.PI * 0.5;
  }

  if (x < 0 && y == 0) {
    return Math.PI * 1.5;
  }

  if (y > 0 && x == 0) {
    return 0;
  }

  if (y < 0 && x == 0) {
    return Math.PI;
  }

  if (x >= 0 && y >= 0) {
    return Math.atan(x / y);
  }

  if (x >= 0 && y < 0) {
    return Math.PI + Math.atan(x / y);
  }

  if (x < 0 && y > 0) {
    return 2 * Math.PI + Math.atan(x / y);
  }

  if (x < 0 && y <= 0) {
    return Math.PI + Math.atan(x / y);
  }
});

/***/ }),

/***/ "./src/handleImage/index.js":
/*!**********************************!*\
  !*** ./src/handleImage/index.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handleJudge_isOval__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./handleJudge/isOval */ "./src/handleImage/handleJudge/isOval.js");
/* harmony import */ var _handleJudge_isRectangle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./handleJudge/isRectangle */ "./src/handleImage/handleJudge/isRectangle.js");
/* harmony import */ var _handleJudge_isRegularShadow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./handleJudge/isRegularShadow */ "./src/handleImage/handleJudge/isRegularShadow.js");
/* harmony import */ var _handleJudge_isRegularBorder__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./handleJudge/isRegularBorder */ "./src/handleImage/handleJudge/isRegularBorder.js");
/* harmony import */ var _handleJudge_isSupportedFill__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./handleJudge/isSupportedFill */ "./src/handleImage/handleJudge/isSupportedFill.js");






/**
 * 计算不规则图形
 *
 * 如果一个组中存在不规则的 mask则 这个组将会做成一张切片
 *
 */

/* harmony default export */ __webpack_exports__["default"] = (function (layer) {
  var _layer$style, _layer$style2, _layer$style2$blur, _layer$style3;

  // 如果组上有阴影(内阴影或者外阴影)，则标记为导出的图形
  if (layer.type === 'Group' && (_layer$style = layer.style) !== null && _layer$style !== void 0 && _layer$style.shadows && [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(layer.style.innerShadows), _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(layer.style.shadows)).find(function (item) {
    return item.enabled;
  })) {
    return true;
  } // 如果图层是图片，则导出为图片


  if (['Image', 'Shape'] === 'Image') {
    return true;
  } // 不支持的填充，导出为图片


  if (!Object(_handleJudge_isSupportedFill__WEBPACK_IMPORTED_MODULE_5__["default"])(layer)) {
    return true;
  } // 不规则边框则导出当前图层


  if (!Object(_handleJudge_isRegularBorder__WEBPACK_IMPORTED_MODULE_4__["default"])(layer)) {
    return true;
  } // 图片、矢量 则直接导出为图片


  if (['Image', 'Shape'].includes(layer.type)) {
    return true;
  } // 不规则图形、矢量图形 则将整个组导出为图片


  if (['Star', 'Triangle', 'ShapeGroup', 'Polygon'].includes(layer.shapeType)) {
    return true;
  } // Line&Array 线和箭头


  if (layer.type === 'ShapePath' && layer.shapeType === 'Custom' && Array.isArray(layer.points)) {
    // 大于4个点的，导出为图片
    if (layer.points.length > 4) {
      return true;
    }

    for (var i = 0; i < layer.points.length; i++) {
      var pointType = layer.points[i].pointType; // 非直点属于不规则矩形

      if (pointType !== 'Straight') {
        return true;
      }
    }
  } // 模糊效果直接导出


  if ((_layer$style2 = layer.style) !== null && _layer$style2 !== void 0 && (_layer$style2$blur = _layer$style2.blur) !== null && _layer$style2$blur !== void 0 && _layer$style2$blur.enabled) {
    return true;
  } // 有矢量点的时候


  if (layer.style && layer.points) {
    // 排除 Mask 的情况
    if (layer.shapeType === 'Oval') {
      return !Object(_handleJudge_isOval__WEBPACK_IMPORTED_MODULE_1__["default"])(layer);
    }

    if (layer.shapeType === 'Rectangle') {
      return !Object(_handleJudge_isRectangle__WEBPACK_IMPORTED_MODULE_2__["default"])(layer);
    }
  } // 文本


  if (layer.type === 'Text' && (_layer$style3 = layer.style) !== null && _layer$style3 !== void 0 && _layer$style3.borders) {
    var _layer$style4, _layer$style4$borders;

    // 如果文本有可用的border也导出图片
    return (_layer$style4 = layer.style) === null || _layer$style4 === void 0 ? void 0 : (_layer$style4$borders = _layer$style4.borders) === null || _layer$style4$borders === void 0 ? void 0 : _layer$style4$borders.find(function (border) {
      return border.enabled;
    });
  } // 不规则阴影，导出为图片


  if (!Object(_handleJudge_isRegularShadow__WEBPACK_IMPORTED_MODULE_3__["default"])(layer)) {
    return true;
  }

  return false;
});

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! exports provided: parseSelectArtboard, parseAllArtboard, help */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseSelectArtboard", function() { return parseSelectArtboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseAllArtboard", function() { return parseAllArtboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "help", function() { return help; });
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _parseArtboard_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./parseArtboard/index */ "./src/parseArtboard/index.js");




var _ = function _(str) {
  return str.replace(/\%\@/gi, '');
};
/**
 * 获取解析结果存放路径
 * @param {String} fileName sketch设计稿名称作为生成代码存放根文件夹
 */


var getSavePath = function getSavePath(fileName) {
  // 打开保存面板
  var savePanel = NSSavePanel.savePanel();
  savePanel.setTitle(_("Export code"));
  savePanel.setNameFieldLabel(_("Export to:"));
  savePanel.setPrompt(_("Export"));
  savePanel.setCanCreateDirectories(true);
  savePanel.setNameFieldStringValue(fileName);

  if (savePanel.runModal() != NSOKButton) {
    return '';
  }

  return savePanel.URL().path();
};

var parseArtboard = function parseArtboard(type) {
  var document = sketch_dom__WEBPACK_IMPORTED_MODULE_1__["Document"].getSelectedDocument(); // 获取不到sketch源文件

  if (!document.path) {
    return sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message('请先保存文件，再进行解析！');
  }

  var fileName = document.sketchObject.displayName().stringByDeletingPathExtension(); // console.log('fileName', fileName);
  // 代码存储根目录

  var rootPath = getSavePath(fileName); // console.log('rootPath', rootPath);

  if (rootPath === '') {
    return sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message('取消解析');
  }

  sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message("\u5F53\u524D\u8FDB\u5EA6\uFF1A0%");
  setTimeout(function () {
    Object(_parseArtboard_index__WEBPACK_IMPORTED_MODULE_2__["parseDocument"])(type, rootPath, function (progress) {
      // console.log('当前进度：', progress);
      sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message("\u5F53\u524D\u8FDB\u5EA6\uFF1A".concat(+(progress * 100).toFixed(4), "%"));
    }).then(function (res) {
      // console.log('解析完成：', res);
      sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message('解析完成！'); // 解析完成，打开结果文件目录

      NSWorkspace.sharedWorkspace().activateFileViewerSelectingURLs([NSURL.fileURLWithPath("".concat(rootPath, "/").concat(res[0] && res[0].name))]);
    }).catch(function (err) {
      console.log('解析失败', err);
      sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message('解析失败！');
    });
  }, 0);
};

var parseSelectArtboard = function parseSelectArtboard() {
  parseArtboard(1);
};
var parseAllArtboard = function parseAllArtboard() {
  parseArtboard(2);
};
var help = function help() {
  NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString('https://github.com/wuba/Picasso'));
};

/***/ }),

/***/ "./src/parseArtboard/common.js":
/*!*************************************!*\
  !*** ./src/parseArtboard/common.js ***!
  \*************************************/
/*! exports provided: handleFilePath, isTheClass, toJSString, removeLayer, find, exportImage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handleFilePath", function() { return handleFilePath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isTheClass", function() { return isTheClass; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toJSString", function() { return toJSString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeLayer", function() { return removeLayer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "find", function() { return find; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportImage", function() { return exportImage; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
 // 路径处理, 如果不处理中文路径会报错

var handleFilePath = function handleFilePath(filePath) {
  return NSURL.URLWithString(String(NSString.stringWithString(filePath).stringByExpandingTildeInPath()).replace(/ /g, '%20'));
};
/**
 * 判断是否为某个sketch类型
 * @param {*} layer
 * @param {*} theClass
 */

var isTheClass = function isTheClass(layer, theClass) {
  if (!layer) return false;
  var klass = layer.class();
  return klass === theClass;
};
var toJSString = function toJSString(str) {
  return str.toString();
};
/**
 * 删除某个图层
 * @param {*} layer
 */

var removeLayer = function removeLayer(layer) {
  var container = layer.parentGroup();
  if (container) container.removeLayer(layer);
};
/**
 * 查找图层
 * @param {*} format 
 * @param {*} container 
 * @param {*} returnArray 
 */

var find = function find(format, container, returnArray) {
  if (!format || !format.key || !format.match) {
    return false;
  }

  var predicate = NSPredicate.predicateWithFormat(format.key, format.match);
  var items;

  if (container.pages) {
    items = container.pages();
  } else if (isTheClass(container, MSSharedStyleContainer) || isTheClass(container, MSSharedTextStyleContainer)) {
    items = container.objectsSortedByName();
  } else if (container.children) {
    items = container.children();
  } else {
    items = container;
  }

  var queryResult = items.filteredArrayUsingPredicate(predicate);
  if (returnArray) return queryResult;

  if (queryResult.count() == 1) {
    return queryResult[0];
  }

  if (queryResult.count() > 0) {
    return queryResult;
  }

  return false;
};
/**
 * 导出图片
 */

var exportImage = function exportImage(layer, sliceSize, rootPath) {
  var trimmed = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
  var groupContentsOnly = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : true;
  var scale = 1; // 根据选择尺寸导出最大的满足需求的图片尺寸

  if ([1, 1.5, 2, 3, 4].includes(+sliceSize)) {
    scale = Math.floor(4 / sliceSize);
  }

  var option = {
    scales: scale,
    formats: 'png',
    trimmed: trimmed,
    // 剪切图片透明无效区域
    'use-id-for-name': true,
    'group-contents-only': groupContentsOnly,
    'save-for-web': true,
    output: rootPath + '/images'
  };

  try {
    sketch__WEBPACK_IMPORTED_MODULE_0___default.a.export(layer, option);
    return "".concat(layer.id).concat(+scale === 1 ? '' : "@".concat(scale, "x"), ".png");
  } catch (err) {
    // console.log('图片导出失败,图层信息：', layer.id, layer.type, err, layer.name);
    return '';
  }
};

/***/ }),

/***/ "./src/parseArtboard/getImageLayers.js":
/*!*********************************************!*\
  !*** ./src/parseArtboard/getImageLayers.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./common */ "./src/parseArtboard/common.js");
/* harmony import */ var _handleImage_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../handleImage/index */ "./src/handleImage/index.js");



 // 递归查找需求导出为图片的图层

var _getImageLayers = function _getImageLayers(layers, symbolInstanceIds, fontMap, symbolGroups, codeImageMap, rootPath, sliceSize) {
  var _exportLayers = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : [];

  for (var i = 0; i < layers.length; i++) {
    var _layer$exportFormats;

    var layer = layers[i];
    var SLayer = layer.sketchObject; // 字体处理；存储

    if (!fontMap[layer.id] && layer.type === 'Text') {
      var _layer$sketchObject;

      /* eslint-disable */
      fontMap[layer.id] = new String((_layer$sketchObject = layer.sketchObject) === null || _layer$sketchObject === void 0 ? void 0 : _layer$sketchObject.fontPostscriptName()).toString();
      /* eslint-disable */
    } // 切片处理


    if (!layer.hidden && (layer.type === 'Slice' || layer.type !== 'Artboard' && layer.type !== 'Shape' && ((_layer$exportFormats = layer.exportFormats) === null || _layer$exportFormats === void 0 ? void 0 : _layer$exportFormats.length) > 0)) {
      try {
        var trimmed = true;
        var groupContentsOnly = true;
        var layerJson = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.export(layer, {
          formats: 'json',
          output: false
        });

        if (layer.type === 'Slice') {
          var _layerJson$exportOpti = layerJson.exportOptions,
              shouldTrim = _layerJson$exportOpti.shouldTrim,
              layerOptions = _layerJson$exportOpti.layerOptions;
          trimmed = shouldTrim;
          groupContentsOnly = +layerOptions === 2;
        }

        var imageLocalPath = Object(_common__WEBPACK_IMPORTED_MODULE_2__["exportImage"])(layer, sliceSize, rootPath, trimmed, groupContentsOnly);

        _exportLayers.push({
          id: layer.id,
          imageLocalPath: imageLocalPath
        });
      } catch (error) {// console.log('图片导出错误', layer.id, error);
      } // 代码模式导出图片

    } else if (!layer.hidden) {
      // console.log('代码模式切片');
      // 判断是否需要做切片处理
      if (Object(_handleImage_index__WEBPACK_IMPORTED_MODULE_3__["default"])(layer)) {
        // 进行切片
        var sliceLayer = MSSliceLayer.sliceLayerFromLayer(SLayer); // 获取切片尺寸

        var sliceFrame = sliceLayer.frame(); // 注意：导出当前图层

        var _imageLocalPath = Object(_common__WEBPACK_IMPORTED_MODULE_2__["exportImage"])(layer, sliceSize, rootPath); // 存储切片信息


        codeImageMap[layer.id] = {
          x: sliceFrame.left(),
          y: sliceFrame.top(),
          width: sliceFrame.width(),
          height: sliceFrame.height()
        };

        _exportLayers.push({
          id: layer.id,
          imageLocalPath: _imageLocalPath
        });

        Object(_common__WEBPACK_IMPORTED_MODULE_2__["removeLayer"])(sliceLayer);
      }
    } // symbol


    if (layer.type === 'SymbolInstance' && SLayer.symbolMaster() && SLayer.symbolMaster().children() && SLayer.symbolMaster().children().count() > 1) {
      var symbolChildren = SLayer.symbolMaster().children();
      var tempSymbol = SLayer.duplicate();
      var tempGroup = tempSymbol.detachStylesAndReplaceWithGroupRecursively(true);
      var tempSymbolLayers = tempGroup.children().objectEnumerator();
      var overrides = SLayer.overrides();
      var idx = 0;
      var tempSymbolLayer = void 0;
      overrides = overrides ? overrides.objectForKey(0) : undefined;
      /* eslint-disable */

      while (tempSymbolLayer = tempSymbolLayers.nextObject()) {
        /* eslint-disable */
        if (Object(_common__WEBPACK_IMPORTED_MODULE_2__["isTheClass"])(tempSymbolLayer, MSSymbolInstance)) {
          var symbolMasterObjectID = Object(_common__WEBPACK_IMPORTED_MODULE_2__["toJSString"])(symbolChildren[idx].objectID());

          if (overrides && overrides[symbolMasterObjectID] && !!overrides[symbolMasterObjectID].symbolID) {
            var changeSymbol = Object(_common__WEBPACK_IMPORTED_MODULE_2__["find"])({
              key: '(symbolID != NULL) && (symbolID == %@)',
              match: Object(_common__WEBPACK_IMPORTED_MODULE_2__["toJSString"])(overrides[symbolMasterObjectID].symbolID)
            }, document.documentData().allSymbols());

            if (changeSymbol) {
              tempSymbolLayer.changeInstanceToSymbol(changeSymbol);
            } else {
              tempSymbolLayer = undefined;
            }
          }
        }

        idx++;
      }

      symbolInstanceIds.push(layer.id);
      symbolGroups.push(tempGroup);

      if (Array.isArray(sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.fromNative(tempGroup).layers)) {
        _getImageLayers(sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.fromNative(tempGroup).layers, symbolInstanceIds, fontMap, symbolGroups, codeImageMap, rootPath, sliceSize, _exportLayers);
      }

      Object(_common__WEBPACK_IMPORTED_MODULE_2__["removeLayer"])(tempGroup);
    } else if (Array.isArray(layer.layers)) {
      _getImageLayers(layer.layers, symbolInstanceIds, fontMap, symbolGroups, codeImageMap, rootPath, sliceSize, _exportLayers);
    }
  }

  return _exportLayers;
};

/* harmony default export */ __webpack_exports__["default"] = (_getImageLayers);

/***/ }),

/***/ "./src/parseArtboard/handleCode/handleWebCode.js":
/*!*******************************************************!*\
  !*** ./src/parseArtboard/handleCode/handleWebCode.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @skpm/fs */ "./node_modules/@skpm/fs/index.js");
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wubafe/picasso-parse */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/index.js");
/* harmony import */ var _wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _remjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./remjs */ "./src/parseArtboard/handleCode/remjs.js");
/* harmony import */ var _resetcss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./resetcss */ "./src/parseArtboard/handleCode/resetcss.js");




/* harmony default export */ __webpack_exports__["default"] = (function (rootPath, codeDSL) {
  var pageWidth = codeDSL.structure.width;
  var codePath = "".concat(rootPath, "/").concat(codeDSL.name.replace(/\//g, '／')); // 生成代码片段

  var code = Object(_wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_1__["picassoCode"])([codeDSL], pageWidth, _wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_1__["CodeType"].WebPx);

  if (!_skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.existsSync(codePath)) {
    _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.mkdirSync(codePath);
  }

  var title = codeDSL.name; // html mobile模版

  var _html_mobile = "\n<!DOCTYPE html>\n<html lang=\"en\">\n    <head>\n        <meta charset=\"UTF-8\">\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n        <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\n        <link rel=\"stylesheet\" href=\"./reset.css\">\n        <link rel=\"stylesheet\" href=\"./index.css\">\n        <script src=\"./rem.js\"></script>\n        <title>".concat(title, "</title>\n    </head>\n    <body>\n").concat(code.html, "\n    </body>\n</html>"); // html pc模版


  var _html_pc = "\n<!DOCTYPE html>\n<html lang=\"en\">\n    <head>\n        <meta charset=\"UTF-8\">\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n        <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\n        <link rel=\"stylesheet\" href=\"./reset.css\">\n        <link rel=\"stylesheet\" href=\"./index.css\">\n        <title>".concat(title, "</title>\n    </head>\n    <body>\n").concat(code.html, "\n    </body>\n</html>");

  var _html = [375, 750].includes(pageWidth) ? _html_mobile : _html_pc;

  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(codePath, "/index.html"), _html);
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(codePath, "/index.scss"), code.scss);
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(codePath, "/index.css"), code.css);
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(codePath, "/reset.css"), _resetcss__WEBPACK_IMPORTED_MODULE_3__["default"]);

  if ([375, 750].includes(pageWidth)) {
    _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(codePath, "/rem.js"), _remjs__WEBPACK_IMPORTED_MODULE_2__["default"]);
  }
});

/***/ }),

/***/ "./src/parseArtboard/handleCode/remjs.js":
/*!***********************************************!*\
  !*** ./src/parseArtboard/handleCode/remjs.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* eslint-disable */
/* harmony default export */ __webpack_exports__["default"] = ("(function (e, t) {\n    function n() {\n        var t = r.getBoundingClientRect().width,\n            n = t / 7.5;\n        r.style.fontSize = n + \"px\", d.rem = e.rem = n\n    }\n    var i, o = e.document,\n        r = o.documentElement,\n        a = 0,\n        d = t.flexible || (t.flexible = {}),\n        s = e.navigator.appVersion.match(/iphone/gi),\n        m = e.devicePixelRatio;\n    a = s ? m >= 3 && (!a || a >= 3) ? 3 : m >= 2 && (!a || a >= 2) ? 2 : 1 : 1, r.setAttribute(\"data-dpr\", a), \"complete\" === o.readyState ? o.body.style.fontSize = \"12px\" : o.addEventListener(\"DOMContentLoaded\", function () {\n        o.body.style.fontSize = \"12px\"\n    }, !1);\n    var p = \"onorientationchange\" in window ? \"orientationchange\" : \"resize\";\n    e.addEventListener(p, function () {\n        clearTimeout(i), i = setTimeout(n, 300)\n    }, !1), e.addEventListener(\"pageshow\", function (e) {\n        e.persisted && (clearTimeout(i), i = setTimeout(n, 300))\n    }, !1), n(), d.dpr = e.dpr = a, d.refreshRem = n, d.rem2px = function (e) {\n        var t = parseFloat(e) * this.rem;\n        return \"string\" == typeof e && e.match(/rem$/) && (t += \"px\"), t\n    }, d.px2rem = function (e) {\n        var t = parseFloat(e) / this.rem;\n        return \"string\" == typeof e && e.match(/px$/) && (t += \"rem\"), t\n    }\n})(window, window.lib || (window.lib = {}));\n");

/***/ }),

/***/ "./src/parseArtboard/handleCode/resetcss.js":
/*!**************************************************!*\
  !*** ./src/parseArtboard/handleCode/resetcss.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\n\n  * {\n    user-select: none;\n  }\n\n  input,\n  textarea {\n    user-select: text;\n  }\n\n  /* \u53BB\u9664\u624B\u673A\u9ED8\u8BA4\u6DFB\u52A0\u7684\u9EC4\u8272\u80CC\u666F */\ninput {\n  -webkit-appearance: none;\n  -webkit-tap-highlight-color: transparent;\n}\n\n  input {\n    background: none;\n    outline: none;\n    border: 0px;\n    border-radius: 0;\n  }\n\n  html,\n  body,\n  div,\n  span,\n  object,\n  iframe,\n  h1,\n  h2,\n  h3,\n  h4,\n  h5,\n  h6,\n  p,\n  blockquote,\n  pre,\n  abbr,\n  address,\n  cite,\n  code,\n  del,\n  dfn,\n  em,\n  img,\n  ins,\n  kbd,\n  q,\n  samp,\n  small,\n  strong,\n  sub,\n  sup,\n  var,\n  b,\n  i,\n  dl,\n  dt,\n  dd,\n  ol,\n  ul,\n  li,\n  fieldset,\n  form,\n  label,\n  legend,\n  table,\n  caption,\n  tbody,\n  tfoot,\n  thead,\n  tr,\n  th,\n  td,\n  article,\n  aside,\n  canvas,\n  details,\n  figcaption,\n  figure,\n  footer,\n  header,\n  hgroup,\n  menu,\n  nav,\n  section,\n  summary,\n  time,\n  mark,\n  audio,\n  video,\n  select {\n    margin: 0;\n    padding: 0;\n    border: 0;\n    outline: 0;\n    font-size: 100%;\n    vertical-align: baseline;\n    background: transparent;\n    font-family: PingFangSC-Regular,Microsoft YaHei;\n\n  }\n  article,\n  aside,\n  details,\n  figcaption,\n  figure,\n  footer,\n  header,\n  hgroup,\n  menu,\n  nav,\n  section {\n    display: block;\n  }\n\n  audio,\n  canvas,\n  video {\n    display: inline-block;\n    *display: inline;\n    *zoom: 1;\n  }\n\n  audio:not([controls]) {\n    display: none;\n  }\n\n  :hover,\n  :focus,\n  :active {\n    outline: none;\n  }\n\n  html,\n  button,\n  input,\n  select,\n  textarea {\n    font-family: PingFangSC-Regular,Microsoft YaHei;\n  }\n\n  input,\n  select,\n  img {\n    vertical-align: middle;\n    border: 0px;\n    font-size: 100%;\n  }\n\n  ol,\n  ul {\n    list-style: none;\n  }\n\n  table {\n    border-collapse: collapse;\n    border-spacing: 0;\n  }\n\n  fieldset,\n  img {\n    border: 0;\n  }\n\n  a {\n    color: #0099cc;\n    cursor: pointer;\n    text-decoration: none;\n  }\n\n  a:hover {\n    color: #0383ae;\n    text-decoration: none;\n  }\n  i,\n  em {\n    font-style: normal;\n  }\n\n  select,\n  input[type=\"text\"],\n  input[type=\"submit\"],\n  input[type=\"reset\"],\n  input[type=\"button\"],\n  button {\n    -webkit-appearance: none;\n  }\n\n  input {\n    -webkit-appearance: none;\n  }\n\nimg {\n    display: block;\n}\n\n*{\n    box-sizing: border-box;\n}\n");

/***/ }),

/***/ "./src/parseArtboard/index.js":
/*!************************************!*\
  !*** ./src/parseArtboard/index.js ***!
  \************************************/
/*! exports provided: parseArtboard, parseArtboardIterator, parseDocument */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseArtboard", function() { return parseArtboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseArtboardIterator", function() { return parseArtboardIterator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "parseDocument", function() { return parseDocument; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _skpm_promise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @skpm/promise */ "./node_modules/@skpm/promise/index.js");
/* harmony import */ var _skpm_promise__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_skpm_promise__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wubafe/picasso-parse */ "./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/index.js");
/* harmony import */ var _wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _handleCode_handleWebCode__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./handleCode/handleWebCode */ "./src/parseArtboard/handleCode/handleWebCode.js");
/* harmony import */ var _getImageLayers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./getImageLayers */ "./src/parseArtboard/getImageLayers.js");



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }







/**
 * 画板解析
 * @param {*} type
 *
 */

var parseArtboard = function parseArtboard(artboardItem, progressSlice, getProgress, rootPath) {
  return new _skpm_promise__WEBPACK_IMPORTED_MODULE_4___default.a(function (resolve, reject) {
    // 未解析，则走解析流程
    var symbolInstanceIds = []; // 字体存储

    var fontMap = {};
    var symbolGroups = []; // 代码解析图片处理存储

    var codeImageMap = {};
    var d1 = new Date().valueOf(); // console.log('解析图片开始：', d1, artboardItem.frame.width);

    var sliceSize = 750 === artboardItem.frame.width ? 4 : 2;
    var sliceList = Object(_getImageLayers__WEBPACK_IMPORTED_MODULE_7__["default"])(artboardItem.layers, symbolInstanceIds, fontMap, symbolGroups, codeImageMap, rootPath, sliceSize); // console.log('fontMap', fontMap);

    var d2 = new Date().valueOf(); // console.log('解析图片结束：', d2-d1);

    parseDocument.artProgress += progressSlice * 0.7;
    getProgress(parseDocument.artProgress); // console.log('画板导出开始：');

    var artboardJSON = sketch__WEBPACK_IMPORTED_MODULE_2___default.a.export(artboardItem, {
      formats: 'json',
      output: false
    });
    var d3 = new Date().valueOf(); // console.log('画板导出结束：', d3-d2);

    parseDocument.artProgress += progressSlice * 0.1;
    getProgress(parseDocument.artProgress);
    var symbolGroupsJSON = []; // console.log('symbol导出开始：');

    if (symbolGroups.length > 0) {
      symbolGroupsJSON = sketch__WEBPACK_IMPORTED_MODULE_2___default.a.export(symbolGroups, {
        formats: 'json',
        output: false
      });
    }

    var d4 = new Date().valueOf(); // console.log('symbol导出结束：', d4-d3);

    var _mergeLayer = function _mergeLayer(layers) {
      for (var i = 0; i < layers.length; i++) {
        if (symbolInstanceIds.indexOf(layers[i].do_objectID) > -1) {
          layers[i] = JSON.parse(JSON.stringify(symbolGroupsJSON[symbolInstanceIds.indexOf(layers[i].do_objectID)]));
        }

        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _mergeLayer(layers[i].layers);
        }
      }

      return layers;
    };

    artboardJSON.layers = _mergeLayer(artboardJSON.layers);
    parseDocument.artProgress += progressSlice * 0.1;
    getProgress(parseDocument.artProgress);

    var _handleSlice = function _handleSlice(layers, sliceObject) {
      for (var i = 0; i < layers.length; i++) {
        if (sliceObject[layers[i].do_objectID]) {
          // 不是原始切片的图层以image的方式处理
          if (layers[i]._class !== 'slice') {
            layers[i]._class = 'image';
          }

          layers[i].isFlippedHorizontal = false;
          layers[i].isFlippedVertical = false;
          layers[i].style = {
            _class: 'style',
            borderOptions: {
              _class: 'borderOptions',
              isEnabled: true,
              dashPattern: [],
              lineCapStyle: 0,
              lineJoinStyle: 0
            },
            borders: [],
            colorControls: {
              _class: 'colorControls',
              isEnabled: false,
              brightness: 0,
              contrast: 1,
              hue: 0,
              saturation: 1
            },
            contextSettings: {
              _class: 'graphicsContextSettings',
              blendMode: 0,
              opacity: 1
            },
            fills: [],
            innerShadows: [],
            shadows: []
          };
          layers[i].layers = [];
          layers[i].imageUrl = sliceObject[layers[i].do_objectID];
        }

        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _handleSlice(layers[i].layers, sliceObject);
        }
      }

      return layers;
    }; // 字体补充


    var _handleFont = function _handleFont(layers, fontObject) {
      for (var i = 0; i < layers.length; i++) {
        var _layers$i$attributedS, _layers$i$attributedS2, _layers$i$attributedS3, _layers$i$attributedS4, _layers$i$attributedS5, _layers$i$attributedS6;

        // 仅限只有一段文本的情况，多段文本不处理
        if (fontObject[layers[i].do_objectID] && ((_layers$i$attributedS = layers[i].attributedString) === null || _layers$i$attributedS === void 0 ? void 0 : (_layers$i$attributedS2 = _layers$i$attributedS.attributes) === null || _layers$i$attributedS2 === void 0 ? void 0 : _layers$i$attributedS2.length) === 1 && (_layers$i$attributedS3 = layers[i].attributedString) !== null && _layers$i$attributedS3 !== void 0 && (_layers$i$attributedS4 = _layers$i$attributedS3.attributes[0]) !== null && _layers$i$attributedS4 !== void 0 && (_layers$i$attributedS5 = _layers$i$attributedS4.attributes) !== null && _layers$i$attributedS5 !== void 0 && (_layers$i$attributedS6 = _layers$i$attributedS5.MSAttributedStringFontAttribute) !== null && _layers$i$attributedS6 !== void 0 && _layers$i$attributedS6.attributes) {
          // console.log('fontObject[layers[i].do_objectID]', fontObject[layers[i].do_objectID]);
          layers[i].attributedString.attributes[0].attributes.MSAttributedStringFontAttribute.attributes.name = fontObject[layers[i].do_objectID];
        }

        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _handleFont(layers[i].layers, fontObject);
        }
      }

      return layers;
    }; // 处理代码模式图片


    var _handleCodeImage = function _handleCodeImage(layers, codeImageMap) {
      for (var j = 0; j < layers.length; j++) {
        if (codeImageMap[layers[j].do_objectID]) {
          layers[j].frame = _objectSpread(_objectSpread({}, layers[j].frame), codeImageMap.frame);
        }

        if (Array.isArray(layers[j].layers)) {
          layers[j].layers = _handleCodeImage(layers[j].layers, codeImageMap);
        }
      }

      return layers;
    };

    var sliceObject = {};
    sliceList.forEach(function (item) {
      if (!sliceObject[item.id]) {
        sliceObject[item.id] = 'imageUrl';
      }
    });
    artboardJSON.imageUrl = 'imageUrl'; // 图片处理

    artboardJSON.layers = _handleFont(artboardJSON.layers, fontMap); // 切片处理

    artboardJSON.layers = _handleSlice(artboardJSON.layers, sliceObject); // 切片尺寸处理

    artboardJSON.layers = _handleCodeImage(artboardJSON.layers, codeImageMap); // 代码DSL

    var codeDSL = Object(_wubafe_picasso_parse__WEBPACK_IMPORTED_MODULE_5__["picassoArtboardCodeParse"])(JSON.parse(JSON.stringify(artboardJSON))); // 图片map

    var imageMap = {}; // 处理DSL图片

    var _handleDSLImageUrl = function _handleDSLImageUrl(layers) {
      for (var j = 0; j < layers.length; j++) {
        if (!imageMap[layers[j].id] && sliceObject[layers[j].id]) {
          imageMap[layers[j].id] = 'imageUrl';
        }

        if (Array.isArray(layers[j].children)) {
          _handleDSLImageUrl(layers[j].children);
        }
      }

      return layers;
    };

    _handleDSLImageUrl(codeDSL.children);

    var realSliceList = [];
    sliceList.forEach(function (item) {
      if (imageMap[item.id] === 'imageUrl') {
        realSliceList.push(item);
      }
    }); // 设置图片url

    var _setImageUrl = function _setImageUrl(layers, imgMap) {
      for (var j = 0; j < layers.length; j++) {
        if (imgMap[layers[j].id] && layers[j].value === 'imageUrl') {
          var _layers$j$style, _layers$j$style$backg, _layers$j$style$backg2;

          // 1. 图片url进行替换
          layers[j].value = imgMap[layers[j].id]; // 2. 如果是背景图，需要对背景图url进行替换

          if ((_layers$j$style = layers[j].style) !== null && _layers$j$style !== void 0 && (_layers$j$style$backg = _layers$j$style.background) !== null && _layers$j$style$backg !== void 0 && (_layers$j$style$backg2 = _layers$j$style$backg.image) !== null && _layers$j$style$backg2 !== void 0 && _layers$j$style$backg2.url) {
            layers[j].style.background.image.url = imgMap[layers[j].id];
          }
        }

        if (Array.isArray(layers[j].children)) {
          layers[j].children = _setImageUrl(layers[j].children, imgMap);
        }
      }

      return layers;
    }; // console.log('realSliceList', realSliceList);


    var realSliceObject = {};
    realSliceList.forEach(function (_ref) {
      var id = _ref.id,
          imageLocalPath = _ref.imageLocalPath;
      realSliceObject[id] = imageLocalPath;
    });
    codeDSL.children = _setImageUrl(codeDSL.children, realSliceObject); // 代码生成

    Object(_handleCode_handleWebCode__WEBPACK_IMPORTED_MODULE_6__["default"])(rootPath, codeDSL);
    parseDocument.artProgress += progressSlice * 0.05;
    getProgress(parseDocument.artProgress);
    resolve({
      id: codeDSL.id,
      name: codeDSL.name.replace(/\//g, '／')
    });
  });
};
/**
 * 画板解析迭代器
 * @param {*} parseInfo 
 * @param {*} artboardList 
 * @param {*} progressSlice 
 * @param {*} getProgress 
 * @param {*} sliceSize 
 */

var parseArtboardIterator = function parseArtboardIterator(artboardList, progressSlice, getProgress, sliceSize, rootPath) {
  return new _skpm_promise__WEBPACK_IMPORTED_MODULE_4___default.a(function (resolve, reject) {
    var results = [];

    var _nextPromise = function _nextPromise(index, _artboardList) {
      if (parseDocument.isCancel) {
        reject();
      } else {
        // 全部画板解析任务完成
        if (index >= _artboardList.length) {
          resolve(results);
        }

        parseArtboard(_artboardList[index], progressSlice / _artboardList.length, getProgress, sliceSize, rootPath).then(function (res) {
          results.push(res);

          _nextPromise(index + 1, _artboardList);
        }).catch(function (err) {
          reject(err);
        });
      }
    };

    _nextPromise(0, artboardList);
  });
};
/**
 * 文档解析
 * @param {*} type 1 选中 2 all
 * 
 */

var parseDocument = function parseDocument(type, rootPath) {
  var getProgress = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {};
  return new _skpm_promise__WEBPACK_IMPORTED_MODULE_4___default.a(function (resolve, reject) {
    // 重置参数
    parseDocument.artProgress = 0;
    getProgress(parseDocument.artProgress);
    var d01 = new Date().valueOf(); // 获取当前文档

    var document = sketch__WEBPACK_IMPORTED_MODULE_2___default.a.getSelectedDocument();
    var artboards = []; // 当前选中的画板;

    if (type === 1) {
      artboards = document.selectedLayers.layers.filter(function (layer) {
        return layer.type === 'Artboard';
      });
    } else {
      document.pages.forEach(function (layer) {
        artboards = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(artboards), _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(layer.layers.filter(function (item) {
          return item.type === 'Artboard';
        })));
      });
    } // console.log('获取画板时间:', d01, new Date().valueOf() - d01);


    if (artboards.length === 0) {
      return sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('请选择画板！');
    }

    if (type === 1) {
      sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('解析选中画板');
    } else {
      sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('解析全部画板');
    }

    parseDocument.artProgress = 0.019;
    getProgress(parseDocument.artProgress); // 画板解析进度分配

    var progressArtboardSlice = 0.98;
    parseArtboardIterator(artboards, progressArtboardSlice, getProgress, rootPath).then(function (res) {
      // console.log('解析完成,结果如下:', res);
      getProgress(1);
      resolve(res);
    }).catch(function (err) {
      reject(err);
    });
  });
}; // 解析进度

parseDocument.artProgress = 0; // 取消标识

parseDocument.isCancel = false;

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['parseSelectArtboard'] = __skpm_run.bind(this, 'parseSelectArtboard');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['parseAllArtboard'] = __skpm_run.bind(this, 'parseAllArtboard');
globalThis['help'] = __skpm_run.bind(this, 'help')

//# sourceMappingURL=__index.js.map