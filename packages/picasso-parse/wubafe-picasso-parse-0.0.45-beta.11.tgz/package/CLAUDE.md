# CLAUDE.md

本文件为 Claude Code（claude.ai/code）在 `packages/picasso-parse` 包内工作时提供指引。仓库级约定见根目录 `CLAUDE.md`。

## 包定位

`@wubafe/picasso-parse` 是 Picasso 仓库**唯一对外发布**的 npm 包（公共 registry，`publishConfig.access: public`）。其余 6 个 sibling 包（`sketch-dsl` / `picasso-dsl` / `picasso-group` / `picasso-layout` / `picasso-trans` / `picasso-code-browser`）均为 `"private": true`，通过相对路径被本包引用，`tsc` 编译时（`tsconfig.include` 含 sibling 的 `src`）一起打进 `dist/`，发包不依赖 lerna。

纯逻辑层，**不依赖 Sketch 运行时**；但发布产物会跑在 Sketch 插件的 JavaScriptCore 环境里——**没有 node crypto / Buffer / fs**，任何新增依赖这些的代码都会在插件端炸掉（`parseRestoreDSL/sha1.ts` 是纯 JS SHA-1 实现，原因即此）。

## 常用命令

```bash
npm run build                        # tsc → dist/（改任何 sibling 包后也必须重 build 本包）
npx ts-node test/restore.test.ts     # RestoreDSL / annotateStableIds 断言式单测（75 项）
npm run test                         # ts-node-dev 跑 test/index.ts（手工对照用，非断言）
npm pack                             # 本地打 tarball（调试期插件端手工安装用）
npm publish --tag beta               # 预发布版本；正式版去掉 --tag
```

TypeScript 版本钉在 **3.9.7**，`target: es6`。不要用 TS 4+ 语法（如 `??=`、模板字面量类型）。

## 解析入口（src/index.ts 导出）

| 函数 | 签名 | 用途 |
| --- | --- | --- |
| `picassoArtboardMeatureParse(layer)` | 单输入 | 标注 DSL |
| `picassoArtboardCodeParse(layer)` | 单输入 | 代码 DSL（分组 + 布局推断） |
| `picassoArtboardOperationCodeParse(layer)` | 单输入 | 运营版（绝对定位） |
| `picassoArtboardLowcodeParse(layer)` | 单输入 | Lowcode / 海葵 |
| `annotateStableIds(exportB, exportA?, mastersC?)` | 多输入 | 稳定 ID / 内容指纹**原地注入** B 树 |
| `picassoArtboardRestoreParse(exportA, exportB, mastersC?, options?)` | 多输入 | RestoreDSL（结构保真、无布局推断） |

RestoreDSL 的三份输入：A = 原始画板导出（稳定 do_objectID）、B = 解绑副本导出（几何精确展开树）、C = 引用到的 symbolMaster 定义树列表。推荐调用顺序：**先 `annotateStableIds` 注入 B 树，再让四种存量 DSL 与 RestoreDSL 消费同一棵注入后的树**——这是跨产物 stableId 一致的前提。

## parseRestoreDSL 模块结构

```
src/parseRestoreDSL/
├── index.ts            picassoArtboardRestoreParse：预处理复用 + 三份输入合并 + meta 组装
├── annotateStableIds.ts A/B 平行前序遍历建映射，注入 stableId/contentHash/styleHash/
│                        subtreeHash + 解绑点 restoreComponentKey/restoreOverrides；
│                        结构不同构时贪心配对兜底（绝不抛错）
├── mapNode.ts          预处理后 SK 树 → RestoreDSL 节点（缺省省略在此执行）
├── normalize.ts        颜色/渐变/constraints/字体拆解/svgPath/runs 等纯函数（mapNode 与 hash 共用）
├── hash.ts             短哈希（sha1 前 8 位，碰撞延 12 位）+ contentSignature + Merkle subtreeHash
├── designTokens.ts     高频值聚合（swatches 拿不到，自动命名 color-N / text-N）
├── diffability.ts      跨版本 diff 前置判定（assessRestoreDiffability：复制画板检测，服务端 diff 第一步）
├── renderProfile.ts    LLM 还原精简视图（toRenderProfile：剥 hash/components/透明占位，省 31~44% 体积）
├── restoreTypes.ts     Schema 类型 + RESTORE_SCHEMA_VERSION + PARSER_VERSION 常量
└── sha1.ts             纯 JS SHA-1（JavaScriptCore 无 crypto）
```

配套文件：`schema/restore-dsl.schema.json`（格式规范真源）+
`schema/restore-dsl-rendering-guide.md`（**渲染语义规范**——消费端怎么渲染才对，
服务端 LLM 提示词的素材源）+ `tools/gen_restore_html.py` / `tools/gen_restore_html.js`
（确定性渲染基线，模拟 LLM 消费者，schema 变更后拿真实产物跑一遍当回归对照；
Python / Node ≥14 双实现逐行对齐、输出逐字节一致，渲染语义变更必须双边同改——
Node 侧渲染核心拆在 `tools/gen_restore_fragment.js`，改 JS 渲染语义在该文件，
`gen_restore_html.js` 只是对比页外壳，对齐口径是其最终产物逐字节一致；
fragment 模块另提供「只要还原稿」的片段 / 纯净页 / fitWidth 等比缩放 API）。
三者与 `RESTORE_SCHEMA_VERSION` 同步维护。

## 修改时的铁律

- **向后兼容（条件写入）**：`parseDSL/index.ts` 与 `filterGroupLayer.ts` 对 `stableId`/`contentHash`/`subtreeHash`/`styleHash` 必须**源字段存在才落 key**。本包发布在公共 npm，存在 `^` 范围自动升级的外部消费方——未经 annotate 的老输入，四种存量 DSL 产物必须逐字节不变。`test/restore.test.ts` 有护栏断言（每加一个透传字段都要补一条"未注入不落 key"断言），改动后必须跑。
- **两个版本常量手工同步**：`package.json.version` ↔ `restoreTypes.ts` 的 `PARSER_VERSION`（实现溯源）；`RESTORE_SCHEMA_VERSION` 只在 RestoreDSL **输出格式**变更的同一次提交里手动升（只加字段升 minor，破坏性变更原则上禁止），仅修 bug 不改格式时不动，且必须同步 `schema/restore-dsl.schema.json`（格式规范真源，可用 `python3 -m jsonschema` 或 ajv 校验产物）。
- **归一化与指纹同源**：`contentSignature`（hash.ts）与 `mapNode` 共用 normalize.ts 的纯函数。改任何归一化逻辑（颜色、字体、constraints…）都会改变全量 contentHash——属于「实现变更」，靠 parserVersion 溯源，但要意识到会让历史版本的 diff 模糊轮降级。
- **contentHash 不含 name / 绝对坐标 / children**：name 是 diff 模糊配对的独立打分信号，absFrame 会随父级移动变化。不要往 contentSignature 里加它们。
- **包主入口是点名导出制**：`src/index.ts` 逐个 re-export，`parseRestoreDSL/index.ts` 里新增的导出必须同时在主入口透传，否则外部 `require('@wubafe/picasso-parse')` 拿不到（曾发生 diffability 断链）。测试必须从 `'../src'` 主入口 import 新 API，直接引内部路径无法覆盖导出链。
- **两套字段名**：RestoreDSL 节点的稳定 ID 在 `id` 字段；存量四种 DSL 里透传后叫 `stableId`。写跨产物对齐逻辑时别搞混。
- **annotateStableIds 是原地修改**（含 mastersC），且幂等（`picassoArtboardRestoreParse` 检测 `contentHash` 已存在则跳过重注入）。
- 版本发布节奏：预发布用 `0.0.X-beta.N`（`npm publish --tag beta`，N 从 0 递增），验证通过后发正式 `0.0.X`。插件侧 package.json 精确锁版（无 `^`）。
